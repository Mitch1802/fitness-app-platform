# BlaulichtCloud
> [!IMPORTANT]
> interne Doku



### FEATURES / BUGS
siehe Release Notes und Projektübersicht

## Homepage News
https://blaulichtcloud.at/api/v3/news/public/?typ=extern

## Homepage Dienstppostenplan
https://blaulichtcloud.at/api/v1/homepage/public/

## Tests (lokal)
Python-Abhängigkeiten liegen in `django/requirements/` (`base.txt`, `production.txt`).
Für lokale Django-Tests werden ein paar Environment-Variablen benötigt.
Optional kann `USER_INVITE_TOKEN_TTL_HOURS` gesetzt werden.

PowerShell (Beispiel):

```powershell
$env:DATABASE_URL='sqlite:///C:/Users/mr96/GitHub/blaulicht-cloud-platform/django/test_db.sqlite3'
$env:DJANGO_SECRET_KEY='test-secret-key'
$env:DJANGO_API_URL='api/v1/'
$env:PUBLIC_FAHRZEUG_PIN='1234'
$env:VERSION='test'
C:/Users/mr96/GitHub/blaulicht-cloud-platform/.venv/Scripts/python.exe django/manage.py test
```

Nur Endpoint-Tests laufen lassen:

```powershell
C:/Users/mr96/GitHub/blaulicht-cloud-platform/.venv/Scripts/python.exe django/manage.py test core_apps.users.tests core_apps.fmd.tests core_apps.mitglieder.tests core_apps.modul_konfiguration.tests core_apps.konfiguration.tests core_apps.backup.tests core_apps.news.tests core_apps.inventar.tests core_apps.media.tests core_apps.atemschutz_masken.tests core_apps.atemschutz_geraete.tests core_apps.messgeraete.tests core_apps.pdf.tests core_apps.fahrzeuge.tests core_apps.verwaltung.tests
```

## PRODUKTIV
Der Produktiv-Rollout läuft über GitHub Actions.

Kanonische Server-Deploy-Dateien:

- `install/app_manager.sh`
- `install/docker-compose.yml`
- Betriebsanleitung: `install/README.md`

1. Der Build-Workflow erstellt die Release-Images und legt die Install-Dateien für Produktion auf dem zentralen Download-Server ab.
2. Der Production-Token wird im libuadmin-Frontend erzeugt und beim Start des Prod-Deploy-Workflows als Input `deploy_token` übergeben.
3. Mit diesem Token werden app_manager.sh und docker-compose.yml geladen und auf den Zielserver kopiert.
4. Auf dem Zielserver läuft danach app_manager.sh update VERSION.
5. Nach erfolgreichem Deploy wird der verwendete Token im libuadmin-Frontend widerrufen.

Manuelle Schritte sind nur noch Fallback. Die Details stehen in install/README.md.

## Celery Crontab anpassen
Die Zeiten für geplante Celery-Tasks werden in `django/rest_api/settings/base.py` im Block `CELERY_BEAT_SCHEDULE` gesetzt.

Beispiele:
- Täglich um 05:00: `crontab(hour=5, minute=0)`
- Sonntags um 03:00: `crontab(hour=3, minute=0, day_of_week=0)`
- Alle 10 Minuten (Test): `crontab(minute="*/10")`

Nach Änderungen:
- `celery_beat` neu starten
- optional auch `celery_worker` neu starten

Beispiel:
- `docker compose -f install/docker-compose.yml restart celery_beat`
- `docker compose -f install/docker-compose.yml restart celery_worker`