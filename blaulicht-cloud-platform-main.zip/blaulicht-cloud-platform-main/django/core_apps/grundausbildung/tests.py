from datetime import date
from uuid import uuid4

from rest_framework import status
from rest_framework.test import APITestCase

from core_apps.common.test_helpers import EndpointSmokeMixin
from core_apps.grundausbildung.models import GrundausbildungStatus
from core_apps.mitglieder.models import Mitglied


class GrundausbildungApiTests(EndpointSmokeMixin, APITestCase):
    def setUp(self):
        self.user_ausbildung = self.create_user_with_roles("AUSBILDUNG")
        self.user_mitglied = self.create_user_with_roles("MITGLIED")

        self.mitglied_in_modul = Mitglied.objects.create(
            stbnr=4101,
            vorname="Max",
            nachname="Ausbildung",
            dienstgrad="FM",
            svnr="1111",
            geburtsdatum=date(2001, 1, 1),
            grundausbildung=True,
        )
        self.mitglied_ohne_modul = Mitglied.objects.create(
            stbnr=4102,
            vorname="Eva",
            nachname="Ohne",
            dienstgrad="PFM",
            svnr="2222",
            geburtsdatum=date(2002, 2, 2),
            grundausbildung=False,
        )
        self.status_obj = GrundausbildungStatus.objects.create(mitglied=self.mitglied_in_modul)

    def test_endpoints_resolve(self):
        endpoints = [
            "grundausbildung/",
            "grundausbildung/add-mitglied/",
            "grundausbildung/remove-mitglied/",
            f"grundausbildung/{uuid4()}/",
        ]
        for endpoint in endpoints:
            with self.subTest(endpoint=endpoint):
                self.assert_options_works(endpoint)

    def test_requires_auth_and_role(self):
        self.assert_requires_authentication("grundausbildung/")
        self.assert_forbidden_without_role("grundausbildung/")

    def test_member_role_forbidden(self):
        self.client.force_authenticate(user=self.user_mitglied)
        response = self.request_method("get", "grundausbildung/")
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_list_shows_only_members_with_flag(self):
        GrundausbildungStatus.objects.create(mitglied=self.mitglied_ohne_modul)

        self.client.force_authenticate(user=self.user_ausbildung)
        response = self.request_method("get", "grundausbildung/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        stbnr_list = [item.get("stbnr") for item in response.data]
        self.assertIn(self.mitglied_in_modul.stbnr, stbnr_list)
        self.assertNotIn(self.mitglied_ohne_modul.stbnr, stbnr_list)

    def test_add_mitglied_sets_flag_and_creates_status(self):
        self.client.force_authenticate(user=self.user_ausbildung)
        response = self.request_method(
            "post",
            "grundausbildung/add-mitglied/",
            data={"mitglied": self.mitglied_ohne_modul.pkid},
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.mitglied_ohne_modul.refresh_from_db()
        self.assertTrue(self.mitglied_ohne_modul.grundausbildung)
        self.assertTrue(GrundausbildungStatus.objects.filter(mitglied=self.mitglied_ohne_modul).exists())

    def test_patch_station_fields(self):
        self.client.force_authenticate(user=self.user_ausbildung)
        endpoint = f"grundausbildung/{self.status_obj.id}/"

        response = self.request_method(
            "patch",
            endpoint,
            data={
                "station_basisausbildung": True,
                "station_atemschutz": True,
                "station_grundlagen_fuehren": False,
            },
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.status_obj.refresh_from_db()
        self.assertTrue(self.status_obj.station_basisausbildung)
        self.assertTrue(self.status_obj.station_atemschutz)
        self.assertFalse(self.status_obj.station_grundlagen_fuehren)

    def test_context_returns_only_members_not_yet_added(self):
        self.client.force_authenticate(user=self.user_ausbildung)
        response = self.request_method("get", "grundausbildung/context/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("mitglieder", response.data)
        stbnr_list = [item.get("stbnr") for item in response.data.get("mitglieder", [])]
        self.assertIn(self.mitglied_ohne_modul.stbnr, stbnr_list)
        self.assertNotIn(self.mitglied_in_modul.stbnr, stbnr_list)

    def test_remove_mitglied_clears_flag(self):
        self.client.force_authenticate(user=self.user_ausbildung)
        response = self.request_method(
            "post",
            "grundausbildung/remove-mitglied/",
            data={"mitglied": self.mitglied_in_modul.pkid},
        )

        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.mitglied_in_modul.refresh_from_db()
        self.assertFalse(self.mitglied_in_modul.grundausbildung)
