from django.apps import AppConfig


class GrundausbildungConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "core_apps.grundausbildung"
