from rest_framework import permissions, status
from rest_framework.decorators import action
from rest_framework.parsers import JSONParser
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from core_apps.common.permissions import HasAnyRolePermission
from core_apps.mitglieder.models import Mitglied

from .models import GrundausbildungStatus
from .serializers import (
    GrundausbildungAddMitgliedSerializer,
    GrundausbildungListSerializer,
    GrundausbildungStatusUpdateSerializer,
)


class GrundausbildungStatusViewSet(ModelViewSet):
    queryset = GrundausbildungStatus.objects.select_related("mitglied").all().order_by("mitglied__stbnr")
    permission_classes = [
        permissions.IsAuthenticated,
        HasAnyRolePermission.with_roles("ADMIN", "AUSBILDUNG"),
    ]
    parser_classes = [JSONParser]
    lookup_field = "id"
    pagination_class = None
    http_method_names = ["get", "patch", "post", "head", "options"]

    def get_queryset(self):
        return super().get_queryset().filter(mitglied__grundausbildung=True)

    def get_serializer_class(self):
        if self.action == "add_mitglied":
            return GrundausbildungAddMitgliedSerializer
        if self.action in {"partial_update", "update"}:
            return GrundausbildungStatusUpdateSerializer
        return GrundausbildungListSerializer

    @action(detail=False, methods=["post"], url_path="add-mitglied")
    def add_mitglied(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        mitglied = Mitglied.objects.filter(pkid=serializer.validated_data["mitglied"]).first()
        if mitglied is None:
            return Response({"detail": "Mitglied nicht gefunden."}, status=status.HTTP_404_NOT_FOUND)

        mitglied.grundausbildung = True
        mitglied.save(update_fields=["grundausbildung", "updated_at"])

        status_obj, _ = GrundausbildungStatus.objects.get_or_create(mitglied=mitglied)

        response_serializer = GrundausbildungListSerializer(status_obj)
        return Response(response_serializer.data, status=status.HTTP_200_OK)

    @action(detail=False, methods=["post"], url_path="remove-mitglied")
    def remove_mitglied(self, request):
        serializer = GrundausbildungAddMitgliedSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        mitglied = Mitglied.objects.filter(pkid=serializer.validated_data["mitglied"]).first()
        if mitglied is None:
            return Response({"detail": "Mitglied nicht gefunden."}, status=status.HTTP_404_NOT_FOUND)

        mitglied.grundausbildung = False
        mitglied.save(update_fields=["grundausbildung", "updated_at"])

        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(detail=False, methods=["get"], url_path="context")
    def context(self, request):
        mitglieder = list(
            Mitglied.objects.filter(grundausbildung=False)
            .exclude(dienststatus=Mitglied.Dienststatus.ABGEMELDET)
            .order_by("stbnr")
            .values("id", "pkid", "stbnr", "vorname", "nachname", "dienstgrad", "dienststatus")
        )
        return Response({"mitglieder": mitglieder}, status=status.HTTP_200_OK)
