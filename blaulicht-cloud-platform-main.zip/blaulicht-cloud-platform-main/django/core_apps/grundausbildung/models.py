from django.db import models
from django.utils.translation import gettext_lazy as _

from core_apps.common.models import TimeStampedModel
from core_apps.mitglieder.models import Mitglied


class GrundausbildungStatus(TimeStampedModel):
    mitglied = models.OneToOneField(
        Mitglied,
        on_delete=models.CASCADE,
        related_name="grundausbildung_status",
        verbose_name=_("Mitglied"),
    )
    station_basisausbildung = models.BooleanField(default=False, verbose_name=_("Basisausbildung"))
    station_atemschutz = models.BooleanField(default=False, verbose_name=_("Atemschutz"))
    station_grundlagen_fuehren = models.BooleanField(default=False, verbose_name=_("Grundlagen Führen"))

    class Meta(TimeStampedModel.Meta):
        ordering = ["mitglied__stbnr"]

    def __str__(self):
        return f"Grundausbildung {self.mitglied.stbnr}"
