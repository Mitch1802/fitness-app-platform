from rest_framework import serializers

from core_apps.mitglieder.models import Mitglied

from .models import GrundausbildungStatus


class GrundausbildungListSerializer(serializers.ModelSerializer):
    mitglied_id = serializers.UUIDField(source="mitglied.id", read_only=True)
    mitglied_pkid = serializers.IntegerField(source="mitglied.pkid", read_only=True)
    stbnr = serializers.IntegerField(source="mitglied.stbnr", read_only=True)
    vorname = serializers.CharField(source="mitglied.vorname", read_only=True)
    nachname = serializers.CharField(source="mitglied.nachname", read_only=True)
    dienstgrad = serializers.CharField(source="mitglied.dienstgrad", read_only=True)
    dienststatus = serializers.CharField(source="mitglied.dienststatus", read_only=True)

    class Meta:
        model = GrundausbildungStatus
        fields = [
            "id",
            "pkid",
            "mitglied_id",
            "mitglied_pkid",
            "stbnr",
            "vorname",
            "nachname",
            "dienstgrad",
            "dienststatus",
            "station_basisausbildung",
            "station_atemschutz",
            "station_grundlagen_fuehren",
            "created_at",
            "updated_at",
        ]


class GrundausbildungStatusUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = GrundausbildungStatus
        fields = [
            "station_basisausbildung",
            "station_atemschutz",
            "station_grundlagen_fuehren",
        ]


class GrundausbildungAddMitgliedSerializer(serializers.Serializer):
    mitglied = serializers.IntegerField(min_value=1)

    def validate_mitglied(self, value):
        if not Mitglied.objects.filter(pkid=value).exists():
            raise serializers.ValidationError("Mitglied nicht gefunden.")
        return value
