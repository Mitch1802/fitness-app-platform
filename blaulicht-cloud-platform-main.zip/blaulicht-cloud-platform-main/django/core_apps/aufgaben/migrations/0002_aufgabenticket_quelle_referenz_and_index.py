from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("aufgaben", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="aufgabenticket",
            name="quelle_referenz",
            field=models.CharField(blank=True, default="", max_length=128, verbose_name="Quelle Referenz"),
        ),
        migrations.AddIndex(
            model_name="aufgabenticket",
            index=models.Index(fields=["quelle_modul", "quelle_referenz"], name="aufgaben_quelle_idx"),
        ),
    ]
