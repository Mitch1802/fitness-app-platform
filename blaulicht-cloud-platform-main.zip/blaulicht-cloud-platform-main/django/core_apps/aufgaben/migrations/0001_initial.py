from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import uuid


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="AufgabenTicket",
            fields=[
                ("pkid", models.BigAutoField(editable=False, primary_key=True, serialize=False, unique=True)),
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, unique=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("titel", models.CharField(max_length=255, verbose_name="Titel")),
                ("beschreibung", models.TextField(blank=True, default="", verbose_name="Beschreibung")),
                ("zu_erledigen_bis", models.DateField(blank=True, null=True, verbose_name="Zu erledigen bis")),
                (
                    "status",
                    models.CharField(
                        choices=[("OFFEN", "Offen"), ("IN_BEARBEITUNG", "In Bearbeitung"), ("GESCHLOSSEN", "Geschlossen")],
                        db_index=True,
                        default="OFFEN",
                        max_length=20,
                        verbose_name="Status",
                    ),
                ),
                ("geschlossen_datum", models.DateTimeField(blank=True, null=True, verbose_name="Geschlossen Datum")),
                ("email_versendet_datum", models.DateTimeField(blank=True, null=True, verbose_name="Email versendet Datum")),
                ("quelle_modul", models.CharField(blank=True, default="", max_length=64, verbose_name="Quelle Modul")),
                (
                    "melder",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="gemeldete_tickets",
                        to=settings.AUTH_USER_MODEL,
                        verbose_name="Melder",
                    ),
                ),
                (
                    "zustaendiger_user",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="zugewiesene_tickets",
                        to=settings.AUTH_USER_MODEL,
                        verbose_name="Zustaendiger User",
                    ),
                ),
            ],
            options={
                "ordering": ["-created_at"],
            },
        ),
        migrations.AddIndex(
            model_name="aufgabenticket",
            index=models.Index(fields=["status"], name="aufgaben_status_idx"),
        ),
        migrations.AddIndex(
            model_name="aufgabenticket",
            index=models.Index(fields=["zustaendiger_user"], name="aufgaben_zust_idx"),
        ),
        migrations.AddIndex(
            model_name="aufgabenticket",
            index=models.Index(fields=["email_versendet_datum"], name="aufgaben_mail_idx"),
        ),
    ]
