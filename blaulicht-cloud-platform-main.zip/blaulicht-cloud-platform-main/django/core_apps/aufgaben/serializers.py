from rest_framework import serializers

from .models import AufgabenTicket
from core_apps.users.models import User


class AufgabenTicketSerializer(serializers.ModelSerializer):
    melder_username = serializers.SerializerMethodField(read_only=True)
    zustaendiger_username = serializers.SerializerMethodField(read_only=True)
    zustaendiger_user = serializers.SlugRelatedField(
        slug_field="id",
        queryset=User.objects.filter(is_active=True),
        allow_null=False,
        required=True,
    )

    class Meta:
        model = AufgabenTicket
        fields = [
            "id",
            "titel",
            "melder",
            "melder_username",
            "zustaendiger_user",
            "zustaendiger_username",
            "beschreibung",
            "zu_erledigen_bis",
            "status",
            "geschlossen_datum",
            "email_versendet_datum",
            "quelle_modul",
            "quelle_referenz",
            "created_at",
            "updated_at",
        ]
        read_only_fields = [
            "id",
            "melder",
            "melder_username",
            "zustaendiger_username",
            "geschlossen_datum",
            "email_versendet_datum",
            "quelle_referenz",
            "created_at",
            "updated_at",
        ]

    def get_melder_username(self, obj: AufgabenTicket) -> str:
        return getattr(obj.melder, "username", "") or ""

    def get_zustaendiger_username(self, obj: AufgabenTicket) -> str:
        return getattr(obj.zustaendiger_user, "username", "") or ""

    def validate_titel(self, value: str) -> str:
        cleaned = str(value or "").strip()
        if not cleaned:
            raise serializers.ValidationError("Titel ist erforderlich.")
        return cleaned

    def validate_beschreibung(self, value: str) -> str:
        cleaned = str(value or "").strip()
        if not cleaned:
            raise serializers.ValidationError("Beschreibung ist erforderlich.")
        return cleaned

    def validate(self, attrs):
        zust = attrs.get("zustaendiger_user", getattr(self.instance, "zustaendiger_user", None))
        if not zust:
            raise serializers.ValidationError({"zustaendiger_user": "Zustaendiger User ist erforderlich."})
        return attrs
