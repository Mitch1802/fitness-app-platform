"""
Celery tasks for daily Aufgaben and Tickets notifications.
"""
import logging
from collections import defaultdict

from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone

from .models import AufgabenTicket

logger = logging.getLogger(__name__)


def _build_mail_content(tickets: list[AufgabenTicket]) -> str:
    lines = [
        "Hallo,",
        "",
        "du hast neue Aufgaben/Tickets:",
        "",
    ]

    for ticket in tickets:
        due = ticket.zu_erledigen_bis.strftime("%d.%m.%Y") if ticket.zu_erledigen_bis else "kein Datum"
        lines.append(f"- {ticket.titel} | Faellig bis: {due} | Status: {ticket.get_status_display()}")

    lines.extend([
        "",
        "Viele Gruesse",
        "Blaulicht Cloud",
    ])
    return "\n".join(lines)


@shared_task(bind=True, max_retries=3)
def send_daily_new_ticket_summary(self):
    """Send a daily 07:00 summary mail with newly created open tickets per responsible user."""
    try:
        logger.info("Starting daily ticket summary task")

        tickets = (
            AufgabenTicket.objects.select_related("zustaendiger_user")
            .filter(
                status__in=[AufgabenTicket.Status.OFFEN, AufgabenTicket.Status.IN_BEARBEITUNG],
                email_versendet_datum__isnull=True,
                zustaendiger_user__isnull=False,
            )
            .order_by("zustaendiger_user__id", "created_at")
        )

        grouped: dict[str, list[AufgabenTicket]] = defaultdict(list)
        for ticket in tickets:
            user = ticket.zustaendiger_user
            if user is None:
                continue
            grouped[str(user.id)].append(ticket)

        now = timezone.now()
        sent_count = 0

        for user_tickets in grouped.values():
            user = user_tickets[0].zustaendiger_user
            if user is None:
                continue

            recipient = str(getattr(user, "email", "") or "").strip()
            if not recipient:
                logger.warning("Ticket summary skipped for user without email", extra={"username": user.username})
                continue

            subject = f"Neue Aufgaben/Tickets ({len(user_tickets)})"
            message = _build_mail_content(user_tickets)
            send_mail(
                subject=subject,
                message=message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[recipient],
                fail_silently=False,
            )

            AufgabenTicket.objects.filter(id__in=[ticket.id for ticket in user_tickets]).update(email_versendet_datum=now)
            sent_count += len(user_tickets)

        logger.info("Daily ticket summary task finished", extra={"sent_tickets": sent_count})

    except Exception as exc:
        logger.exception("Daily ticket summary task failed")
        raise self.retry(exc=exc, countdown=60)
