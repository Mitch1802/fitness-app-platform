from uuid import uuid4
from unittest.mock import patch

from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from core_apps.aufgaben.models import AufgabenTicket
from core_apps.aufgaben.models import create_or_reopen_ticket
from core_apps.aufgaben.tasks import send_daily_new_ticket_summary
from core_apps.common.test_helpers import EndpointSmokeMixin
from core_apps.users.models import Role, User


class AufgabenEndpointTests(EndpointSmokeMixin, APITestCase):
    def setUp(self):
        self.user_a = User.objects.create_user(username="ticket_user_a", password="Test123!", email="a@example.com")
        self.user_b = User.objects.create_user(username="ticket_user_b", password="Test123!", email="b@example.com")
        self.user_c = User.objects.create_user(username="ticket_user_c", password="Test123!", email="c@example.com")

        admin_role, _ = Role.objects.get_or_create(key="ADMIN", defaults={"verbose_name": "Admin"})
        self.admin = User.objects.create_user(username="ticket_admin", password="Test123!", email="admin@example.com")
        self.admin.roles.add(admin_role)

    def test_endpoints_resolve(self):
        self.assert_options_works("aufgaben/")
        self.assert_options_works("aufgaben/summary/")
        self.assert_options_works(f"aufgaben/{uuid4()}/")

    def test_create_sets_melder_automatically(self):
        self.client.force_authenticate(user=self.user_a)

        response = self.request_method(
            "post",
            "aufgaben/",
            data={
                "titel": "Testticket",
                "zustaendiger_user": str(self.user_b.id),
                "beschreibung": "Beschreibung",
                "status": AufgabenTicket.Status.OFFEN,
            },
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        ticket = AufgabenTicket.objects.get(titel="Testticket")
        self.assertEqual(ticket.melder_id, self.user_a.pk)

    def test_create_requires_zustaendiger_user(self):
        self.client.force_authenticate(user=self.user_a)

        response = self.request_method(
            "post",
            "aufgaben/",
            data={
                "titel": "Ohne Zustaendiger",
                "beschreibung": "Beschreibung",
                "status": AufgabenTicket.Status.OFFEN,
            },
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("zustaendiger_user", response.data)

    def test_create_requires_beschreibung(self):
        self.client.force_authenticate(user=self.user_a)

        response = self.request_method(
            "post",
            "aufgaben/",
            data={
                "titel": "Ohne Beschreibung",
                "zustaendiger_user": str(self.user_b.id),
                "beschreibung": "   ",
                "status": AufgabenTicket.Status.OFFEN,
            },
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("beschreibung", response.data)

    def test_non_admin_sees_only_assigned_tickets_by_default(self):
        AufgabenTicket.objects.create(titel="A1", melder=self.user_a, zustaendiger_user=self.user_b)
        AufgabenTicket.objects.create(titel="A2", melder=self.user_c, zustaendiger_user=self.user_a)
        AufgabenTicket.objects.create(titel="A3", melder=self.user_c, zustaendiger_user=self.user_b)

        self.client.force_authenticate(user=self.user_a)
        response = self.request_method("get", "aufgaben/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        titles = {item.get("titel") for item in response.data}
        self.assertEqual(titles, {"A2"})

    def test_non_admin_can_include_created_tickets(self):
        AufgabenTicket.objects.create(titel="A1", melder=self.user_a, zustaendiger_user=self.user_b)
        AufgabenTicket.objects.create(titel="A2", melder=self.user_c, zustaendiger_user=self.user_a)
        AufgabenTicket.objects.create(titel="A3", melder=self.user_c, zustaendiger_user=self.user_b)

        self.client.force_authenticate(user=self.user_a)
        response = self.request_method("get", "aufgaben/?include_created=1")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        titles = {item.get("titel") for item in response.data}
        self.assertEqual(titles, {"A1", "A2"})

    def test_admin_sees_all_tickets(self):
        AufgabenTicket.objects.create(titel="A1", melder=self.user_a, zustaendiger_user=self.user_b)
        AufgabenTicket.objects.create(titel="A2", melder=self.user_c, zustaendiger_user=self.user_a)

        self.client.force_authenticate(user=self.admin)
        response = self.request_method("get", "aufgaben/?alle=1")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)

    def test_admin_sees_only_assigned_tickets_by_default(self):
        AufgabenTicket.objects.create(titel="A1", melder=self.user_a, zustaendiger_user=self.user_b)
        AufgabenTicket.objects.create(titel="A2", melder=self.user_c, zustaendiger_user=self.admin)

        self.client.force_authenticate(user=self.admin)
        response = self.request_method("get", "aufgaben/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        titles = {item.get("titel") for item in response.data}
        self.assertEqual(titles, {"A2"})

    def test_summary_counts_non_closed_tickets(self):
        AufgabenTicket.objects.create(titel="O", melder=self.user_a, zustaendiger_user=self.user_a, status=AufgabenTicket.Status.OFFEN)
        AufgabenTicket.objects.create(titel="I", melder=self.user_a, zustaendiger_user=self.user_a, status=AufgabenTicket.Status.IN_BEARBEITUNG)
        AufgabenTicket.objects.create(titel="G", melder=self.user_a, zustaendiger_user=self.user_a, status=AufgabenTicket.Status.GESCHLOSSEN)

        self.client.force_authenticate(user=self.user_a)
        response = self.request_method("get", "aufgaben/summary/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data.get("offen"), 1)
        self.assertEqual(response.data.get("in_bearbeitung"), 1)
        self.assertEqual(response.data.get("gesamt_offen"), 2)

    @patch("core_apps.aufgaben.tasks.send_mail")
    def test_daily_summary_marks_sent_tickets(self, send_mail_mock):
        ticket = AufgabenTicket.objects.create(
            titel="Mailticket",
            melder=self.user_a,
            zustaendiger_user=self.user_b,
            status=AufgabenTicket.Status.OFFEN,
            email_versendet_datum=None,
        )

        send_daily_new_ticket_summary()

        ticket.refresh_from_db()
        self.assertTrue(send_mail_mock.called)
        self.assertIsNotNone(ticket.email_versendet_datum)

    def test_status_sets_closed_date(self):
        ticket = AufgabenTicket.objects.create(
            titel="Status",
            melder=self.user_a,
            zustaendiger_user=self.user_b,
            status=AufgabenTicket.Status.OFFEN,
        )
        self.assertIsNone(ticket.geschlossen_datum)

        ticket.status = AufgabenTicket.Status.GESCHLOSSEN
        ticket.save()
        self.assertIsNotNone(ticket.geschlossen_datum)

        ticket.status = AufgabenTicket.Status.OFFEN
        ticket.save()
        self.assertIsNone(ticket.geschlossen_datum)

    def test_create_or_reopen_ticket_deduplicates_by_source_reference(self):
        ticket_1 = create_or_reopen_ticket(
            titel="Auto Ticket",
            melder=self.user_a,
            zustaendiger_user=self.user_b,
            beschreibung="Erstversion",
            quelle_modul="wartung_service",
            quelle_referenz="fahrzeug:1:service",
        )

        ticket_1.status = AufgabenTicket.Status.GESCHLOSSEN
        ticket_1.save()

        ticket_2 = create_or_reopen_ticket(
            titel="Auto Ticket aktualisiert",
            melder=self.user_a,
            zustaendiger_user=self.user_b,
            beschreibung="Neu geoeffnet",
            quelle_modul="wartung_service",
            quelle_referenz="fahrzeug:1:service",
        )

        self.assertEqual(ticket_1.id, ticket_2.id)
        self.assertEqual(ticket_2.status, AufgabenTicket.Status.OFFEN)
        self.assertEqual(ticket_2.titel, "Auto Ticket aktualisiert")
        self.assertEqual(
            AufgabenTicket.objects.filter(quelle_modul="wartung_service", quelle_referenz="fahrzeug:1:service").count(),
            1,
        )
