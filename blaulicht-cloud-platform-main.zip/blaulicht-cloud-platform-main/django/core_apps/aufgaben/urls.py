from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import AufgabenTicketViewSet

router = DefaultRouter()
router.register(r"", AufgabenTicketViewSet, basename="aufgaben")

urlpatterns = [
    path("", include(router.urls)),
]
