from django.db.models import Q
from rest_framework import permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from .models import AufgabenTicket
from .serializers import AufgabenTicketSerializer
from core_apps.users.models import User


class AufgabenTicketViewSet(ModelViewSet):
    serializer_class = AufgabenTicketSerializer
    permission_classes = [permissions.IsAuthenticated]
    lookup_field = "id"
    pagination_class = None
    ordering = ["-created_at"]

    def _can_see_all(self, user) -> bool:
        return hasattr(user, "has_role") and (user.has_role("ADMIN") or user.has_role("KOMMANDO"))

    def _query_param_enabled(self, name: str) -> bool:
        return self.request.query_params.get(name, "0") in ("1", "true", "yes")

    def _list_filter(self, user) -> Q:
        ticket_filter = Q(zustaendiger_user=user)
        if self._query_param_enabled("include_created"):
            ticket_filter |= Q(melder=user)
        return ticket_filter

    def get_queryset(self):
        user = self.request.user
        queryset = AufgabenTicket.objects.select_related("melder", "zustaendiger_user").all()

        if self._can_see_all(user):
            if self.action in {"list", "summary"} and not self._query_param_enabled("alle"):
                return queryset.filter(self._list_filter(user)).distinct()
            return queryset

        if self.action in {"list", "summary"}:
            return queryset.filter(self._list_filter(user)).distinct()

        return queryset.filter(Q(melder=user) | Q(zustaendiger_user=user)).distinct()

    def perform_create(self, serializer):
        serializer.save(melder=self.request.user)

    @action(detail=False, methods=["get"], url_path="summary")
    def summary(self, request):
        queryset = self.get_queryset()
        offen = queryset.filter(status=AufgabenTicket.Status.OFFEN).count()
        in_bearbeitung = queryset.filter(status=AufgabenTicket.Status.IN_BEARBEITUNG).count()

        return Response(
            {
                "offen": offen,
                "in_bearbeitung": in_bearbeitung,
                "gesamt_offen": offen + in_bearbeitung,
            }
        )

    @action(detail=False, methods=["get"], url_path="context")
    def context(self, request):
        users = (
            User.objects.exclude(email__isnull=True)
            .exclude(email__exact="")
            .order_by("username")
            .values("id", "username", "email")
        )
        return Response(
            {
                "users": [
                    {"id": str(item["id"]), "username": item["username"]}
                    for item in users
                    if str(item.get("email") or "").strip() != ""
                ],
                "current_user": {
                    "id": str(request.user.id),
                    "username": request.user.username,
                },
                "can_see_all": self._can_see_all(request.user),
            }
        )
