from django.conf import settings
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from core_apps.common.models import TimeStampedModel


class AufgabenTicket(TimeStampedModel):
    class Status(models.TextChoices):
        OFFEN = "OFFEN", "Offen"
        IN_BEARBEITUNG = "IN_BEARBEITUNG", "In Bearbeitung"
        GESCHLOSSEN = "GESCHLOSSEN", "Geschlossen"

    titel = models.CharField(verbose_name=_("Titel"), max_length=255)
    melder = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name="gemeldete_tickets",
        null=True,
        blank=True,
        verbose_name=_("Melder"),
    )
    zustaendiger_user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name="zugewiesene_tickets",
        null=True,
        blank=True,
        verbose_name=_("Zustaendiger User"),
    )
    beschreibung = models.TextField(verbose_name=_("Beschreibung"), blank=True, default="")
    zu_erledigen_bis = models.DateField(verbose_name=_("Zu erledigen bis"), null=True, blank=True)
    status = models.CharField(
        verbose_name=_("Status"),
        max_length=20,
        choices=Status.choices,
        default=Status.OFFEN,
        db_index=True,
    )
    geschlossen_datum = models.DateTimeField(verbose_name=_("Geschlossen Datum"), null=True, blank=True)
    email_versendet_datum = models.DateTimeField(verbose_name=_("Email versendet Datum"), null=True, blank=True)
    quelle_modul = models.CharField(verbose_name=_("Quelle Modul"), max_length=64, blank=True, default="")
    quelle_referenz = models.CharField(verbose_name=_("Quelle Referenz"), max_length=128, blank=True, default="")

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["status"], name="aufgaben_status_idx"),
            models.Index(fields=["zustaendiger_user"], name="aufgaben_zust_idx"),
            models.Index(fields=["email_versendet_datum"], name="aufgaben_mail_idx"),
            models.Index(fields=["quelle_modul", "quelle_referenz"], name="aufgaben_quelle_idx"),
        ]

    def __str__(self) -> str:
        return f"{self.titel} ({self.get_status_display()})"

    def apply_status_defaults(self) -> None:
        if self.status == self.Status.GESCHLOSSEN and not self.geschlossen_datum:
            self.geschlossen_datum = timezone.now()
        elif self.status != self.Status.GESCHLOSSEN and self.geschlossen_datum is not None:
            self.geschlossen_datum = None

    def save(self, *args, **kwargs):
        self.apply_status_defaults()
        return super().save(*args, **kwargs)


def create_ticket(*, titel: str, melder, zustaendiger_user=None, beschreibung: str = "", zu_erledigen_bis=None, quelle_modul: str = "", quelle_referenz: str = "") -> AufgabenTicket:
    """Central helper to create tickets from this app or future external modules."""
    return AufgabenTicket.objects.create(
        titel=titel,
        melder=melder,
        zustaendiger_user=zustaendiger_user,
        beschreibung=beschreibung,
        zu_erledigen_bis=zu_erledigen_bis,
        quelle_modul=quelle_modul,
        quelle_referenz=quelle_referenz,
    )


def create_or_reopen_ticket(*, titel: str, melder, zustaendiger_user=None, beschreibung: str = "", zu_erledigen_bis=None, quelle_modul: str = "", quelle_referenz: str = "") -> AufgabenTicket:
    """Create a ticket once per source reference or reopen/update an existing one."""
    existing = None
    if quelle_modul and quelle_referenz:
        existing = (
            AufgabenTicket.objects.filter(quelle_modul=quelle_modul, quelle_referenz=quelle_referenz)
            .order_by("-created_at")
            .first()
        )

    if existing:
        existing.titel = titel
        existing.melder = melder
        existing.zustaendiger_user = zustaendiger_user
        existing.beschreibung = beschreibung
        existing.zu_erledigen_bis = zu_erledigen_bis
        existing.quelle_modul = quelle_modul
        existing.quelle_referenz = quelle_referenz
        if existing.status == AufgabenTicket.Status.GESCHLOSSEN:
            existing.status = AufgabenTicket.Status.OFFEN
            existing.email_versendet_datum = None
        existing.save()
        return existing

    return AufgabenTicket.objects.create(
        titel=titel,
        melder=melder,
        zustaendiger_user=zustaendiger_user,
        beschreibung=beschreibung,
        zu_erledigen_bis=zu_erledigen_bis,
        quelle_modul=quelle_modul,
        quelle_referenz=quelle_referenz,
    )
