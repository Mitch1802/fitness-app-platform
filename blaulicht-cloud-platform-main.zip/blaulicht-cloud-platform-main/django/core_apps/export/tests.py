from typing import cast

from rest_framework import status
from rest_framework.test import APITestCase, APIClient

from core_apps.common.test_helpers import EndpointSmokeMixin
from core_apps.einsatzberichte.models import Einsatzbericht
from core_apps.mitglieder.models import Mitglied


class ExportEndpointTests(EndpointSmokeMixin, APITestCase):
    def setUp(self):
        self.export_user = self.create_user_with_roles("EXPORT")

    def test_all_export_endpoints_resolve(self):
        endpoints = [
            "export/context/",
            "export/exporte/standesliste/",
            "export/exporte/einsatzstatistik/",
            "export/exporte/einsatzauflistung/",
        ]

        for endpoint in endpoints:
            with self.subTest(endpoint=endpoint):
                self.assert_options_works(endpoint)

    def test_export_requires_auth_and_role(self):
        self.assert_requires_authentication("export/context/")
        self.assert_forbidden_without_role("export/context/")
        self.assert_requires_authentication("export/exporte/standesliste/")
        self.assert_forbidden_without_role("export/exporte/standesliste/")
        self.assert_requires_authentication("export/exporte/einsatzstatistik/")
        self.assert_forbidden_without_role("export/exporte/einsatzstatistik/")
        self.assert_requires_authentication("export/exporte/einsatzauflistung/")
        self.assert_forbidden_without_role("export/exporte/einsatzauflistung/")

    def test_export_method_matrix_no_server_error(self):
        self.assert_method_matrix_no_server_error("export/context/")
        self.assert_method_matrix_no_server_error("export/exporte/standesliste/")
        self.assert_method_matrix_no_server_error("export/exporte/einsatzstatistik/")
        self.assert_method_matrix_no_server_error("export/exporte/einsatzauflistung/")

    def test_export_standesliste_returns_active_members(self):
        client = cast(APIClient, self.client)
        client.force_authenticate(user=self.export_user)

        Mitglied.objects.create(
            stbnr=10,
            vorname="Anna",
            nachname="Aktiv",
            dienstgrad="FM",
            geburtsdatum="2000-01-01",
            dienststatus=Mitglied.Dienststatus.AKTIV,
        )
        Mitglied.objects.create(
            stbnr=12,
            vorname="Rita",
            nachname="Reserve",
            dienstgrad="FM",
            geburtsdatum="1995-01-01",
            dienststatus=Mitglied.Dienststatus.RESERVE,
        )
        Mitglied.objects.create(
            stbnr=13,
            vorname="Jana",
            nachname="Jugend",
            dienstgrad="JFM",
            geburtsdatum="2010-01-01",
            dienststatus=Mitglied.Dienststatus.JUGEND,
        )

        response = self.request_method("get", "export/exporte/standesliste/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data, [{"stbnr": 10, "dienstgrad": "FM", "name": "Anna Aktiv"}])

    def test_export_einsatzstatistik_filters_by_year(self):
        client = cast(APIClient, self.client)
        client.force_authenticate(user=self.export_user)

        anna = Mitglied.objects.create(
            stbnr=10,
            vorname="Anna",
            nachname="Aktiv",
            dienstgrad="FM",
            geburtsdatum="2000-01-01",
            dienststatus=Mitglied.Dienststatus.AKTIV,
        )

        e1 = Einsatzbericht.objects.create(
            einsatzleiter="Anna Aktiv",
            einsatzart="Brandeinsatz",
            alarmstichwort="B1",
            einsatzadresse="Musterweg 1",
            alarmierende_stelle="LSZ",
            einsatz_datum="2026-01-10",
            status=Einsatzbericht.Status.ENTWURF,
        )
        e2 = Einsatzbericht.objects.create(
            einsatzleiter="Anna Aktiv",
            einsatzart="Brandeinsatz",
            alarmstichwort="B2",
            einsatzadresse="Musterweg 1",
            alarmierende_stelle="LSZ",
            einsatz_datum="2025-01-10",
            status=Einsatzbericht.Status.ENTWURF,
        )
        e1.mitglieder.set([anna])
        e2.mitglieder.set([anna])

        response = self.request_method("get", "export/exporte/einsatzstatistik/?jahr=2026")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data, [{"stbnr": 10, "name": "Anna Aktiv", "einsaetze": 1}])

    def test_export_einsatzauflistung_returns_rows_for_year(self):
        client = cast(APIClient, self.client)
        client.force_authenticate(user=self.export_user)

        Einsatzbericht.objects.create(
            einsatzleiter="Max Muster",
            einsatzart="Technischer Einsatz",
            alarmstichwort="T1",
            einsatzadresse="Bahnhof 2",
            alarmierende_stelle="LSZ",
            einsatz_datum="2026-03-02",
            status=Einsatzbericht.Status.GESENDET,
        )
        Einsatzbericht.objects.create(
            einsatzleiter="Alt Einsatz",
            einsatzart="Brandeinsatz",
            alarmstichwort="B9",
            einsatzadresse="Altweg 1",
            alarmierende_stelle="LSZ",
            einsatz_datum="2025-03-02",
            status=Einsatzbericht.Status.GESENDET,
        )

        response = self.request_method("get", "export/exporte/einsatzauflistung/?jahr=2026")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["alarmstichwort"], "T1")

    def test_export_year_validation(self):
        client = cast(APIClient, self.client)
        client.force_authenticate(user=self.export_user)

        response_stat = self.request_method("get", "export/exporte/einsatzstatistik/?jahr=abc")
        response_list = self.request_method("get", "export/exporte/einsatzauflistung/?jahr=abc")

        self.assertEqual(response_stat.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response_list.status_code, status.HTTP_400_BAD_REQUEST)
