from datetime import datetime, timedelta

from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Count, Q

from core_apps.common.permissions import HasAnyRolePermission
from core_apps.konfiguration.models import Konfiguration
from core_apps.konfiguration.serializers import KonfigurationSerializer
from core_apps.modul_konfiguration.models import ModulKonfiguration
from core_apps.modul_konfiguration.serializers import ModulKonfigurationSerializer
from core_apps.mitglieder.models import Mitglied
from core_apps.einsatzberichte.models import Einsatzbericht


def _format_time_hhmm(value):
    if not value:
        return ""
    return value.strftime("%H:%M")


def _duration_in_hours(start_time, end_time):
    if not start_time or not end_time:
        return None

    start_dt = datetime.combine(datetime.min.date(), start_time)
    end_dt = datetime.combine(datetime.min.date(), end_time)

    if end_dt < start_dt:
        end_dt += timedelta(days=1)

    duration_hours = (end_dt - start_dt).total_seconds() / 3600
    return round(duration_hours, 2)


def _extract_last_name(full_name):
    cleaned = str(full_name or "").strip()
    if not cleaned:
        return ""
    parts = cleaned.split()
    return parts[-1]


class ExportContextView(APIView):
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN", "EXPORT")]

    def get(self, request, *args, **kwargs):
        modul_konfig = ModulKonfigurationSerializer(ModulKonfiguration.objects.all(), many=True).data
        konfig = KonfigurationSerializer(Konfiguration.objects.all(), many=True).data
        return Response({"modul_konfig": modul_konfig, "konfig": konfig})


class ExportStandeslisteView(APIView):
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN", "EXPORT")]

    def get(self, request, *args, **kwargs):
        aktive_mitglieder = (
            Mitglied.objects.filter(dienststatus=Mitglied.Dienststatus.AKTIV)
            .order_by("stbnr", "nachname", "vorname")
        )

        payload = [
            {
                "stbnr": mitglied.stbnr,
                "dienstgrad": mitglied.dienstgrad,
                "name": f"{mitglied.vorname} {mitglied.nachname}".strip(),
            }
            for mitglied in aktive_mitglieder
        ]

        return Response(payload)


class ExportEinsatzstatistikView(APIView):
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN", "EXPORT")]

    def get(self, request, *args, **kwargs):
        jahr_raw = str(request.query_params.get("jahr", "")).strip()
        if not jahr_raw.isdigit() or len(jahr_raw) != 4:
            return Response(
                {"detail": "Bitte ein gueltiges Jahr (YYYY) angeben."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        jahr = int(jahr_raw)
        aktive_mitglieder = (
            Mitglied.objects.exclude(dienststatus__in=[Mitglied.Dienststatus.ABGEMELDET, Mitglied.Dienststatus.RESERVE])
            .annotate(
                einsaetze_anzahl=Count(
                    "einsatzberichte",
                    filter=Q(einsatzberichte__einsatz_datum__year=jahr),
                    distinct=True,
                )
            )
            .order_by("stbnr", "nachname", "vorname")
        )

        payload = [
            {
                "stbnr": mitglied.stbnr,
                "name": f"{mitglied.vorname} {mitglied.nachname}".strip(),
                "einsaetze": int(mitglied.einsaetze_anzahl or 0),
            }
            for mitglied in aktive_mitglieder
        ]

        return Response(payload)


class ExportEinsatzauflistungView(APIView):
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN", "EXPORT")]

    def get(self, request, *args, **kwargs):
        jahr_raw = str(request.query_params.get("jahr", "")).strip()
        if not jahr_raw.isdigit() or len(jahr_raw) != 4:
            return Response(
                {"detail": "Bitte ein gueltiges Jahr (YYYY) angeben."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        jahr = int(jahr_raw)
        einsaetze = (
            Einsatzbericht.objects.filter(einsatz_datum__year=jahr)
            .annotate(
                mitglieder_anzahl=Count("mitglieder", distinct=True),
                fahrzeuge_anzahl=Count("fahrzeuge", distinct=True),
            )
            .order_by("einsatz_datum", "pkid")
        )

        payload = [
            {
                "id": str(einsatz.id),
                "einsatz_datum": einsatz.einsatz_datum.isoformat() if einsatz.einsatz_datum else "",
                "alarmstichwort": einsatz.alarmstichwort,
                "einsatzart": einsatz.einsatzart,
                "einsatzadresse": einsatz.einsatzadresse,
                "einsatzleiter": einsatz.einsatzleiter,
                "einsatzleiter_nachname": _extract_last_name(einsatz.einsatzleiter),
                "alarmierende_stelle": einsatz.alarmierende_stelle,
                "status": einsatz.status,
                "alarmiert_zeit": _format_time_hhmm(einsatz.ausgerueckt),
                "dauer_stunden": _duration_in_hours(einsatz.ausgerueckt, einsatz.eingerueckt),
                "mitglieder_anzahl": int(einsatz.mitglieder_anzahl or 0),
                "fahrzeuge_anzahl": int(einsatz.fahrzeuge_anzahl or 0),
            }
            for einsatz in einsaetze
        ]

        return Response(payload)
