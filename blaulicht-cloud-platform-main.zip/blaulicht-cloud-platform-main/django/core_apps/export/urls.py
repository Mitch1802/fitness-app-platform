from django.urls import path

from .views import (
    ExportContextView,
    ExportStandeslisteView,
    ExportEinsatzstatistikView,
    ExportEinsatzauflistungView,
)


urlpatterns = [
    path("context/", ExportContextView.as_view(), name="export-context"),
    path("exporte/standesliste/", ExportStandeslisteView.as_view(), name="export-standesliste"),
    path("exporte/einsatzstatistik/", ExportEinsatzstatistikView.as_view(), name="export-einsatzstatistik"),
    path("exporte/einsatzauflistung/", ExportEinsatzauflistungView.as_view(), name="export-einsatzauflistung"),
]
