from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("messgeraete", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="messgeraetprotokoll",
            name="notiz",
            field=models.CharField(blank=True, max_length=1000, null=True, verbose_name="Notiz"),
        ),
    ]
