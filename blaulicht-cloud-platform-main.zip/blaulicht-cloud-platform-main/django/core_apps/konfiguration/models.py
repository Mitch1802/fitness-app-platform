from django.db import models
from django.utils.translation import gettext_lazy as _

from core_apps.common.models import TimeStampedModel


class Konfiguration(TimeStampedModel):
    fw_nummer = models.CharField(verbose_name=_("Feuerwehr Nummer"), max_length=255, unique=True, default="")
    fw_name =  models.CharField(verbose_name=_("Feuerwehr Name"), max_length=255, default="")
    fw_street =  models.CharField(verbose_name=_("Feuerwehr Straße"), max_length=255, default="")
    fw_plz =  models.CharField(verbose_name=_("Feuerwehr PLZ"), max_length=255, default="")
    fw_ort =  models.CharField(verbose_name=_("Feuerwehr Ort"), max_length=255, default="")
    fw_email =  models.CharField(verbose_name=_("Feuerwehr Email"), max_length=255, default="")
    fw_telefon =  models.CharField(verbose_name=_("Feuerwehr Telefon"), max_length=255, default="")
    fw_kdt =  models.CharField(verbose_name=_("Feuerwehr Kommandant"), max_length=255, default="")
    fw_webseite =  models.CharField(verbose_name=_("Feuerwehr Webseite"), max_length=255, default="")
    fw_konto =  models.CharField(verbose_name=_("Feuerwehr Konto"), max_length=255, default="")
    fw_iban =  models.CharField(verbose_name=_("Feuerwehr IBAN"), max_length=255, default="")
    fw_bic =  models.CharField(verbose_name=_("Feuerwehr BIC"), max_length=255, default="")

    # E-Mail Benachrichtigungen je Fachbereich (je 2 Kontakte)
    email_atemschutz_1 = models.CharField(verbose_name=_("Atemschutz E-Mail Kontakt 1"), max_length=255, default="", blank=True)
    email_atemschutz_2 = models.CharField(verbose_name=_("Atemschutz E-Mail Kontakt 2"), max_length=255, default="", blank=True)
    email_fahrzeuge_1 = models.CharField(verbose_name=_("Fahrzeuge E-Mail Kontakt 1 (Fahrmeister)"), max_length=255, default="", blank=True)
    email_fahrzeuge_2 = models.CharField(verbose_name=_("Fahrzeuge E-Mail Kontakt 2 (Fahrmeister)"), max_length=255, default="", blank=True)
    email_inventar_1 = models.CharField(verbose_name=_("FahrzeugInventar & Inventar E-Mail Kontakt 1 (Zeugmeister)"), max_length=255, default="", blank=True)
    email_inventar_2 = models.CharField(verbose_name=_("FahrzeugInventar & Inventar E-Mail Kontakt 2 (Zeugmeister)"), max_length=255, default="", blank=True)

    def __str__(self):
        return f"{self.fw_name}"
