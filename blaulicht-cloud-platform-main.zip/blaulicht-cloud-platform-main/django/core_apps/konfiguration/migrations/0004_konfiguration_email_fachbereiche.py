from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('konfiguration', '0003_konfiguration_fw_bic_konfiguration_fw_email_and_more'),
    ]

    operations = [
        migrations.AddField(
            model_name='konfiguration',
            name='email_atemschutz_1',
            field=models.CharField(blank=True, default='', max_length=255, verbose_name='Atemschutz E-Mail Kontakt 1'),
        ),
        migrations.AddField(
            model_name='konfiguration',
            name='email_atemschutz_2',
            field=models.CharField(blank=True, default='', max_length=255, verbose_name='Atemschutz E-Mail Kontakt 2'),
        ),
        migrations.AddField(
            model_name='konfiguration',
            name='email_fahrzeuge_1',
            field=models.CharField(blank=True, default='', max_length=255, verbose_name='Fahrzeuge E-Mail Kontakt 1 (Fahrmeister)'),
        ),
        migrations.AddField(
            model_name='konfiguration',
            name='email_fahrzeuge_2',
            field=models.CharField(blank=True, default='', max_length=255, verbose_name='Fahrzeuge E-Mail Kontakt 2 (Fahrmeister)'),
        ),
        migrations.AddField(
            model_name='konfiguration',
            name='email_inventar_1',
            field=models.CharField(blank=True, default='', max_length=255, verbose_name='FahrzeugInventar & Inventar E-Mail Kontakt 1 (Zeugmeister)'),
        ),
        migrations.AddField(
            model_name='konfiguration',
            name='email_inventar_2',
            field=models.CharField(blank=True, default='', max_length=255, verbose_name='FahrzeugInventar & Inventar E-Mail Kontakt 2 (Zeugmeister)'),
        ),
    ]
