from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('konfiguration', '0005_konfiguration_email_stammdaten'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='konfiguration',
            name='email_stammdaten',
        ),
    ]
