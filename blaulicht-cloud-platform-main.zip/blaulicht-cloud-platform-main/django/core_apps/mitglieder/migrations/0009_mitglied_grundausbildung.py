from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("mitglieder", "0008_remove_mitglied_jugend_fields"),
    ]

    operations = [
        migrations.AddField(
            model_name="mitglied",
            name="grundausbildung",
            field=models.BooleanField(default=False, verbose_name="Grundausbildung"),
        ),
    ]
