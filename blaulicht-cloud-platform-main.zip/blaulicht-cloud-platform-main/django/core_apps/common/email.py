import logging
from urllib.parse import quote

from django.conf import settings
from django.core.mail import send_mail

logger = logging.getLogger(__name__)


def build_invite_url(token: str, request=None) -> str:
    if request is not None:
        base = request.build_absolute_uri("/").rstrip("/")
    else:
        base = ""
    if not base:
        logger.warning("build_invite_url: kein request übergeben, Einladungs-URL kann nicht gebaut werden.")
        return ""
    return f"{base}/einladung?token={quote(token)}"


def send_account_invite_email(username: str, email: str, invite_url: str, first_name: str = "") -> bool:
    """
    Sendet eine Einladungs-E-Mail mit einmaligem Link zur Passwortvergabe.

    Returns True wenn die E-Mail erfolgreich gesendet wurde, sonst False.
    """
    if not email:
        logger.warning("Einladungs-E-Mail konnte nicht gesendet werden: keine E-Mail-Adresse für Benutzer '%s'.", username)
        return False

    if not invite_url:
        logger.warning("Einladungs-E-Mail konnte nicht gesendet werden: kein Invite-Link für Benutzer '%s'.", username)
        return False

    greeting = f"Hallo {first_name}," if first_name else "Hallo,"
    subject = "Einladung zur Blaulicht Cloud"
    message = (
        f"{greeting}\n\n"
        f"für dein Konto '{username}' wurde eine Einladung erstellt.\n"
        f"Bitte vergib dein Passwort über diesen Link:\n\n"
        f"{invite_url}\n\n"
        f"Hinweis: Der Link ist zeitlich begrenzt und nach der Passwortvergabe ungültig.\n\n"
        f"Mit freundlichen Grüßen\n"
        f"Dein Blaulicht Cloud Team"
    )

    try:
        send_mail(
            subject=subject,
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[email],
            fail_silently=False,
        )
        logger.info("Einladungs-E-Mail an '%s' gesendet.", email)
        return True
    except Exception:
        logger.exception("Fehler beim Senden der Einladungs-E-Mail an '%s'.", email)
        return False


def send_service_reminder_email(recipient_email: str, items: list[dict], fw_name: str = "", days: int = 30) -> bool:
    """
    Sendet eine Erinnerungs-E-Mail für bald fällige Services/Wartungen.

    ``items`` ist eine Liste von Dicts mit den Schlüsseln:
        - modul: str
        - bereich: str
        - eintrag: str
        - intervall: str
        - faelligkeit: str
        - status: str

    ``days`` gibt den Erinnerungszeitraum an, der in der E-Mail erwähnt wird.

    Returns True wenn die E-Mail erfolgreich gesendet wurde, sonst False.
    """
    if not recipient_email:
        logger.warning("Service-Erinnerungs-E-Mail konnte nicht gesendet werden: keine Empfänger-Adresse.")
        return False

    if not items:
        return False

    org = f" ({fw_name})" if fw_name else ""
    subject = f"Wartungs- & Service-Erinnerung{org}"

    lines = [
        f"Folgende Einträge sind in den nächsten {days} Tagen fällig{org}:\n",
        f"{'Modul':<20} {'Bereich':<12} {'Eintrag':<40} {'Intervall':<25} {'Fälligkeit':<12} Status",
        "-" * 120,
    ]
    for item in items:
        lines.append(
            f"{item.get('modul', ''):<20} "
            f"{item.get('bereich', ''):<12} "
            f"{item.get('eintrag', ''):<40} "
            f"{item.get('intervall', ''):<25} "
            f"{item.get('faelligkeit', ''):<12} "
            f"{item.get('status', '')}"
        )

    lines.append("\nBitte prüfe und plane die notwendigen Maßnahmen rechtzeitig.")
    lines.append("\nMit freundlichen Grüßen\nDein Blaulicht Cloud Team")

    message = "\n".join(lines)

    try:
        send_mail(
            subject=subject,
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[recipient_email],
            fail_silently=False,
        )
        logger.info("Service-Erinnerungs-E-Mail mit %d Einträgen an '%s' gesendet.", len(items), recipient_email)
        return True
    except Exception:
        logger.exception("Fehler beim Senden der Service-Erinnerungs-E-Mail an '%s'.", recipient_email)
        return False


def send_einsatzbericht_test_email(recipient_email: str, fw_name: str = "") -> bool:
    """
    Sendet eine Test-E-Mail fuer den Einsatzbericht-Versand.

    Returns True wenn die E-Mail erfolgreich gesendet wurde, sonst False.
    """
    if not recipient_email:
        logger.warning("Einsatzbericht-Test-E-Mail konnte nicht gesendet werden: keine Empfaenger-Adresse.")
        return False

    org = f" ({fw_name})" if fw_name else ""
    subject = f"Einsatzbericht Versand-Test{org}"
    message = (
        "Dies ist eine Test-E-Mail fuer den Einsatzbericht-Versand.\n\n"
        "Wenn diese E-Mail ankommt, ist der Mailversand fuer gesendete Einsatzberichte korrekt konfiguriert.\n\n"
        "Mit freundlichen Gruessen\n"
        "Dein Blaulicht Cloud Team"
    )

    try:
        send_mail(
            subject=subject,
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[recipient_email],
            fail_silently=False,
        )
        logger.info("Einsatzbericht-Test-E-Mail an '%s' gesendet.", recipient_email)
        return True
    except Exception:
        logger.exception("Fehler beim Senden der Einsatzbericht-Test-E-Mail an '%s'.", recipient_email)
        return False


def send_service_expiry_7_days_email(recipient_emails: list[str], items: list[dict], fw_name: str = "") -> bool:
    """
    Sendet eine Erinnerungs-E-Mail 7 Tage vor Ablauf eines Services/Wartung an Fachbereich-Emails.

    ``items`` ist eine Liste von Dicts mit den Schlüsseln:
        - bereich: str (z.B. 'Inventar', 'Fahrzeuge', 'Atemschutz')
        - name: str (Name des Objekts)
        - faellig_am: str (Datum im Format YYYY-MM-DD)

    ``recipient_emails`` ist eine Liste von Email-Adressen (z.B. Fachbereich-Kontakte).

    Returns True wenn die E-Mail erfolgreich gesendet wurde, sonst False.
    """
    if not recipient_emails:
        logger.warning("Service-Ablauf-E-Mail (7 Tage) konnte nicht gesendet werden: keine Empfänger-Adressen.")
        return False

    if not items:
        return False

    org = f" ({fw_name})" if fw_name else ""
    subject = f"Wartung fällig in 7 Tagen{org}"

    lines = [
        "Hallo,\n",
        f"folgende Wartungen/Services fallen in 7 Tagen an{org}:\n",
        "",
        f"{'Bereich':<20} {'Objekt':<50} {'Fällig am':<12}",
        "-" * 85,
    ]
    for item in items:
        lines.append(
            f"{item.get('bereich', ''):<20} "
            f"{item.get('name', ''):<50} "
            f"{item.get('faellig_am', ''):<12}"
        )

    lines.extend([
        "",
        "Bitte planen Sie die notwendige Wartung frühzeitig ein.",
        "",
        "Mit freundlichen Grüßen",
        "Dein Blaulicht Cloud Team"
    ])

    message = "\n".join(lines)

    try:
        send_mail(
            subject=subject,
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=recipient_emails,
            fail_silently=False,
        )
        logger.info("Service-Ablauf-E-Mail (7 Tage) mit %d Einträgen an %d Empfänger gesendet.", len(items), len(recipient_emails))
        return True
    except Exception:
        logger.exception("Fehler beim Senden der Service-Ablauf-E-Mail (7 Tage) an %s.", recipient_emails)
        return False


def send_service_expiry_14_days_after_email(recipient_email: str, items: list[dict], fw_name: str = "") -> bool:
    """
    Sendet eine Erinnerungs-E-Mail 14 Tage nach Ablauf eines Services/Wartung an die zentrale Stammdaten-Email.

    ``items`` ist eine Liste von Dicts mit den Schlüsseln:
        - bereich: str (z.B. 'Inventar', 'Fahrzeuge', 'Atemschutz')
        - name: str (Name des Objekts)
        - faellig_am: str (Datum im Format YYYY-MM-DD)
        - fachbereich_email: str (Email-Adresse des zuständigen Fachbereichs)

    Returns True wenn die E-Mail erfolgreich gesendet wurde, sonst False.
    """
    if not recipient_email:
        logger.warning("Service-Ablauf-E-Mail (14 Tage nachher) konnte nicht gesendet werden: keine Empfänger-Adresse.")
        return False

    if not items:
        return False

    org = f" ({fw_name})" if fw_name else ""
    subject = f"🔴 Wartung überfällig - 14 Tage nach Ablauf{org}"

    lines = [
        "Sehr geehrte Damen und Herren,\n",
        f"folgende Wartungen/Services sind bereits 14 Tage überfällig{org}:\n",
        "",
        f"{'Bereich':<20} {'Objekt':<50} {'War fällig am':<12} {'Fachbereich-Email':<30}",
        "-" * 115,
    ]
    for item in items:
        lines.append(
            f"{item.get('bereich', ''):<20} "
            f"{item.get('name', ''):<50} "
            f"{item.get('faellig_am', ''):<12} "
            f"{item.get('fachbereich_email', ''):<30}"
        )

    lines.extend([
        "",
        "Diese Wartungen sollten dringend durchgeführt oder geklärt werden.",
        "Bitte kontaktieren Sie die zuständigen Fachbereichs-Emails für weitere Informationen.",
        "",
        "Mit freundlichen Grüßen",
        "Dein Blaulicht Cloud Team"
    ])

    message = "\n".join(lines)

    try:
        send_mail(
            subject=subject,
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[recipient_email],
            fail_silently=False,
        )
        logger.info("Service-Ablauf-E-Mail (14 Tage nachher) mit %d Einträgen an '%s' gesendet.", len(items), recipient_email)
        return True
    except Exception:
        logger.exception("Fehler beim Senden der Service-Ablauf-E-Mail (14 Tage nachher) an '%s'.", recipient_email)
        return False
