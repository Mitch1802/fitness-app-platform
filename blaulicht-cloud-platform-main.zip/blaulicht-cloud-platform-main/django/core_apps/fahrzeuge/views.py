import logging

from django.conf import settings
from django.core import signing
from django.db import transaction
from django.db.models import Prefetch
from django.shortcuts import get_object_or_404

from rest_framework import viewsets, permissions, status
from rest_framework.parsers import JSONParser, MultiPartParser, FormParser
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle

from core_apps.common.permissions import HasAnyRolePermission, HasReadOnlyRolePermission, any_of
from core_apps.aufgaben.models import create_or_reopen_ticket
from core_apps.homepage.models import HomepageDienstposten

from .models import Fahrzeug, FahrzeugRaum, RaumItem, FahrzeugCheck, FahrzeugCheckItem
from .serializers import (
    FahrzeugListSerializer,
    FahrzeugDetailSerializer,
    FahrzeugCrudSerializer,
    FahrzeugRaumSerializer,
    FahrzeugRaumCrudSerializer,
    RaumItemSerializer,
    RaumItemCrudSerializer,
    FahrzeugPublicListSerializer,
    FahrzeugPublicDetailSerializer,
    FahrzeugCheckCreateSerializer,
    FahrzeugCheckHistorySerializer,
    FahrzeugInventarFlatItemSerializer,
    FahrzeugInventarFlatItemWriteSerializer,
)


logger = logging.getLogger(__name__)


def _get_responsible_zeugmeister_user():
    dienstposten = (
        HomepageDienstposten.objects
        .select_related("mitglied__benutzer")
        .filter(
            position__icontains="zeugmeister",
            mitglied__benutzer__isnull=False,
            mitglied__benutzer__is_active=True,
        )
        .order_by("section_order", "position_order", "pkid")
        .first()
    )
    if not dienstposten or not dienstposten.mitglied:
        return None
    return dienstposten.mitglied.benutzer


def _build_problem_ticket_description(*, fahrzeug, check, validated_results, item_map) -> str:
    problem_results = [r for r in validated_results if r["status"] != FahrzeugCheckItem.Status.OK]
    lines = [
        f"Beim internen Fahrzeug-Check wurden {len(problem_results)} Maengel gefunden.",
        f"Fahrzeug: {fahrzeug.name}",
        f"Check-Titel: {check.title}",
    ]
    if check.notiz:
        lines.append(f"Check-Notiz: {check.notiz}")

    lines.append("")
    lines.append("Problempositionen:")

    status_label_map = dict(FahrzeugCheckItem.Status.choices)
    for result in problem_results:
        item = item_map[result["item_id"]]
        status_label = status_label_map.get(result["status"], result["status"])
        parts = [f"- {item.raum.name} - {item.name}", f"Status: {status_label}"]
        if result.get("menge_aktuel") is not None:
            parts.append(f"Ist: {result['menge_aktuel']} {item.einheit}".strip())
        if result.get("notiz"):
            parts.append(f"Notiz: {result['notiz']}")
        lines.append(" | ".join(parts))

    return "\n".join(lines)


def _create_problem_ticket_if_needed(*, request_user, fahrzeug, check, validated_results, item_map):
    problem_results = [r for r in validated_results if r["status"] != FahrzeugCheckItem.Status.OK]
    if not problem_results:
        return

    zustaendiger_user = _get_responsible_zeugmeister_user()
    beschreibung = _build_problem_ticket_description(
        fahrzeug=fahrzeug,
        check=check,
        validated_results=validated_results,
        item_map=item_map,
    )

    ticket_title = f"Fahrzeug-Check Mangel: {fahrzeug.name}"
    if check.title:
        ticket_title = f"{ticket_title} ({check.title})"

    create_or_reopen_ticket(
        titel=ticket_title,
        melder=request_user,
        zustaendiger_user=zustaendiger_user,
        beschreibung=beschreibung,
        quelle_modul="fahrzeuge_check_intern",
        quelle_referenz=str(check.id),
    )


def _is_default(name: str) -> bool:
    return not name


def _safe_delete(storage, name: str):
    try:
        storage.delete(name)
    except Exception:
        # Cleanup darf keinen Request abbrechen.
        logger.exception("Datei '%s' konnte beim Cleanup nicht gelöscht werden.", name)


# ==========================================================
# Public Token (globaler PIN -> Token ist NICHT an Fahrzeug gebunden)
# ==========================================================
def make_public_token() -> str:
    payload = {"scope": "public_readonly"}
    return signing.dumps(payload, salt="fahrzeug_public_pin_v2")


def read_public_token(token: str) -> dict | None:
    try:
        ttl_min = getattr(settings, "PUBLIC_TOKEN_TTL_MIN", 60)
        return signing.loads(
            token,
            salt="fahrzeug_public_pin_v2",
            max_age=ttl_min * 60,
        )
    except (signing.BadSignature, signing.SignatureExpired, TypeError, ValueError):
        return None


class PublicPinVerifyView(APIView):
    authentication_classes = []
    permission_classes = [permissions.AllowAny]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "public_pin_verify"

    def post(self, request):
        pin = str(request.data.get("pin", "")).strip()
        if not pin:
            return Response({"detail": "PIN fehlt."}, status=status.HTTP_400_BAD_REQUEST)

        if not getattr(settings, "PUBLIC_PIN_ENABLED", False):
            return Response({"detail": "PIN ist deaktiviert."}, status=status.HTTP_403_FORBIDDEN)

        if pin != getattr(settings, "PUBLIC_FAHRZEUG_PIN", ""):
            return Response({"detail": "PIN falsch."}, status=status.HTTP_403_FORBIDDEN)

        ttl_min = getattr(settings, "PUBLIC_TOKEN_TTL_MIN", 60)
        return Response({"access_token": make_public_token(), "expires_in": ttl_min * 60})


class PublicFahrzeugDetailView(APIView):
    authentication_classes = []
    permission_classes = [permissions.AllowAny]

    def get(self, request, public_id: str):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return Response({"detail": "Token fehlt."}, status=status.HTTP_401_UNAUTHORIZED)

        token = auth.removeprefix("Bearer ").strip()
        payload = read_public_token(token)
        if not payload or payload.get("scope") != "public_readonly":
            return Response({"detail": "Token ungültig/abgelaufen."}, status=status.HTTP_401_UNAUTHORIZED)

        fahrzeug = get_object_or_404(
            Fahrzeug.objects.prefetch_related("raeume__items"),
            public_id=public_id,
        )
        return Response(FahrzeugPublicDetailSerializer(fahrzeug).data)


class PublicFahrzeugListView(APIView):
    authentication_classes = []
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return Response({"detail": "Token fehlt."}, status=status.HTTP_401_UNAUTHORIZED)

        token = auth.removeprefix("Bearer ").strip()
        payload = read_public_token(token)
        if not payload or payload.get("scope") != "public_readonly":
            return Response({"detail": "Token ungültig/abgelaufen."}, status=status.HTTP_401_UNAUTHORIZED)

        fahrzeuge = Fahrzeug.objects.all().order_by("reihenfolge", "name", "bezeichnung", "pkid")
        return Response(FahrzeugPublicListSerializer(fahrzeuge, many=True).data)


class PublicFahrzeugWebsiteListView(APIView):
    authentication_classes = []
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        fahrzeuge = Fahrzeug.objects.all().order_by("reihenfolge", "name", "bezeichnung", "pkid")
        return Response(FahrzeugPublicListSerializer(fahrzeuge, many=True).data)


# ==========================================================
# Auth CRUD: Fahrzeuge
# ==========================================================
class FahrzeugViewSet(viewsets.ModelViewSet):
    permission_classes = [
        permissions.IsAuthenticated,
        any_of(
            HasAnyRolePermission.with_roles("ADMIN", "FAHRZEUG"),
            HasReadOnlyRolePermission.with_roles("MITGLIED"),
        ),
    ]
    queryset = Fahrzeug.objects.prefetch_related("raeume__items").order_by("reihenfolge", "name", "bezeichnung", "pkid")
    lookup_field = "id"  # UUID aus TimeStampedModel
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    def get_serializer_class(self):
        if self.action == "list":
            return FahrzeugListSerializer
        if self.action == "retrieve":
            return FahrzeugDetailSerializer
        return FahrzeugCrudSerializer

    def perform_update(self, serializer):
        instance = self.get_object()
        old_name = instance.foto.name if getattr(instance, "foto", None) else None
        saved = serializer.save()
        new_name = saved.foto.name if getattr(saved, "foto", None) else None

        if old_name and old_name != new_name and not _is_default(old_name):
            _safe_delete(saved.foto.storage, old_name)

    def perform_destroy(self, instance):
        name = instance.foto.name if getattr(instance, "foto", None) else None
        super().perform_destroy(instance)

        if name and not _is_default(name):
            _safe_delete(instance.foto.storage, name)


# ==========================================================
# Nested: Räume
# ==========================================================
class FahrzeugRaumViewSet(viewsets.ModelViewSet):
    permission_classes = [
        permissions.IsAuthenticated,
        HasAnyRolePermission.with_roles("ADMIN", "FAHRZEUG"),
    ]
    lookup_field = "id"
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    def get_queryset(self):
        return FahrzeugRaum.objects.filter(fahrzeug__id=self.kwargs["fahrzeug_id"]).order_by("reihenfolge", "pkid")

    def get_serializer_class(self):
        if self.action in ("list", "retrieve"):
            return FahrzeugRaumSerializer
        return FahrzeugRaumCrudSerializer

    def perform_create(self, serializer):
        fahrzeug = get_object_or_404(Fahrzeug, id=self.kwargs["fahrzeug_id"])
        serializer.save(fahrzeug=fahrzeug)

    def perform_update(self, serializer):
        instance = self.get_object()
        old_name = instance.foto.name if getattr(instance, "foto", None) else None
        saved = serializer.save()
        new_name = saved.foto.name if getattr(saved, "foto", None) else None

        if old_name and old_name != new_name and not _is_default(old_name):
            _safe_delete(saved.foto.storage, old_name)

    def perform_destroy(self, instance):
        name = instance.foto.name if getattr(instance, "foto", None) else None
        super().perform_destroy(instance)

        if name and not _is_default(name):
            _safe_delete(instance.foto.storage, name)


# ==========================================================
# Nested: Items
# ==========================================================
class RaumItemViewSet(viewsets.ModelViewSet):
    permission_classes = [
        permissions.IsAuthenticated,
        HasAnyRolePermission.with_roles("ADMIN", "FAHRZEUG"),
    ]
    lookup_field = "id"

    def get_queryset(self):
        return RaumItem.objects.filter(raum__id=self.kwargs["raum_id"]).order_by("reihenfolge", "pkid")

    def get_serializer_class(self):
        if self.action in ("list", "retrieve"):
            return RaumItemSerializer
        return RaumItemCrudSerializer

    def perform_create(self, serializer):
        raum = get_object_or_404(FahrzeugRaum, id=self.kwargs["raum_id"])
        serializer.save(raum=raum)


# ==========================================================
# Check speichern (Auth)
# ==========================================================
class FahrzeugCheckCreateView(APIView):
    permission_classes = [
        permissions.IsAuthenticated,
        HasAnyRolePermission.with_roles("ADMIN", "FAHRZEUG", "MITGLIED"),
    ]

    def post(self, request, fahrzeug_id):
        ser = FahrzeugCheckCreateSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        fahrzeug = get_object_or_404(Fahrzeug, id=fahrzeug_id)

        item_ids = [r["item_id"] for r in ser.validated_data["results"]]

        # Items müssen zu diesem Fahrzeug gehören -> Filter über raum__fahrzeug_id
        items = RaumItem.objects.select_related("raum").filter(
            id__in=item_ids,
            raum__fahrzeug_id=fahrzeug.pkid,
        )
        item_map = {i.id: i for i in items}

        bulk_data = []
        for r in ser.validated_data["results"]:
            item = item_map.get(r["item_id"])
            if not item:
                return Response(
                    {"detail": f"Item {r['item_id']} gehört nicht zu diesem Fahrzeug."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            bulk_data.append(
                {
                    "item": item,
                    "status": r["status"],
                    "menge_aktuel": r.get("menge_aktuel"),
                    "notiz": r.get("notiz", ""),
                }
            )

        with transaction.atomic():
            check = FahrzeugCheck.objects.create(
                fahrzeug=fahrzeug,
                title=ser.validated_data["title"],
                notiz=ser.validated_data.get("notiz", ""),
            )

            bulk = [
                FahrzeugCheckItem(
                    fahrzeug_check=check,
                    item=entry["item"],
                    status=entry["status"],
                    menge_aktuel=entry["menge_aktuel"],
                    notiz=entry["notiz"],
                )
                for entry in bulk_data
            ]
            FahrzeugCheckItem.objects.bulk_create(bulk)

            _create_problem_ticket_if_needed(
                request_user=request.user,
                fahrzeug=fahrzeug,
                check=check,
                validated_results=ser.validated_data["results"],
                item_map=item_map,
            )

        return Response({"id": str(check.id)}, status=status.HTTP_201_CREATED)


class FahrzeugCheckHistoryListView(APIView):
    permission_classes = [
        permissions.IsAuthenticated,
        HasAnyRolePermission.with_roles("ADMIN", "FAHRZEUG"),
    ]

    def get(self, _request, fahrzeug_id):
        fahrzeug = get_object_or_404(Fahrzeug, id=fahrzeug_id)

        checks = (
            FahrzeugCheck.objects
            .filter(fahrzeug=fahrzeug)
            .prefetch_related(
                Prefetch(
                    "results",
                    queryset=(
                        FahrzeugCheckItem.objects
                        .exclude(status=FahrzeugCheckItem.Status.OK)
                        .select_related("item__raum")
                        .order_by("pkid")
                    ),
                    to_attr="problem_results",
                )
            )
            .order_by("-created_at", "-pkid")
        )

        serializer = FahrzeugCheckHistorySerializer(checks, many=True)
        return Response(serializer.data)


class FahrzeugCheckDetailView(APIView):
    permission_classes = [
        permissions.IsAuthenticated,
        HasAnyRolePermission.with_roles("ADMIN", "FAHRZEUG"),
    ]

    def get_object(self, fahrzeug_id, check_id):
        return get_object_or_404(
            FahrzeugCheck.objects.filter(fahrzeug__id=fahrzeug_id),
            id=check_id,
        )

    def delete(self, _request, fahrzeug_id, check_id):
        check = self.get_object(fahrzeug_id, check_id)
        check.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


# ==========================================================
# Fahrzeug Inventar – flache Liste aller Items über alle Fahrzeuge
# ==========================================================
class FahrzeugInventarFlatListView(APIView):
    permission_classes = [
        permissions.IsAuthenticated,
        HasAnyRolePermission.with_roles("ADMIN", "FAHRZEUG"),
    ]

    def get(self, _request):
        items = (
            RaumItem.objects
            .select_related("raum__fahrzeug")
            .order_by("raum__fahrzeug__name", "raum__reihenfolge", "reihenfolge", "pkid")
        )
        serializer = FahrzeugInventarFlatItemSerializer(items, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = FahrzeugInventarFlatItemWriteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        item = serializer.save()
        return Response(FahrzeugInventarFlatItemSerializer(item).data, status=status.HTTP_201_CREATED)


class FahrzeugInventarFlatDetailView(APIView):
    permission_classes = [
        permissions.IsAuthenticated,
        HasAnyRolePermission.with_roles("ADMIN", "FAHRZEUG"),
    ]

    def get_object(self, item_id):
        return get_object_or_404(
            RaumItem.objects.select_related("raum__fahrzeug"),
            id=item_id,
        )

    def patch(self, request, item_id):
        item = self.get_object(item_id)
        serializer = FahrzeugInventarFlatItemWriteSerializer(item, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        updated = serializer.save()
        return Response(FahrzeugInventarFlatItemSerializer(updated).data)

    def delete(self, _request, item_id):
        item = self.get_object(item_id)
        item.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
