from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("fahrzeuge", "0007_raumitem_bereich_raumitem_unterinventar"),
    ]

    operations = [
        migrations.AddField(
            model_name="fahrzeug",
            name="reihenfolge",
            field=models.PositiveIntegerField(default=0, verbose_name="Reihenfolge"),
        ),
    ]