from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("fahrzeuge", "0006_fahrzeug_pickerl_naechstes_am_and_more"),
    ]

    operations = [
        migrations.AddField(
            model_name="raumitem",
            name="bereich",
            field=models.CharField(blank=True, default="", max_length=180, verbose_name="Bereich"),
        ),
        migrations.AddField(
            model_name="raumitem",
            name="unterinventar",
            field=models.JSONField(blank=True, default=list, verbose_name="Unterinventar"),
        ),
    ]
