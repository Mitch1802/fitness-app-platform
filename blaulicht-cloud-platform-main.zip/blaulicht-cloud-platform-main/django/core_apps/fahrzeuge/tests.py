from uuid import uuid4
from unittest.mock import patch, Mock
from types import SimpleNamespace

from dj_rest_auth.app_settings import api_settings as rest_auth_settings
from rest_framework import status
from rest_framework.test import APITestCase

from core_apps.common.test_helpers import EndpointSmokeMixin
from core_apps.aufgaben.models import AufgabenTicket
from core_apps.fahrzeuge.models import Fahrzeug, FahrzeugRaum, RaumItem, FahrzeugCheck, FahrzeugCheckItem
from core_apps.homepage.models import HomepageDienstposten
from core_apps.mitglieder.models import Mitglied
from core_apps.fahrzeuge.views import make_public_token
from core_apps.fahrzeuge.views import PublicFahrzeugDetailView
from core_apps.fahrzeuge.views import (
    read_public_token,
    PublicPinVerifyView,
    PublicFahrzeugListView,
    PublicFahrzeugWebsiteListView,
    FahrzeugViewSet,
    FahrzeugRaumViewSet,
    RaumItemViewSet,
)
from core_apps.fahrzeuge.serializers import (
    FahrzeugListSerializer,
    FahrzeugDetailSerializer,
    FahrzeugCrudSerializer,
    FahrzeugRaumSerializer,
    FahrzeugRaumCrudSerializer,
    RaumItemSerializer,
    RaumItemCrudSerializer,
)


class FahrzeugeEndpointTests(EndpointSmokeMixin, APITestCase):
    def setUp(self):
        self.admin = self.create_user_with_roles("ADMIN")
        self.member = self.create_user_with_roles("MITGLIED")
        self.fahrzeug_role_user = self.create_user_with_roles("FAHRZEUG")

        self.fahrzeug = Fahrzeug.objects.create(name="TLF", bezeichnung="Tankwagen", reihenfolge=20)
        self.fahrzeug_early = Fahrzeug.objects.create(name="HLF", bezeichnung="Hilfeleistung", reihenfolge=10)
        self.raum = FahrzeugRaum.objects.create(fahrzeug=self.fahrzeug, name="R1", reihenfolge=1)
        self.item = RaumItem.objects.create(raum=self.raum, name="Helm", menge=1)

        self.zeugmeister_mitglied = Mitglied.objects.create(
            stbnr=9999,
            vorname="Zust",
            nachname="Zeugmeister",
            geburtsdatum="1990-01-01",
        )
        self.zeugmeister_user = self.create_user_with_roles("MITGLIED")
        self.zeugmeister_user.mitglied = self.zeugmeister_mitglied
        self.zeugmeister_user.save(update_fields=["mitglied"])

        HomepageDienstposten.objects.create(
            section_id="kommando",
            section_title="Kommando",
            section_order=1,
            position="Zeugmeister",
            position_order=1,
            mitglied=self.zeugmeister_mitglied,
            fallback_name="Zeugmeister",
        )

    def test_all_fahrzeuge_endpoints_resolve(self):
        fahrzeug_id = uuid4()
        raum_id = uuid4()
        item_id = uuid4()
        endpoints = [
            "public/pin/verify/",
            "public/fahrzeuge/",
            "public/fahrzeuge/liste/",
            "public/fahrzeuge/public-test-id/",
            "fahrzeuge/",
            f"fahrzeuge/{fahrzeug_id}/",
            f"fahrzeuge/{fahrzeug_id}/checks/",
            f"fahrzeuge/{fahrzeug_id}/checks/history/",
            f"fahrzeuge/{fahrzeug_id}/checks/{item_id}/",
            f"fahrzeuge/{fahrzeug_id}/raeume/",
            f"fahrzeuge/{fahrzeug_id}/raeume/{raum_id}/",
            f"raeume/{raum_id}/items/",
            f"raeume/{raum_id}/items/{item_id}/",
            "fahrzeug-inventar/",
            f"fahrzeug-inventar/{item_id}/",
        ]

        for endpoint in endpoints:
            with self.subTest(endpoint=endpoint):
                self.assert_options_works(endpoint)

    def test_fahrzeuge_public_pin_verify_is_public(self):
        response = self.request_method("post", "public/pin/verify/", data={"pin": "falsch"})
        self.assertIn(response.status_code, [403, 429])

    def test_fahrzeuge_public_pin_verify_rejects_missing_pin(self):
        response = self.request_method("post", "public/pin/verify/", data={})
        self.assertIn(response.status_code, [400, 429])

    def test_fahrzeuge_public_pin_verify_accepts_valid_pin(self):
        with patch("core_apps.fahrzeuge.views.settings.PUBLIC_PIN_ENABLED", True), patch(
            "core_apps.fahrzeuge.views.settings.PUBLIC_FAHRZEUG_PIN", "1234"
        ), patch("core_apps.fahrzeuge.views.PublicPinVerifyView.check_throttles", return_value=None):
            response = self.request_method("post", "public/pin/verify/", data={"pin": "1234"})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("access_token", response.data)

    def test_fahrzeuge_public_pin_verify_ignores_invalid_auth_cookie(self):
        if rest_auth_settings.JWT_AUTH_COOKIE:
            self.client.cookies[rest_auth_settings.JWT_AUTH_COOKIE] = "invalid.jwt.token"

        with patch("core_apps.fahrzeuge.views.settings.PUBLIC_PIN_ENABLED", True), patch(
            "core_apps.fahrzeuge.views.settings.PUBLIC_FAHRZEUG_PIN", "1234"
        ), patch("core_apps.fahrzeuge.views.PublicPinVerifyView.check_throttles", return_value=None):
            response = self.request_method("post", "public/pin/verify/", data={"pin": "1234"})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("access_token", response.data)

    def test_fahrzeuge_public_detail_requires_token_but_not_user_auth(self):
        self.assertEqual(
            self.request_method("get", "public/fahrzeuge/public-test-id/").status_code,
            401,
        )

    def test_fahrzeuge_public_list_requires_token_but_not_user_auth(self):
        self.assertEqual(
            self.request_method("get", "public/fahrzeuge/").status_code,
            401,
        )

    def test_fahrzeuge_public_website_list_is_allowany(self):
        response = self.request_method("get", "public/fahrzeuge/liste/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(len(response.data), 2)
        self.assertEqual(response.data[0]["name"], "HLF")
        self.assertEqual(response.data[0]["bezeichnung"], "Hilfeleistung")
        self.assertIn("foto_url", response.data[0])

    def test_fahrzeuge_public_detail_accepts_valid_token(self):
        request = SimpleNamespace(headers={"Authorization": "Bearer token"})
        with patch("core_apps.fahrzeuge.views.read_public_token", return_value={"scope": "public_readonly"}):
            response = PublicFahrzeugDetailView().get(request, public_id=self.fahrzeug.public_id)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["public_id"], self.fahrzeug.public_id)

    def test_fahrzeuge_public_list_accepts_valid_token(self):
        request = SimpleNamespace(headers={"Authorization": "Bearer token"})
        with patch("core_apps.fahrzeuge.views.read_public_token", return_value={"scope": "public_readonly"}):
            response = PublicFahrzeugListView().get(request)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(len(response.data), 2)
        self.assertIn("reihenfolge", response.data[0])
        self.assertEqual(response.data[0]["public_id"], self.fahrzeug_early.public_id)
        self.assertEqual(response.data[1]["public_id"], self.fahrzeug.public_id)

    def test_fahrzeuge_public_endpoints_ignore_invalid_auth_cookie_and_accept_public_token(self):
        if rest_auth_settings.JWT_AUTH_COOKIE:
            self.client.cookies[rest_auth_settings.JWT_AUTH_COOKIE] = "invalid.jwt.token"

        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {make_public_token()}")

        list_response = self.request_method("get", "public/fahrzeuge/")
        detail_response = self.request_method("get", f"public/fahrzeuge/{self.fahrzeug.public_id}/")

        self.assertEqual(list_response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(len(list_response.data), 1)
        self.assertEqual(detail_response.status_code, status.HTTP_200_OK)
        self.assertEqual(detail_response.data["public_id"], self.fahrzeug.public_id)

    def test_fahrzeuge_auth_endpoints_require_auth_and_role(self):
        self.assert_endpoint_contract("fahrzeuge/")
        self.assert_endpoint_contract(f"fahrzeuge/{uuid4()}/checks/", method="post", data={})

    def test_fahrzeug_role_user_can_list_fahrzeuge(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)

        response = self.request_method("get", "fahrzeuge/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("reihenfolge", response.data[0])

    def test_fahrzeuge_are_ordered_by_reihenfolge(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)

        response = self.request_method("get", "fahrzeuge/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(len(response.data), 2)
        self.assertEqual(response.data[0]["name"], "HLF")
        self.assertEqual(response.data[0]["reihenfolge"], 10)
        self.assertEqual(response.data[1]["name"], "TLF")
        self.assertEqual(response.data[1]["reihenfolge"], 20)

    def test_fahrzeuge_checks_reject_empty_results(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)

        response = self.request_method(
            "post",
            f"fahrzeuge/{self.fahrzeug.id}/checks/",
            data={"title": "Check", "results": []},
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_fahrzeuge_checks_reject_missing_title(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)

        response = self.request_method(
            "post",
            f"fahrzeuge/{self.fahrzeug.id}/checks/",
            data={
                "results": [{"item_id": str(self.item.id), "status": "ok"}],
            },
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_fahrzeuge_checks_reject_item_of_other_vehicle(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)

        other_vehicle = Fahrzeug.objects.create(name="LF")
        other_room = FahrzeugRaum.objects.create(fahrzeug=other_vehicle, name="R2", reihenfolge=1)
        foreign_item = RaumItem.objects.create(raum=other_room, name="Fremd", menge=1)

        response = self.request_method(
            "post",
            f"fahrzeuge/{self.fahrzeug.id}/checks/",
            data={
                "title": "Check",
                "results": [{"item_id": str(foreign_item.id), "status": "ok"}],
            },
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_fahrzeuge_checks_create_success(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)

        response = self.request_method(
            "post",
            f"fahrzeuge/{self.fahrzeug.id}/checks/",
            data={
                "title": "Check",
                "results": [{"item_id": str(self.item.id), "status": "ok", "notiz": "passt"}],
            },
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertIn("id", response.data)
        self.assertEqual(AufgabenTicket.objects.filter(quelle_modul="fahrzeuge_check_intern").count(), 0)

    def test_fahrzeuge_checks_create_problem_generates_ticket_for_zeugmeister(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)

        response = self.request_method(
            "post",
            f"fahrzeuge/{self.fahrzeug.id}/checks/",
            data={
                "title": "Monatscheck",
                "notiz": "Interner Rundgang",
                "results": [
                    {"item_id": str(self.item.id), "status": "missing", "menge_aktuel": "0", "notiz": "nicht vorhanden"}
                ],
            },
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        ticket = AufgabenTicket.objects.get(
            quelle_modul="fahrzeuge_check_intern",
            quelle_referenz=response.data["id"],
        )
        self.assertEqual(ticket.melder_id, self.fahrzeug_role_user.pk)
        self.assertEqual(ticket.zustaendiger_user_id, self.zeugmeister_user.pk)
        self.assertIn("Maengel gefunden", ticket.beschreibung)
        self.assertIn("R1 - Helm", ticket.beschreibung)

    def test_fahrzeuge_checks_history_lists_only_problem_items(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)

        ok_check = FahrzeugCheck.objects.create(fahrzeug=self.fahrzeug, title="OK Check")
        FahrzeugCheckItem.objects.create(
            fahrzeug_check=ok_check,
            item=self.item,
            status=FahrzeugCheckItem.Status.OK,
            notiz="alles gut",
        )

        problem_check = FahrzeugCheck.objects.create(fahrzeug=self.fahrzeug, title="Problem Check", notiz="Kontrolle")
        FahrzeugCheckItem.objects.create(
            fahrzeug_check=problem_check,
            item=self.item,
            status=FahrzeugCheckItem.Status.MISSING,
            menge_aktuel=0,
            notiz="fehlt",
        )

        response = self.request_method("get", f"fahrzeuge/{self.fahrzeug.id}/checks/history/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)
        self.assertEqual(response.data[0]["title"], "Problem Check")
        self.assertEqual(response.data[0]["problem_count"], 1)
        self.assertEqual(len(response.data[0]["problem_items"]), 1)
        self.assertEqual(response.data[1]["title"], "OK Check")
        self.assertEqual(response.data[1]["problem_count"], 0)
        self.assertEqual(response.data[1]["problem_items"], [])

    def test_fahrzeuge_checks_history_forbidden_for_mitglied(self):
        self.client.force_authenticate(user=self.member)

        response = self.request_method("get", f"fahrzeuge/{self.fahrzeug.id}/checks/history/")

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_fahrzeuge_checks_delete_success_for_fahrzeug_role(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)
        check = FahrzeugCheck.objects.create(fahrzeug=self.fahrzeug, title="Delete Me")

        response = self.request_method("delete", f"fahrzeuge/{self.fahrzeug.id}/checks/{check.id}/")

        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(FahrzeugCheck.objects.filter(id=check.id).exists())

    def test_fahrzeuge_checks_delete_rejects_other_vehicle(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)
        other = Fahrzeug.objects.create(name="LF")
        check = FahrzeugCheck.objects.create(fahrzeug=other, title="Fremd")

        response = self.request_method("delete", f"fahrzeuge/{self.fahrzeug.id}/checks/{check.id}/")

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_fahrzeuge_checks_delete_forbidden_for_mitglied(self):
        self.client.force_authenticate(user=self.member)
        check = FahrzeugCheck.objects.create(fahrzeug=self.fahrzeug, title="Delete")

        response = self.request_method("delete", f"fahrzeuge/{self.fahrzeug.id}/checks/{check.id}/")

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_fahrzeuge_method_matrix_no_server_error(self):
        fahrzeug_id = uuid4()
        raum_id = uuid4()
        item_id = uuid4()
        for endpoint in [
            "public/pin/verify/",
            "public/fahrzeuge/",
            "public/fahrzeuge/liste/",
            "public/fahrzeuge/public-test-id/",
            "fahrzeuge/",
            f"fahrzeuge/{fahrzeug_id}/",
            f"fahrzeuge/{fahrzeug_id}/checks/",
            f"fahrzeuge/{fahrzeug_id}/checks/history/",
            f"fahrzeuge/{fahrzeug_id}/checks/{item_id}/",
            f"fahrzeuge/{fahrzeug_id}/raeume/",
            f"fahrzeuge/{fahrzeug_id}/raeume/{raum_id}/",
            f"raeume/{raum_id}/items/",
            f"raeume/{raum_id}/items/{item_id}/",
            "fahrzeug-inventar/",
            f"fahrzeug-inventar/{item_id}/",
        ]:
            self.assert_method_matrix_no_server_error(endpoint)

    def test_fahrzeug_inventar_flat_crud(self):
        self.client.force_authenticate(user=self.fahrzeug_role_user)

        list_response = self.request_method("get", "fahrzeug-inventar/")
        self.assertEqual(list_response.status_code, status.HTTP_200_OK)

        create_response = self.request_method(
            "post",
            "fahrzeug-inventar/",
            data={
                "raum_id": str(self.raum.id),
                "name": "Handschuhe",
                "menge": "4",
                "einheit": "Paar",
                "reihenfolge": 5,
            },
        )
        self.assertEqual(create_response.status_code, status.HTTP_201_CREATED)
        created_id = create_response.data["id"]

        patch_response = self.request_method(
            "patch",
            f"fahrzeug-inventar/{created_id}/",
            data={"name": "Handschuhe Nitril", "menge": "6"},
        )
        self.assertEqual(patch_response.status_code, status.HTTP_200_OK)
        self.assertEqual(patch_response.data["name"], "Handschuhe Nitril")

        delete_response = self.request_method("delete", f"fahrzeug-inventar/{created_id}/")
        self.assertEqual(delete_response.status_code, status.HTTP_204_NO_CONTENT)


class FahrzeugeBranchCoverageTests(APITestCase):
    def setUp(self):
        self.fahrzeug = Fahrzeug.objects.create(name="TLF-B")
        self.raum = FahrzeugRaum.objects.create(fahrzeug=self.fahrzeug, name="R1", reihenfolge=1)
        self.item = RaumItem.objects.create(raum=self.raum, name="Schlauch", menge=2)

    def test_public_detail_invalid_scope_and_token_reader(self):
        request = SimpleNamespace(headers={"Authorization": "Bearer token"})
        with patch("core_apps.fahrzeuge.views.read_public_token", return_value={"scope": "other"}):
            response = PublicFahrzeugDetailView().get(request, public_id=self.fahrzeug.public_id)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

        self.assertIsNone(read_public_token("defekt"))

    def test_public_pin_verify_missing_and_disabled(self):
        view = PublicPinVerifyView()

        missing_pin = view.post(SimpleNamespace(data={}))
        self.assertEqual(missing_pin.status_code, status.HTTP_400_BAD_REQUEST)

        with patch("core_apps.fahrzeuge.views.settings.PUBLIC_PIN_ENABLED", False):
            disabled = view.post(SimpleNamespace(data={"pin": "1234"}))
        self.assertEqual(disabled.status_code, status.HTTP_403_FORBIDDEN)

        with patch("core_apps.fahrzeuge.views.settings.PUBLIC_PIN_ENABLED", True), patch(
            "core_apps.fahrzeuge.views.settings.PUBLIC_FAHRZEUG_PIN", "1234"
        ):
            wrong_pin = view.post(SimpleNamespace(data={"pin": "9999"}))
        self.assertEqual(wrong_pin.status_code, status.HTTP_403_FORBIDDEN)

    def test_fahrzeug_viewset_serializer_selection(self):
        view = FahrzeugViewSet()
        view.action = "list"
        self.assertEqual(view.get_serializer_class(), FahrzeugListSerializer)
        view.action = "retrieve"
        self.assertEqual(view.get_serializer_class(), FahrzeugDetailSerializer)
        view.action = "create"
        self.assertEqual(view.get_serializer_class(), FahrzeugCrudSerializer)

    def test_public_fahrzeug_website_list_view_is_public(self):
        request = SimpleNamespace(headers={})
        response = PublicFahrzeugWebsiteListView().get(request)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(len(response.data), 1)

    def test_fahrzeug_raum_viewset_paths(self):
        view = FahrzeugRaumViewSet()
        view.kwargs = {"fahrzeug_id": self.fahrzeug.id}
        ids = list(view.get_queryset().values_list("id", flat=True))
        self.assertIn(self.raum.id, ids)

        view.action = "list"
        self.assertEqual(view.get_serializer_class(), FahrzeugRaumSerializer)
        view.action = "create"
        self.assertEqual(view.get_serializer_class(), FahrzeugRaumCrudSerializer)

        serializer = SimpleNamespace(save=Mock())
        view.perform_create(serializer)
        serializer.save.assert_called_once()

    def test_raum_item_viewset_paths(self):
        view = RaumItemViewSet()
        view.kwargs = {"raum_id": self.raum.id}
        ids = list(view.get_queryset().values_list("id", flat=True))
        self.assertIn(self.item.id, ids)

        view.action = "retrieve"
        self.assertEqual(view.get_serializer_class(), RaumItemSerializer)
        view.action = "create"
        self.assertEqual(view.get_serializer_class(), RaumItemCrudSerializer)

        serializer = SimpleNamespace(save=Mock())
        view.perform_create(serializer)
        serializer.save.assert_called_once()

    def test_fahrzeug_crud_serializer_validates_service_window(self):
        serializer = FahrzeugCrudSerializer(
            data={
                "name": "HLF 20",
                "service_zuletzt_am": "2026-03-10",
                "service_naechstes_am": "2026-03-01",
            }
        )

        self.assertFalse(serializer.is_valid())
        self.assertIn("service_naechstes_am", serializer.errors)

    def test_fahrzeug_crud_serializer_validates_pickerl_window(self):
        serializer = FahrzeugCrudSerializer(
            data={
                "name": "HLF 20",
                "pickerl_zuletzt_am": "2026-03-10",
                "pickerl_naechstes_am": "2026-03-01",
            }
        )

        self.assertFalse(serializer.is_valid())
        self.assertIn("pickerl_naechstes_am", serializer.errors)

    def test_raum_item_crud_serializer_validates_wartung_window(self):
        serializer = RaumItemCrudSerializer(
            data={
                "name": "Prueflampe",
                "menge": "1",
                "einheit": "Stk",
                "notiz": "",
                "reihenfolge": 0,
                "wartung_zuletzt_am": "2026-03-10",
                "wartung_naechstes_am": "2026-03-01",
            }
        )

        self.assertFalse(serializer.is_valid())
        self.assertIn("wartung_naechstes_am", serializer.errors)
