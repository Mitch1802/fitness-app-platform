import os
import re

from django.db.models import Max
from rest_framework import serializers

from .models import Fahrzeug, FahrzeugRaum, RaumItem, FahrzeugCheck, FahrzeugCheckItem


def _foto_url(obj) -> str | None:
    foto = getattr(obj, "foto", None)
    try:
        return foto.url if foto and getattr(foto, "name", "") else None
    except Exception:
        return None


def _sanitize_upload_filename(file):
    if not file:
        return file

    name = getattr(file, "name", "") or "upload"
    name = name.strip()
    if "." not in name or name.lower().endswith((".blob", ".octet-stream")):
        content_type = (getattr(file, "content_type", "") or "image/png").lower()
        ext = content_type.split("/")[-1]
        if ext not in {"jpg", "jpeg", "png"}:
            ext = "png"
        file.name = f"upload.{ext}"
    else:
        base = os.path.basename(name)
        file.name = re.sub(r"[^\w.\-]+", "_", base)

    return file


def _validate_date_window(attrs, instance, from_key: str, to_key: str):
    from_value = attrs.get(from_key, getattr(instance, from_key, None) if instance else None)
    to_value = attrs.get(to_key, getattr(instance, to_key, None) if instance else None)

    if from_value and to_value and to_value < from_value:
        raise serializers.ValidationError({
            to_key: "Das naechste Datum darf nicht vor dem zuletzt erledigten Datum liegen."
        })


def _normalize_unterinventar(value):
    if value is None:
        return []
    if not isinstance(value, list):
        raise serializers.ValidationError("Unterinventar muss eine Liste sein.")

    normalized = []
    for entry in value:
        if isinstance(entry, dict):
            name = str(entry.get("name", "")).strip()
            if not name:
                continue
            menge_raw = entry.get("menge", 1)
            try:
                menge = float(menge_raw)
            except (TypeError, ValueError):
                raise serializers.ValidationError("Unterinventar-Menge muss eine Zahl sein.")
            if menge <= 0:
                raise serializers.ValidationError("Unterinventar-Menge muss größer als 0 sein.")
            normalized.append({"name": name, "menge": menge})
            continue

        name = str(entry or "").strip()
        if name:
            normalized.append({"name": name, "menge": 1})

    return normalized


# =========================
# LIST
# =========================
class FahrzeugListSerializer(serializers.ModelSerializer):
    foto_url = serializers.SerializerMethodField(read_only=True)

    def get_foto_url(self, obj):
        return _foto_url(obj)

    class Meta:
        model = Fahrzeug
        fields = [
            "id",
            "name",
            "bezeichnung",
            "reihenfolge",
            "public_id",
            "service_zuletzt_am",
            "service_naechstes_am",
            "pickerl_zuletzt_am",
            "pickerl_naechstes_am",
            "foto_url",
        ]


# =========================
# PUBLIC (PIN) -> ohne IDs von Items/Rooms? (du wolltest public ohne IDs – ok)
# =========================
class RaumItemPublicSerializer(serializers.ModelSerializer):
    class Meta:
        model = RaumItem
        fields = [
            "name",
            "bereich",
            "menge",
            "einheit",
            "notiz",
            "unterinventar",
            "reihenfolge",
            "wartung_zuletzt_am",
            "wartung_naechstes_am",
        ]


class FahrzeugRaumPublicSerializer(serializers.ModelSerializer):
    items = RaumItemPublicSerializer(many=True, read_only=True)
    foto_url = serializers.SerializerMethodField(read_only=True)

    def get_foto_url(self, obj):
        return _foto_url(obj)

    class Meta:
        model = FahrzeugRaum
        fields = ["name", "reihenfolge", "foto_url", "items"]


class FahrzeugPublicDetailSerializer(serializers.ModelSerializer):
    raeume = FahrzeugRaumPublicSerializer(many=True, read_only=True)
    foto_url = serializers.SerializerMethodField(read_only=True)

    def get_foto_url(self, obj):
        return _foto_url(obj)

    class Meta:
        model = Fahrzeug
        fields = [
            "name",
            "bezeichnung",
            "reihenfolge",
            "beschreibung",
            "public_id",
            "service_zuletzt_am",
            "service_naechstes_am",
            "pickerl_zuletzt_am",
            "pickerl_naechstes_am",
            "foto_url",
            "raeume",
        ]


class FahrzeugPublicListSerializer(serializers.ModelSerializer):
    foto_url = serializers.SerializerMethodField(read_only=True)

    def get_foto_url(self, obj):
        return _foto_url(obj)

    class Meta:
        model = Fahrzeug
        fields = [
            "name",
            "bezeichnung",
            "reihenfolge",
            "public_id",
            "foto_url",
        ]


# =========================
# AUTH DETAIL (MIT IDs, damit Checks möglich sind)
# =========================
class RaumItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = RaumItem
        fields = [
            "id",
            "name",
            "bereich",
            "menge",
            "einheit",
            "notiz",
            "unterinventar",
            "reihenfolge",
            "wartung_zuletzt_am",
            "wartung_naechstes_am",
        ]


class FahrzeugRaumSerializer(serializers.ModelSerializer):
    items = RaumItemSerializer(many=True, read_only=True)
    foto_url = serializers.SerializerMethodField(read_only=True)

    def get_foto_url(self, obj):
        return _foto_url(obj)

    class Meta:
        model = FahrzeugRaum
        fields = ["id", "name", "reihenfolge", "foto_url", "items"]


class FahrzeugDetailSerializer(serializers.ModelSerializer):
    raeume = FahrzeugRaumSerializer(many=True, read_only=True)
    foto_url = serializers.SerializerMethodField(read_only=True)

    def get_foto_url(self, obj):
        return _foto_url(obj)

    class Meta:
        model = Fahrzeug
        fields = [
            "id",
            "name",
            "bezeichnung",
            "reihenfolge",
            "beschreibung",
            "public_id",
            "service_zuletzt_am",
            "service_naechstes_am",
            "pickerl_zuletzt_am",
            "pickerl_naechstes_am",
            "foto_url",
            "raeume",
        ]


# =========================
# CRUD (Fahrzeug / Raum / Item)
# =========================
class FahrzeugCrudSerializer(serializers.ModelSerializer):
    foto = serializers.ImageField(required=False, allow_null=True)
    foto_url = serializers.SerializerMethodField(read_only=True)
    remove_foto = serializers.BooleanField(required=False, write_only=True, default=False)

    def get_foto_url(self, obj):
        return _foto_url(obj)

    def validate_foto(self, file):
        return _sanitize_upload_filename(file)

    def validate(self, attrs):
        _validate_date_window(attrs, self.instance, "service_zuletzt_am", "service_naechstes_am")
        _validate_date_window(attrs, self.instance, "pickerl_zuletzt_am", "pickerl_naechstes_am")
        return attrs

    def create(self, validated_data):
        foto = validated_data.pop("foto", None)
        validated_data.pop("remove_foto", None)
        instance = Fahrzeug.objects.create(**validated_data)
        if foto:
            instance.foto = foto
            instance.save(update_fields=["foto"])
        return instance

    def update(self, instance, validated_data):
        foto = validated_data.pop("foto", serializers.empty)
        remove_foto = validated_data.pop("remove_foto", False)
        instance = super().update(instance, validated_data)

        if remove_foto:
            if instance.foto and instance.foto.name:
                instance.foto.delete(save=False)
            instance.foto = None
            instance.save(update_fields=["foto"])
        elif foto is not serializers.empty:
            instance.foto = foto
            instance.save(update_fields=["foto"])

        return instance

    class Meta:
        model = Fahrzeug
        fields = [
            "id",
            "name",
            "bezeichnung",
            "reihenfolge",
            "beschreibung",
            "service_zuletzt_am",
            "service_naechstes_am",
            "pickerl_zuletzt_am",
            "pickerl_naechstes_am",
            "foto",
            "foto_url",
            "remove_foto",
        ]


class FahrzeugRaumCrudSerializer(serializers.ModelSerializer):
    foto = serializers.ImageField(required=False, allow_null=True)
    foto_url = serializers.SerializerMethodField(read_only=True)
    remove_foto = serializers.BooleanField(required=False, write_only=True, default=False)

    def get_foto_url(self, obj):
        return _foto_url(obj)

    def validate_foto(self, file):
        return _sanitize_upload_filename(file)

    def create(self, validated_data):
        foto = validated_data.pop("foto", None)
        validated_data.pop("remove_foto", None)
        instance = FahrzeugRaum.objects.create(**validated_data)
        if foto:
            instance.foto = foto
            instance.save(update_fields=["foto"])
        return instance

    def update(self, instance, validated_data):
        foto = validated_data.pop("foto", serializers.empty)
        remove_foto = validated_data.pop("remove_foto", False)
        instance = super().update(instance, validated_data)

        if remove_foto:
            if instance.foto and instance.foto.name:
                instance.foto.delete(save=False)
            instance.foto = None
            instance.save(update_fields=["foto"])
        elif foto is not serializers.empty:
            instance.foto = foto
            instance.save(update_fields=["foto"])

        return instance

    class Meta:
        model = FahrzeugRaum
        fields = ["id", "name", "reihenfolge", "foto", "foto_url", "remove_foto"]


class RaumItemCrudSerializer(serializers.ModelSerializer):
    def validate_unterinventar(self, value):
        return _normalize_unterinventar(value)

    def validate(self, attrs):
        _validate_date_window(attrs, self.instance, "wartung_zuletzt_am", "wartung_naechstes_am")
        return attrs

    class Meta:
        model = RaumItem
        fields = [
            "id",
            "name",
            "bereich",
            "menge",
            "einheit",
            "notiz",
            "unterinventar",
            "reihenfolge",
            "wartung_zuletzt_am",
            "wartung_naechstes_am",
        ]


# =========================
# FAHRZEUG INVENTAR FLAT LIST
# =========================
class FahrzeugInventarFlatItemSerializer(serializers.ModelSerializer):
    fahrzeug_id = serializers.UUIDField(source="raum.fahrzeug.id", read_only=True)
    fahrzeug_name = serializers.CharField(source="raum.fahrzeug.name", read_only=True)
    raum_id = serializers.UUIDField(source="raum.id", read_only=True)
    raum_name = serializers.CharField(source="raum.name", read_only=True)

    class Meta:
        model = RaumItem
        fields = [
            "id",
            "fahrzeug_id",
            "fahrzeug_name",
            "raum_id",
            "raum_name",
            "name",
            "bereich",
            "menge",
            "einheit",
            "notiz",
            "unterinventar",
            "reihenfolge",
            "wartung_zuletzt_am",
            "wartung_naechstes_am",
        ]


class FahrzeugInventarFlatItemWriteSerializer(serializers.ModelSerializer):
    raum_id = serializers.UUIDField(write_only=True, required=False, allow_null=True)
    fahrzeug_id = serializers.UUIDField(write_only=True, required=False, allow_null=True)
    raum_name = serializers.CharField(write_only=True, required=False, allow_blank=True)

    def validate_unterinventar(self, value):
        return _normalize_unterinventar(value)

    def validate(self, attrs):
        _validate_date_window(attrs, self.instance, "wartung_zuletzt_am", "wartung_naechstes_am")

        raum_id = attrs.get("raum_id", None)
        raum_name = str(attrs.get("raum_name", "")).strip()

        if raum_id is None:
            if self.instance is not None and "raum_id" not in attrs and not raum_name:
                return attrs

            fahrzeug_id = attrs.get("fahrzeug_id", None)
            if fahrzeug_id is None:
                raise serializers.ValidationError({"fahrzeug_id": "Dieses Feld ist erforderlich, wenn kein Raum gesetzt ist."})
            if not raum_name:
                raise serializers.ValidationError({"raum_name": "Dieses Feld ist erforderlich, wenn kein Raum gesetzt ist."})

        return attrs

    def _resolve_raum(self, validated_data):
        raum_id = validated_data.pop("raum_id", None)
        fahrzeug_id = validated_data.pop("fahrzeug_id", None)
        raum_name = str(validated_data.pop("raum_name", "")).strip()

        if raum_id:
            try:
                return FahrzeugRaum.objects.get(id=raum_id)
            except FahrzeugRaum.DoesNotExist as exc:
                raise serializers.ValidationError({"raum_id": "Ungültiger Raum."}) from exc

        if fahrzeug_id is None or not raum_name:
            raise serializers.ValidationError({"raum_id": "Dieses Feld ist erforderlich."})

        try:
            fahrzeug = Fahrzeug.objects.get(id=fahrzeug_id)
        except Fahrzeug.DoesNotExist as exc:
            raise serializers.ValidationError({"fahrzeug_id": "Ungültiges Fahrzeug."}) from exc

        existing = FahrzeugRaum.objects.filter(fahrzeug=fahrzeug, name__iexact=raum_name).first()
        if existing:
            return existing

        max_order = FahrzeugRaum.objects.filter(fahrzeug=fahrzeug).aggregate(max_order=Max("reihenfolge")).get("max_order") or 0
        return FahrzeugRaum.objects.create(
            fahrzeug=fahrzeug,
            name=raum_name,
            reihenfolge=max_order + 1,
        )

    def create(self, validated_data):
        raum = self._resolve_raum(validated_data)
        return RaumItem.objects.create(raum=raum, **validated_data)

    def update(self, instance, validated_data):
        has_raum_payload = any(key in validated_data for key in ("raum_id", "fahrzeug_id", "raum_name"))
        if has_raum_payload:
            instance.raum = self._resolve_raum(validated_data)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance

    class Meta:
        model = RaumItem
        fields = [
            "raum_id",
            "fahrzeug_id",
            "raum_name",
            "name",
            "bereich",
            "menge",
            "einheit",
            "notiz",
            "unterinventar",
            "reihenfolge",
            "wartung_zuletzt_am",
            "wartung_naechstes_am",
        ]


# =========================
# CHECK CREATE
# =========================
class FahrzeugCheckItemCreateSerializer(serializers.Serializer):
    item_id = serializers.UUIDField()
    status = serializers.ChoiceField(choices=FahrzeugCheckItem.Status.choices)
    menge_aktuel = serializers.DecimalField(max_digits=10, decimal_places=2, required=False, allow_null=True)
    notiz = serializers.CharField(required=False, allow_blank=True)


class FahrzeugCheckCreateSerializer(serializers.Serializer):
    title = serializers.CharField(required=True, allow_blank=False)
    notiz = serializers.CharField(required=False, allow_blank=True)
    results = FahrzeugCheckItemCreateSerializer(many=True)

    def validate_title(self, value):
        normalized = str(value).strip()
        if not normalized:
            raise serializers.ValidationError("title darf nicht leer sein.")
        return normalized

    def validate(self, data):
        if not data.get("results"):
            raise serializers.ValidationError("results darf nicht leer sein.")
        return data


class FahrzeugCheckProblemItemSerializer(serializers.ModelSerializer):
    item_name = serializers.CharField(source="item.name", read_only=True)
    raum_name = serializers.CharField(source="item.raum.name", read_only=True)
    menge_soll = serializers.DecimalField(source="item.menge", max_digits=10, decimal_places=2, read_only=True)
    einheit = serializers.CharField(source="item.einheit", read_only=True)

    class Meta:
        model = FahrzeugCheckItem
        fields = [
            "id",
            "item_name",
            "raum_name",
            "status",
            "menge_soll",
            "menge_aktuel",
            "einheit",
            "notiz",
        ]


class FahrzeugCheckHistorySerializer(serializers.ModelSerializer):
    fahrzeug_name = serializers.CharField(source="fahrzeug.name", read_only=True)
    problem_count = serializers.SerializerMethodField(read_only=True)
    problem_items = serializers.SerializerMethodField(read_only=True)

    def get_problem_items(self, obj):
        problem_items = getattr(obj, "problem_results", None)
        if problem_items is None:
            problem_items = obj.results.exclude(status=FahrzeugCheckItem.Status.OK).select_related("item__raum")
        return FahrzeugCheckProblemItemSerializer(problem_items, many=True).data

    def get_problem_count(self, obj):
        problem_items = getattr(obj, "problem_results", None)
        if problem_items is None:
            return obj.results.exclude(status=FahrzeugCheckItem.Status.OK).count()
        return len(problem_items)

    class Meta:
        model = FahrzeugCheck
        fields = [
            "id",
            "fahrzeug_name",
            "title",
            "notiz",
            "created_at",
            "problem_count",
            "problem_items",
        ]
