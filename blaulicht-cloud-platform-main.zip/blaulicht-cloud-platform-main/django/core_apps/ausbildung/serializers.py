from rest_framework import serializers

from .models import AusbildungDatei, AusbildungThemenbereich


class AusbildungDateiSerializer(serializers.ModelSerializer):
    datei_url = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = AusbildungDatei
        fields = ["id", "dateiname", "datei_url", "created_at"]
        read_only_fields = ["id", "dateiname", "datei_url", "created_at"]

    def get_datei_url(self, obj):
        datei = getattr(obj, "datei", None)
        try:
            return datei.url if datei and getattr(datei, "name", "") else None
        except Exception:
            return None


class AusbildungThemenbereichSerializer(serializers.ModelSerializer):
    dateien = AusbildungDateiSerializer(many=True, read_only=True)

    class Meta:
        model = AusbildungThemenbereich
        fields = ["id", "pkid", "titel", "beschreibung", "dateien", "created_at", "updated_at"]
        read_only_fields = ["id", "pkid", "dateien", "created_at", "updated_at"]

    def create(self, validated_data):
        request = self.context.get("request")
        instance = AusbildungThemenbereich.objects.create(**validated_data)
        self._create_uploaded_dateien(request, instance)
        return instance

    def update(self, instance, validated_data):
        request = self.context.get("request")
        for key, value in validated_data.items():
            setattr(instance, key, value)
        instance.save()
        self._create_uploaded_dateien(request, instance)
        return instance

    def _create_uploaded_dateien(self, request, instance):
        if not request:
            return
        for f in request.FILES.getlist("dateien_upload"):
            AusbildungDatei.objects.create(
                themenbereich=instance,
                datei=f,
                dateiname=f.name,
            )


class AusbildungThemenbereichListSerializer(serializers.ModelSerializer):
    datei_anzahl = serializers.IntegerField(source="dateien.count", read_only=True)

    class Meta:
        model = AusbildungThemenbereich
        fields = ["id", "pkid", "titel", "beschreibung", "datei_anzahl", "created_at", "updated_at"]
        read_only_fields = ["id", "pkid", "datei_anzahl", "created_at", "updated_at"]
