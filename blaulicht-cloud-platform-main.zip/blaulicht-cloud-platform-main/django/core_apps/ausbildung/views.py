import logging
import os

from rest_framework import permissions, status
from rest_framework.decorators import action
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from core_apps.common.permissions import HasAnyRolePermission

from .models import AusbildungDatei, AusbildungThemenbereich
from .serializers import (
    AusbildungDateiSerializer,
    AusbildungThemenbereichListSerializer,
    AusbildungThemenbereichSerializer,
)

logger = logging.getLogger(__name__)


def _delete_themenbereich_directory(storage, themenbereich_id):
    folder_name = os.path.join("ausbildung", str(themenbereich_id))

    try:
        folder_path = storage.path(folder_name)
    except (AttributeError, NotImplementedError):
        return

    if not os.path.isdir(folder_path):
        return

    try:
        if os.listdir(folder_path):
            return
        os.rmdir(folder_path)
    except FileNotFoundError:
        return
    except OSError:
        logger.exception("Ausbildung-Ordner '%s' konnte nicht gelöscht werden.", folder_name)


class AusbildungThemenbereichViewSet(ModelViewSet):
    queryset = AusbildungThemenbereich.objects.prefetch_related("dateien").all()
    permission_classes = [
        permissions.IsAuthenticated,
        HasAnyRolePermission.with_roles("ADMIN", "AUSBILDUNG"),
    ]
    parser_classes = [JSONParser, MultiPartParser, FormParser]
    lookup_field = "id"
    pagination_class = None
    http_method_names = ["get", "post", "patch", "delete", "head", "options"]

    def get_serializer_class(self):
        if self.action == "list":
            return AusbildungThemenbereichListSerializer
        return AusbildungThemenbereichSerializer

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        datei_storage = AusbildungDatei._meta.get_field("datei").storage
        datei_files = [
            (d.datei.storage, d.datei.name)
            for d in instance.dateien.all()
            if getattr(d, "datei", None) and getattr(d.datei, "name", "")
        ]
        response = super().destroy(request, *args, **kwargs)
        for storage, name in datei_files:
            try:
                storage.delete(name)
            except Exception:
                logger.exception("Ausbildung-Datei '%s' konnte nicht gelöscht werden.", name)
        _delete_themenbereich_directory(datei_storage, instance.id)
        return response

    @action(detail=True, methods=["post"], url_path="dateien")
    def datei_hochladen(self, request, id=None):
        themenbereich = self.get_object()
        dateien_neu = []
        for f in request.FILES.getlist("dateien_upload"):
            datei_obj = AusbildungDatei.objects.create(
                themenbereich=themenbereich,
                datei=f,
                dateiname=f.name,
            )
            dateien_neu.append(datei_obj)
        serializer = AusbildungDateiSerializer(dateien_neu, many=True)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["delete"], url_path=r"dateien/(?P<datei_id>[^/.]+)")
    def datei_loeschen(self, request, id=None, datei_id=None):
        themenbereich = self.get_object()
        datei = themenbereich.dateien.filter(id=datei_id).first()
        if datei is None:
            return Response({"detail": "Datei nicht gefunden."}, status=status.HTTP_404_NOT_FOUND)

        storage = datei.datei.storage if datei.datei else None
        name = datei.datei.name if datei.datei else ""
        datei.delete()

        if storage and name:
            try:
                storage.delete(name)
            except Exception:
                logger.exception("Ausbildung-Datei '%s' konnte nicht gelöscht werden.", name)

        return Response(status=status.HTTP_204_NO_CONTENT)
