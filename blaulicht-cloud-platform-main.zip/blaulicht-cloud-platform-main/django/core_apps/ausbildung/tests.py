import uuid
from pathlib import Path
from tempfile import TemporaryDirectory

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import override_settings

from rest_framework import status
from rest_framework.test import APITestCase

from core_apps.common.test_helpers import EndpointSmokeMixin

from .models import AusbildungDatei, AusbildungThemenbereich


class AusbildungApiTests(EndpointSmokeMixin, APITestCase):
    def setUp(self):
        self.user_ausbildung = self.create_user_with_roles("AUSBILDUNG")
        self.user_mitglied = self.create_user_with_roles("MITGLIED")

        self.themenbereich = AusbildungThemenbereich.objects.create(
            titel="Testthema",
            beschreibung="Beschreibung für das Testthema",
        )

    def test_endpoints_resolve(self):
        endpoints = [
            "ausbildung/",
            f"ausbildung/{uuid.uuid4()}/",
        ]
        for endpoint in endpoints:
            with self.subTest(endpoint=endpoint):
                self.assert_options_works(endpoint)

    def test_requires_auth_and_role(self):
        self.assert_requires_authentication("ausbildung/")
        self.assert_forbidden_without_role("ausbildung/")

    def test_member_role_forbidden(self):
        self.client.force_authenticate(user=self.user_mitglied)
        response = self.request_method("get", "ausbildung/")
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_list_returns_themenbereiche(self):
        self.client.force_authenticate(user=self.user_ausbildung)
        response = self.request_method("get", "ausbildung/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        titel_list = [item.get("titel") for item in response.data]
        self.assertIn("Testthema", titel_list)

    def test_create_themenbereich(self):
        self.client.force_authenticate(user=self.user_ausbildung)
        response = self.request_method(
            "post",
            "ausbildung/",
            data={"titel": "Neues Thema", "beschreibung": "Kurze Beschreibung"},
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data.get("titel"), "Neues Thema")

    def test_patch_themenbereich(self):
        self.client.force_authenticate(user=self.user_ausbildung)
        endpoint = f"ausbildung/{self.themenbereich.id}/"
        response = self.client.patch(
            self.build_api_url(endpoint),
            data={"beschreibung": "Aktualisiert"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.themenbereich.refresh_from_db()
        self.assertEqual(self.themenbereich.beschreibung, "Aktualisiert")

    def test_delete_themenbereich(self):
        self.client.force_authenticate(user=self.user_ausbildung)
        endpoint = f"ausbildung/{self.themenbereich.id}/"
        response = self.client.delete(self.build_api_url(endpoint))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(AusbildungThemenbereich.objects.filter(id=self.themenbereich.id).exists())

    def test_delete_themenbereich_removes_media_directory(self):
        self.client.force_authenticate(user=self.user_ausbildung)

        with TemporaryDirectory() as media_root:
            with override_settings(MEDIA_ROOT=media_root):
                datei = AusbildungDatei.objects.create(
                    themenbereich=self.themenbereich,
                    datei=SimpleUploadedFile("unterlage.txt", b"test"),
                    dateiname="unterlage.txt",
                )
                datei_path = Path(datei.datei.path)
                themenbereich_dir = Path(media_root) / "ausbildung" / str(self.themenbereich.id)

                self.assertTrue(datei_path.exists())
                self.assertTrue(themenbereich_dir.exists())

                endpoint = f"ausbildung/{self.themenbereich.id}/"
                response = self.client.delete(self.build_api_url(endpoint))

                self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
                self.assertFalse(datei_path.exists())
                self.assertFalse(themenbereich_dir.exists())
