import os
import re

from django.db import models
from django.utils.translation import gettext_lazy as _

from core_apps.common.models import TimeStampedModel


def ausbildung_datei_path(instance, filename):
    filename = os.path.basename(filename or "datei")
    filename = re.sub(r"[^\w.\-]+", "_", filename)
    themenbereich_id = instance.themenbereich.id if instance.themenbereich_id else "neu"
    return os.path.join("ausbildung", str(themenbereich_id), filename)


class AusbildungThemenbereich(TimeStampedModel):
    titel = models.CharField(verbose_name=_("Titel"), max_length=255)
    beschreibung = models.TextField(verbose_name=_("Beschreibung"), blank=True)

    class Meta(TimeStampedModel.Meta):
        ordering = ["titel"]

    def __str__(self):
        return self.titel


class AusbildungDatei(TimeStampedModel):
    themenbereich = models.ForeignKey(
        AusbildungThemenbereich,
        on_delete=models.CASCADE,
        related_name="dateien",
        verbose_name=_("Themenbereich"),
    )
    datei = models.FileField(_("Datei"), upload_to=ausbildung_datei_path)
    dateiname = models.CharField(verbose_name=_("Dateiname"), max_length=255)

    class Meta(TimeStampedModel.Meta):
        ordering = ["dateiname"]

    def __str__(self):
        return f"{self.dateiname} ({self.themenbereich})"
