from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import AusbildungThemenbereichViewSet

router = DefaultRouter()
router.register(r"", AusbildungThemenbereichViewSet, basename="ausbildung")

urlpatterns = [
    path("", include(router.urls)),
]
