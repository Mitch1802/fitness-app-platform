import uuid

import django.db.models.deletion
from django.db import migrations, models

import core_apps.ausbildung.models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="AusbildungThemenbereich",
            fields=[
                ("pkid", models.BigAutoField(editable=False, primary_key=True, serialize=False, unique=True)),
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, unique=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("titel", models.CharField(max_length=255, verbose_name="Titel")),
                ("beschreibung", models.TextField(blank=True, verbose_name="Beschreibung")),
            ],
            options={
                "ordering": ["titel"],
                "abstract": False,
            },
        ),
        migrations.CreateModel(
            name="AusbildungDatei",
            fields=[
                ("pkid", models.BigAutoField(editable=False, primary_key=True, serialize=False, unique=True)),
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, unique=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "themenbereich",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="dateien",
                        to="ausbildung.ausbildungthemenbereich",
                        verbose_name="Themenbereich",
                    ),
                ),
                (
                    "datei",
                    models.FileField(
                        upload_to=core_apps.ausbildung.models.ausbildung_datei_path,
                        verbose_name="Datei",
                    ),
                ),
                ("dateiname", models.CharField(max_length=255, verbose_name="Dateiname")),
            ],
            options={
                "ordering": ["dateiname"],
                "abstract": False,
            },
        ),
    ]
