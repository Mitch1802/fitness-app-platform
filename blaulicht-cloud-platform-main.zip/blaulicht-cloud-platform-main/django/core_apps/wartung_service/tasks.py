"""
Celery tasks for service expiry notifications.
"""
import logging
from datetime import timedelta, date

from celery import shared_task
from django.db.models import Q
from django.utils import timezone

from core_apps.common.email import send_service_expiry_7_days_email, send_service_expiry_14_days_after_email
from core_apps.konfiguration.models import Konfiguration
from core_apps.inventar.models import Inventar
from core_apps.fahrzeuge.models import Fahrzeug, RaumItem
from core_apps.atemschutz_geraete.models import AtemschutzGeraet
from core_apps.messgeraete.models import Messgeraet
from core_apps.aufgaben.models import create_or_reopen_ticket
from core_apps.users.models import User

logger = logging.getLogger(__name__)


def _get_default_admin_user():
    return User.objects.filter(is_active=True, roles__key__iexact="ADMIN").order_by("date_joined").first()


def _create_or_update_critical_ticket(*, admin_user, reference: str, titel: str, beschreibung: str, faellig_am):
    if not admin_user:
        return

    create_or_reopen_ticket(
        titel=titel,
        melder=admin_user,
        zustaendiger_user=admin_user,
        beschreibung=beschreibung,
        zu_erledigen_bis=faellig_am,
        quelle_modul="wartung_service",
        quelle_referenz=reference,
    )


@shared_task(bind=True, max_retries=3)
def check_service_expiry(self):
    """
    Check for services expiring in 7 days or 14 days after expiry and send notification emails.
    
    This task runs daily at 5 AM.
    - Sends email 7 days before expiry to relevant fachbereich contacts
    - Sends email 14 days after expiry to central stammdaten email
    """
    try:
        logger.info("Starting service expiry check task...")
        
        # Get configuration
        try:
            config = Konfiguration.objects.first()
        except Exception as e:
            logger.error(f"Failed to fetch Konfiguration: {e}")
            return
        
        if not config:
            logger.warning("No Konfiguration found in database")
            return
        
        today = date.today()
        seven_days_later = today + timedelta(days=7)
        fourteen_days_ago = today - timedelta(days=14)
        admin_user = _get_default_admin_user()
        
        # Initialize lists for email items
        items_7_days_before = {
            'inventar': [],
            'fahrzeuge': [],
            'raumitems': [],
            'atemschutz': [],
            'messgeraete': []
        }
        items_14_days_after = {
            'inventar': [],
            'fahrzeuge': [],
            'raumitems': [],
            'atemschutz': [],
            'messgeraete': []
        }
        
        # ===== 7 TAGE VOR ABLAUF =====
        
        # Check Inventar (7 days before)
        inventar_7_days = Inventar.objects.filter(
            wartung_naechstes_am=seven_days_later,
            email_sent_7_days_before=False
        )
        for item in inventar_7_days:
            items_7_days_before['inventar'].append({
                'bereich': 'Inventar',
                'name': item.bezeichnung,
                'faellig_am': str(item.wartung_naechstes_am)
            })
            item.email_sent_7_days_before = True
            item.save(update_fields=['email_sent_7_days_before'])
        
        # Check Fahrzeug (7 days before)
        fahrzeuge_7_days = Fahrzeug.objects.filter(
            Q(service_naechstes_am=seven_days_later) | Q(pickerl_naechstes_am=seven_days_later),
            email_sent_7_days_before=False
        )
        for item in fahrzeuge_7_days:
            has_due_entry = False
            if item.service_naechstes_am == seven_days_later:
                items_7_days_before['fahrzeuge'].append({
                    'bereich': 'Fahrzeug',
                    'name': item.name,
                    'faellig_am': str(item.service_naechstes_am)
                })
                has_due_entry = True
            if item.pickerl_naechstes_am == seven_days_later:
                items_7_days_before['fahrzeuge'].append({
                    'bereich': 'Fahrzeug Pickerl',
                    'name': item.name,
                    'faellig_am': str(item.pickerl_naechstes_am)
                })
                has_due_entry = True
            if has_due_entry:
                item.email_sent_7_days_before = True
                item.save(update_fields=['email_sent_7_days_before'])
        
        # Check RaumItem (7 days before)
        raumitems_7_days = RaumItem.objects.filter(
            wartung_naechstes_am=seven_days_later,
            email_sent_7_days_before=False
        )
        for item in raumitems_7_days:
            items_7_days_before['raumitems'].append({
                'bereich': 'Fahrzeug-Inventar',
                'name': f"{item.raum.fahrzeug.name} - {item.raum.name} - {item.name}",
                'faellig_am': str(item.wartung_naechstes_am)
            })
            item.email_sent_7_days_before = True
            item.save(update_fields=['email_sent_7_days_before'])
        
        # Check AtemschutzGeraet (7 days before - if naechste_gue is a date)
        try:
            atemschutz_7_days = AtemschutzGeraet.objects.filter(
                email_sent_7_days_before=False
            )
            for item in atemschutz_7_days:
                # Try to parse naechste_gue as date if it's in format YYYY-MM-DD
                if item.naechste_gue:
                    try:
                        gue_date = timezone.datetime.strptime(item.naechste_gue, '%Y-%m-%d').date()
                        if gue_date == seven_days_later:
                            items_7_days_before['atemschutz'].append({
                                'bereich': 'Atemschutz-Gerät',
                                'name': f"{item.inv_nr} ({item.art})",
                                'faellig_am': item.naechste_gue
                            })
                            item.email_sent_7_days_before = True
                            item.save(update_fields=['email_sent_7_days_before'])
                    except ValueError:
                        pass  # naechste_gue is not a date, skip
        except Exception as e:
            logger.error(f"Error checking AtemschutzGeraet: {e}")
        
        # Check Messgeraet (7 days before)
        messgeraete_7_days = Messgeraet.objects.filter(
            email_sent_7_days_before=False
        )
        for item in messgeraete_7_days:
            # Messgeraet doesn't have a next maintenance date field by default
            # This is a placeholder for future functionality
            pass
        
        # Send 7-day reminder emails grouped by fachbereich
        if any([items_7_days_before['inventar'], items_7_days_before['fahrzeuge'], 
                items_7_days_before['raumitems'], items_7_days_before['atemschutz']]):
            
            all_items_7_days = (
                items_7_days_before['inventar'] + 
                items_7_days_before['fahrzeuge'] + 
                items_7_days_before['raumitems'] + 
                items_7_days_before['atemschutz']
            )
            
            # Send to Inventar contacts
            inventar_emails = [config.email_inventar_1, config.email_inventar_2]
            inventar_items = items_7_days_before['inventar'] + items_7_days_before['raumitems']
            if inventar_items and any(inventar_emails):
                send_service_expiry_7_days_email(
                    [e for e in inventar_emails if e],
                    inventar_items,
                    config.fw_name
                )
                logger.info(f"Sent 7-day reminder to Inventar contacts for {len(inventar_items)} items")
            
            # Send to Fahrzeuge contacts
            fahrzeuge_emails = [config.email_fahrzeuge_1, config.email_fahrzeuge_2]
            fahrzeuge_items = items_7_days_before['fahrzeuge']
            if fahrzeuge_items and any(fahrzeuge_emails):
                send_service_expiry_7_days_email(
                    [e for e in fahrzeuge_emails if e],
                    fahrzeuge_items,
                    config.fw_name
                )
                logger.info(f"Sent 7-day reminder to Fahrzeuge contacts for {len(fahrzeuge_items)} items")
            
            # Send to Atemschutz contacts
            atemschutz_emails = [config.email_atemschutz_1, config.email_atemschutz_2]
            atemschutz_items = items_7_days_before['atemschutz']
            if atemschutz_items and any(atemschutz_emails):
                send_service_expiry_7_days_email(
                    [e for e in atemschutz_emails if e],
                    atemschutz_items,
                    config.fw_name
                )
                logger.info(f"Sent 7-day reminder to Atemschutz contacts for {len(atemschutz_items)} items")
        
        # ===== 14 TAGE NACH ABLAUF =====
        
        # IDs to mark as sent only after successful 14-day email delivery
        sent_14_ids = {
            'inventar': [],
            'fahrzeuge': [],
            'raumitems': [],
            'atemschutz': []
        }

        # Check Inventar (14 days after or more)
        inventar_14_days = Inventar.objects.filter(
            wartung_naechstes_am__lte=fourteen_days_ago,
            email_sent_14_days_after=False
        )
        for item in inventar_14_days:
            items_14_days_after['inventar'].append({
                'bereich': 'Inventar',
                'name': item.bezeichnung,
                'faellig_am': str(item.wartung_naechstes_am),
                'fachbereich_email': f"{config.email_inventar_1}, {config.email_inventar_2}"
            })
            _create_or_update_critical_ticket(
                admin_user=admin_user,
                reference=f"inventar:{item.pkid}:wartung",
                titel=f"Kritisch ueberfaellige Wartung: Inventar {item.bezeichnung}",
                beschreibung=(
                    f"Inventar '{item.bezeichnung}' ist seit mindestens 14 Tagen ueberfaellig. "
                    f"Faellig am: {item.wartung_naechstes_am}."
                ),
                faellig_am=item.wartung_naechstes_am,
            )
            sent_14_ids['inventar'].append(item.pkid)
        
        # Check Fahrzeug (14 days after or more)
        fahrzeuge_14_days = Fahrzeug.objects.filter(
            Q(service_naechstes_am__lte=fourteen_days_ago) | Q(pickerl_naechstes_am__lte=fourteen_days_ago),
            email_sent_14_days_after=False
        )
        for item in fahrzeuge_14_days:
            has_due_entry = False
            if item.service_naechstes_am and item.service_naechstes_am <= fourteen_days_ago:
                items_14_days_after['fahrzeuge'].append({
                    'bereich': 'Fahrzeug',
                    'name': item.name,
                    'faellig_am': str(item.service_naechstes_am),
                    'fachbereich_email': f"{config.email_fahrzeuge_1}, {config.email_fahrzeuge_2}"
                })
                _create_or_update_critical_ticket(
                    admin_user=admin_user,
                    reference=f"fahrzeug:{item.pkid}:service",
                    titel=f"Kritisch ueberfaelliger Service: Fahrzeug {item.name}",
                    beschreibung=(
                        f"Fahrzeug '{item.name}' ist seit mindestens 14 Tagen ueberfaellig (Service). "
                        f"Faellig am: {item.service_naechstes_am}."
                    ),
                    faellig_am=item.service_naechstes_am,
                )
                has_due_entry = True
            if item.pickerl_naechstes_am and item.pickerl_naechstes_am <= fourteen_days_ago:
                items_14_days_after['fahrzeuge'].append({
                    'bereich': 'Fahrzeug Pickerl',
                    'name': item.name,
                    'faellig_am': str(item.pickerl_naechstes_am),
                    'fachbereich_email': f"{config.email_fahrzeuge_1}, {config.email_fahrzeuge_2}"
                })
                _create_or_update_critical_ticket(
                    admin_user=admin_user,
                    reference=f"fahrzeug:{item.pkid}:pickerl",
                    titel=f"Kritisch ueberfaelliges Pickerl: Fahrzeug {item.name}",
                    beschreibung=(
                        f"Fahrzeug '{item.name}' ist seit mindestens 14 Tagen ueberfaellig (Pickerl). "
                        f"Faellig am: {item.pickerl_naechstes_am}."
                    ),
                    faellig_am=item.pickerl_naechstes_am,
                )
                has_due_entry = True
            if has_due_entry:
                sent_14_ids['fahrzeuge'].append(item.pkid)
        
        # Check RaumItem (14 days after or more)
        raumitems_14_days = RaumItem.objects.filter(
            wartung_naechstes_am__lte=fourteen_days_ago,
            email_sent_14_days_after=False
        )
        for item in raumitems_14_days:
            items_14_days_after['raumitems'].append({
                'bereich': 'Fahrzeug-Inventar',
                'name': f"{item.raum.fahrzeug.name} - {item.raum.name} - {item.name}",
                'faellig_am': str(item.wartung_naechstes_am),
                'fachbereich_email': f"{config.email_inventar_1}, {config.email_inventar_2}"
            })
            _create_or_update_critical_ticket(
                admin_user=admin_user,
                reference=f"raumitem:{item.pkid}:wartung",
                titel=f"Kritisch ueberfaellige Wartung: Fahrzeug-Inventar {item.name}",
                beschreibung=(
                    f"Fahrzeug-Inventar '{item.raum.fahrzeug.name} / {item.raum.name} / {item.name}' "
                    f"ist seit mindestens 14 Tagen ueberfaellig. Faellig am: {item.wartung_naechstes_am}."
                ),
                faellig_am=item.wartung_naechstes_am,
            )
            sent_14_ids['raumitems'].append(item.pkid)
        
        # Check AtemschutzGeraet (14 days after)
        try:
            atemschutz_14_days = AtemschutzGeraet.objects.filter(
                email_sent_14_days_after=False
            )
            for item in atemschutz_14_days:
                if item.naechste_gue:
                    try:
                        gue_date = timezone.datetime.strptime(item.naechste_gue, '%Y-%m-%d').date()
                        if gue_date <= fourteen_days_ago:
                            items_14_days_after['atemschutz'].append({
                                'bereich': 'Atemschutz-Gerät',
                                'name': f"{item.inv_nr} ({item.art})",
                                'faellig_am': item.naechste_gue,
                                'fachbereich_email': f"{config.email_atemschutz_1}, {config.email_atemschutz_2}"
                            })
                            _create_or_update_critical_ticket(
                                admin_user=admin_user,
                                reference=f"atemschutz:{item.pkid}:gue",
                                titel=f"Kritisch ueberfaellige GUE: Atemschutzgeraet {item.inv_nr}",
                                beschreibung=(
                                    f"Atemschutzgeraet '{item.inv_nr} ({item.art})' ist seit mindestens 14 Tagen ueberfaellig. "
                                    f"Faellig am: {item.naechste_gue}."
                                ),
                                faellig_am=gue_date,
                            )
                            sent_14_ids['atemschutz'].append(item.pkid)
                    except ValueError:
                        pass
        except Exception as e:
            logger.error(f"Error checking AtemschutzGeraet for 14-day: {e}")
        
        # Send 14-day after emails to central stammdaten email
        if any([items_14_days_after['inventar'], items_14_days_after['fahrzeuge'], 
                items_14_days_after['raumitems'], items_14_days_after['atemschutz']]):
            
            all_items_14_days = (
                items_14_days_after['inventar'] + 
                items_14_days_after['fahrzeuge'] + 
                items_14_days_after['raumitems'] + 
                items_14_days_after['atemschutz']
            )
            
            stammdaten_email = (config.fw_email or "").strip()
            if stammdaten_email:
                sent = send_service_expiry_14_days_after_email(
                    stammdaten_email,
                    all_items_14_days,
                    config.fw_name
                )
                if sent:
                    Inventar.objects.filter(pkid__in=sent_14_ids['inventar']).update(email_sent_14_days_after=True)
                    Fahrzeug.objects.filter(pkid__in=sent_14_ids['fahrzeuge']).update(email_sent_14_days_after=True)
                    RaumItem.objects.filter(pkid__in=sent_14_ids['raumitems']).update(email_sent_14_days_after=True)
                    AtemschutzGeraet.objects.filter(pkid__in=sent_14_ids['atemschutz']).update(email_sent_14_days_after=True)
                    logger.info(f"Sent 14-day after reminder to Stammdaten email for {len(all_items_14_days)} items")
                else:
                    logger.warning("14-day reminder email could not be sent; items remain unsent for retry")
            else:
                logger.warning("fw_email (Stammdaten) is empty; 14-day reminder skipped and items remain unsent")
        
        logger.info("Service expiry check task completed successfully")
        
    except Exception as exc:
        logger.exception(f"Service expiry check task failed: {exc}")
        # Retry after 60 seconds
        raise self.retry(exc=exc, countdown=60)
