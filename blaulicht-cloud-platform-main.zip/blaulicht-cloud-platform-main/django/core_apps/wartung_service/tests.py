from datetime import date, timedelta
from unittest.mock import patch

from rest_framework import status
from rest_framework.test import APITestCase

from core_apps.atemschutz_geraete.models import AtemschutzGeraet, AtemschutzGeraetProtokoll
from core_apps.common.test_helpers import EndpointSmokeMixin
from core_apps.fahrzeuge.models import Fahrzeug, FahrzeugRaum, RaumItem
from core_apps.inventar.models import Inventar
from core_apps.konfiguration.models import Konfiguration
from core_apps.messgeraete.models import Messgeraet, MessgeraetProtokoll
from core_apps.wartung_service.tasks import check_service_expiry
from core_apps.aufgaben.models import AufgabenTicket
from core_apps.users.models import Role, User


class WartungServiceEndpointTests(EndpointSmokeMixin, APITestCase):
    def setUp(self):
        self.admin_user = self.create_user_with_roles("ADMIN")
        self.kommando_user = self.create_user_with_roles("KOMMANDO")
        self.current_year = date.today().year

    def test_wartung_service_endpoint_resolves(self):
        self.assert_options_works("wartung_service/")

    def test_wartung_service_requires_auth_and_role(self):
        self.assert_requires_authentication("wartung_service/")
        self.assert_forbidden_without_role("wartung_service/")

    def test_wartung_service_collects_due_entries_for_current_year(self):
        Inventar.objects.create(
            bezeichnung="Hydraulikheber",
            wartung_naechstes_am=date(self.current_year, 7, 1),
        )

        fahrzeug = Fahrzeug.objects.create(
            name="HLF 1",
            service_naechstes_am=date(self.current_year, 9, 1),
            pickerl_naechstes_am=date(self.current_year, 10, 1),
        )
        raum = FahrzeugRaum.objects.create(fahrzeug=fahrzeug, name="Geräteraum 1", reihenfolge=1)
        RaumItem.objects.create(
            raum=raum,
            name="Hohlstrahlrohr",
            wartung_naechstes_am=date(self.current_year, 11, 15),
        )

        as_geraet = AtemschutzGeraet.objects.create(
            inv_nr="AS-101",
            typ="PA",
            naechste_gue=str(self.current_year),
        )
        AtemschutzGeraetProtokoll.objects.create(
            geraet_id=as_geraet,
            datum=date(self.current_year, 1, 10),
            name_pruefer="Planer",
            preufung_monatlich=True,
        )
        AtemschutzGeraetProtokoll.objects.create(
            geraet_id=as_geraet,
            datum=date(self.current_year - 1, 3, 15),
            name_pruefer="Planer",
            pruefung_jaehrlich=True,
        )

        mg = Messgeraet.objects.create(inv_nr="MG-1", bezeichnung="Dräger X")
        MessgeraetProtokoll.objects.create(
            geraet_id=mg,
            datum=date(self.current_year - 1, 5, 1),
            name_pruefer="Planer",
            kalibrierung=True,
        )
        MessgeraetProtokoll.objects.create(
            geraet_id=mg,
            datum=date(self.current_year, 2, 1),
            name_pruefer="Planer",
            kontrolle_woechentlich=True,
        )

        self.client.force_authenticate(user=self.admin_user)
        response = self.request_method("get", "wartung_service/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("main", response.data)
        self.assertIn("summary", response.data)

        entries = response.data.get("main", [])
        self.assertGreaterEqual(len(entries), 7)

        self.assertTrue(any(e.get("modul") == "Inventar" for e in entries))
        self.assertTrue(any(e.get("modul") == "Fahrzeuge" for e in entries))
        self.assertTrue(any(e.get("modul") == "Fahrzeuge" and e.get("intervall") == "Pickerl" for e in entries))
        self.assertTrue(any(e.get("intervall") == "Generalüberholung" for e in entries))
        self.assertTrue(any(e.get("modul") == "Messgeräte" and e.get("intervall") == "Kalibrierung" for e in entries))

    def test_wartung_service_kommando_can_access_overview(self):
        Inventar.objects.create(
            bezeichnung="Hydraulikheber",
            wartung_naechstes_am=date(self.current_year, 7, 1),
        )
        Fahrzeug.objects.create(
            name="HLF 1",
            service_naechstes_am=date(self.current_year, 9, 1),
        )

        self.client.force_authenticate(user=self.kommando_user)
        response = self.request_method("get", "wartung_service/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        entries = response.data.get("main", [])
        self.assertTrue(entries)
        self.assertTrue(any(e.get("modul") == "Inventar" for e in entries))
        self.assertTrue(any(e.get("modul") == "Fahrzeuge" for e in entries))

    def test_wartung_service_inventar_role_is_forbidden(self):
        inventar_user = self.create_user_with_roles("INVENTAR")
        self.client.force_authenticate(user=inventar_user)

        response = self.request_method("get", "wartung_service/")

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)


class WartungServiceReminderTaskTests(APITestCase):
    def setUp(self):
        self.today = date.today()
        Konfiguration.objects.create(
            fw_nummer="1234",
            fw_name="FF Test",
            fw_email="stammdaten@test.at",
            email_fahrzeuge_1="fahrzeuge@test.at",
        )
        admin_role, _ = Role.objects.get_or_create(key="ADMIN", defaults={"verbose_name": "Admin"})
        self.admin_user = User.objects.create_user(
            username="wartung_admin",
            password="Test123!",
            email="admin@test.at",
        )
        self.admin_user.roles.add(admin_role)

    @patch("core_apps.wartung_service.tasks.send_service_expiry_14_days_after_email")
    @patch("core_apps.wartung_service.tasks.send_service_expiry_7_days_email")
    def test_check_service_expiry_includes_fahrzeug_pickerl_for_7_day_reminder(
        self,
        mock_send_7_days,
        mock_send_14_days,
    ):
        Fahrzeug.objects.create(
            name="HLF Pickerl",
            pickerl_naechstes_am=self.today + timedelta(days=7),
        )

        check_service_expiry.run()

        self.assertTrue(mock_send_7_days.called)
        fahrzeuge_items = mock_send_7_days.call_args[0][1]
        self.assertTrue(any(x.get("bereich") == "Fahrzeug Pickerl" for x in fahrzeuge_items))
        self.assertFalse(mock_send_14_days.called)
        self.assertTrue(Fahrzeug.objects.get(name="HLF Pickerl").email_sent_7_days_before)

    @patch("core_apps.wartung_service.tasks.send_service_expiry_14_days_after_email", return_value=True)
    @patch("core_apps.wartung_service.tasks.send_service_expiry_7_days_email")
    def test_check_service_expiry_includes_fahrzeug_pickerl_for_14_day_reminder(
        self,
        mock_send_7_days,
        mock_send_14_days,
    ):
        Fahrzeug.objects.create(
            name="HLF Pickerl Überfällig",
            pickerl_naechstes_am=self.today - timedelta(days=14),
        )

        check_service_expiry.run()

        self.assertFalse(mock_send_7_days.called)
        self.assertTrue(mock_send_14_days.called)
        all_items = mock_send_14_days.call_args[0][1]
        self.assertTrue(any(x.get("bereich") == "Fahrzeug Pickerl" for x in all_items))
        self.assertTrue(Fahrzeug.objects.get(name="HLF Pickerl Überfällig").email_sent_14_days_after)
        self.assertEqual(AufgabenTicket.objects.filter(quelle_modul="wartung_service").count(), 1)

    @patch("core_apps.wartung_service.tasks.send_service_expiry_14_days_after_email", return_value=False)
    @patch("core_apps.wartung_service.tasks.send_service_expiry_7_days_email")
    def test_check_service_expiry_creates_single_deduplicated_ticket_when_mail_retry_needed(
        self,
        mock_send_7_days,
        mock_send_14_days,
    ):
        Fahrzeug.objects.create(
            name="HLF Service Überfällig",
            service_naechstes_am=self.today - timedelta(days=14),
        )

        check_service_expiry.run()
        check_service_expiry.run()

        self.assertFalse(mock_send_7_days.called)
        self.assertTrue(mock_send_14_days.called)
        self.assertEqual(AufgabenTicket.objects.filter(quelle_modul="wartung_service").count(), 1)
