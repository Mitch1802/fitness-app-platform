from rest_framework.routers import DefaultRouter

from django.urls import path

from .views import FotoEventViewSet, FotoUploadViewSet, PublicFotoEventViewSet, PublicFotoUploadView

router = DefaultRouter()
router.register("events", FotoEventViewSet, basename="fotoevent")
router.register("uploads", FotoUploadViewSet, basename="fotoupload")
router.register("public/events", PublicFotoEventViewSet, basename="fotoevent-public")
router.register("public/upload", PublicFotoUploadView, basename="fotoupload-public")

urlpatterns = router.urls
