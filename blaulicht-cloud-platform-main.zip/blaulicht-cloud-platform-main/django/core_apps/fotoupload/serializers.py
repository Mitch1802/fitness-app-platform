from rest_framework import serializers
from django.db.models import Sum

from .models import FotoEvent, FotoUpload


class FotoEventSerializer(serializers.ModelSerializer):
    upload_count = serializers.SerializerMethodField()
    foto_total_count = serializers.SerializerMethodField()

    class Meta:
        model = FotoEvent
        fields = ["id", "name", "beschreibung", "datum", "sichtbar", "upload_count", "foto_total_count", "created_at", "updated_at"]
        read_only_fields = ["id", "upload_count", "foto_total_count", "created_at", "updated_at"]

    def get_upload_count(self, obj) -> int:
        return obj.uploads.count()

    def get_foto_total_count(self, obj) -> int:
        return obj.uploads.aggregate(total=Sum("foto_anzahl")).get("total") or 0


class FotoEventPublicSerializer(serializers.ModelSerializer):
    class Meta:
        model = FotoEvent
        fields = ["id", "name", "beschreibung", "datum"]


class FotoUploadSerializer(serializers.ModelSerializer):
    event_name = serializers.CharField(source="event.name", read_only=True)
    zip_url = serializers.SerializerMethodField()

    class Meta:
        model = FotoUpload
        fields = ["id", "event", "event_name", "uploader_name", "foto_anzahl", "zip_url", "created_at"]
        read_only_fields = ["id", "event_name", "foto_anzahl", "zip_url", "created_at"]

    def get_zip_url(self, obj) -> str | None:
        if obj.zip_datei and obj.zip_datei.name:
            request = self.context.get("request")
            if request:
                return request.build_absolute_uri(obj.zip_datei.url)
            return obj.zip_datei.url
        return None
