import os
import re

from django.db import models
from django.utils.translation import gettext_lazy as _

from core_apps.common.models import TimeStampedModel


def _clean_zip_filename(event_name: str, uploader_name: str) -> str:
    safe_event = re.sub(r"[^\w\-]+", "_", (event_name or "event").strip())
    safe_uploader = re.sub(r"[^\w\-]+", "_", (uploader_name or "upload").strip())
    return f"{safe_event}_{safe_uploader}.zip"


def foto_zip_path(instance, filename):
    event_id = instance.event.id if instance.event_id else "unbekannt"
    filename = _clean_zip_filename(
        instance.event.name if instance.event_id else "event",
        instance.uploader_name,
    )
    return os.path.join("fotoupload", str(event_id), filename)


class FotoEvent(TimeStampedModel):
    name = models.CharField(verbose_name=_("Name"), max_length=255)
    beschreibung = models.TextField(verbose_name=_("Beschreibung"), blank=True)
    datum = models.DateField(verbose_name=_("Datum"), blank=True, null=True)
    sichtbar = models.BooleanField(verbose_name=_("Öffentlich sichtbar"), default=True)

    class Meta(TimeStampedModel.Meta):
        ordering = ["-datum", "-created_at"]
        verbose_name = _("Foto-Event")
        verbose_name_plural = _("Foto-Events")

    def __str__(self):
        return self.name


class FotoUpload(TimeStampedModel):
    event = models.ForeignKey(
        FotoEvent,
        on_delete=models.CASCADE,
        related_name="uploads",
        verbose_name=_("Event"),
    )
    uploader_name = models.CharField(verbose_name=_("Name des Uploaders"), max_length=255)
    foto_anzahl = models.PositiveIntegerField(verbose_name=_("Anzahl Fotos"), default=0)
    zip_datei = models.FileField(
        verbose_name=_("ZIP-Datei"),
        upload_to=foto_zip_path,
        blank=True,
        null=True,
    )

    class Meta(TimeStampedModel.Meta):
        ordering = ["-created_at"]
        verbose_name = _("Foto-Upload")
        verbose_name_plural = _("Foto-Uploads")

    def __str__(self):
        return f"{self.uploader_name} – {self.event.name} ({self.foto_anzahl} Fotos)"
