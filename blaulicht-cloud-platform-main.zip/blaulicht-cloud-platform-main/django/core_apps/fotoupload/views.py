import io
import logging
import zipfile

from django.http import FileResponse
from rest_framework import permissions, status
from rest_framework.decorators import action
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet, ReadOnlyModelViewSet, GenericViewSet
from rest_framework.mixins import RetrieveModelMixin, ListModelMixin, DestroyModelMixin

from core_apps.common.permissions import HasAnyRolePermission

from .models import FotoEvent, FotoUpload
from .serializers import FotoEventPublicSerializer, FotoEventSerializer, FotoUploadSerializer

logger = logging.getLogger(__name__)

ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp", "image/heic", "image/heif"}
MAX_FILE_SIZE_MB = 50
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024
MAX_PHOTOS_PER_UPLOAD = 200


class FotoEventViewSet(ModelViewSet):
    queryset = FotoEvent.objects.all()
    serializer_class = FotoEventSerializer
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN", "NEWS")]
    parser_classes = [JSONParser, MultiPartParser, FormParser]
    lookup_field = "id"
    pagination_class = None

    @action(detail=True, methods=["get"], url_path="uploads")
    def uploads(self, request, id=None):
        event = self.get_object()
        uploads = event.uploads.all()
        serializer = FotoUploadSerializer(uploads, many=True, context={"request": request})
        return Response(serializer.data)


class FotoUploadViewSet(RetrieveModelMixin, ListModelMixin, DestroyModelMixin, GenericViewSet):
    queryset = FotoUpload.objects.select_related("event").all()
    serializer_class = FotoUploadSerializer
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN", "NEWS")]
    lookup_field = "id"
    pagination_class = None

    def get_queryset(self):
        qs = super().get_queryset()
        event_id = self.request.query_params.get("event_id")
        if event_id:
            qs = qs.filter(event__id=event_id)
        return qs

    def perform_destroy(self, instance):
        if instance.zip_datei and instance.zip_datei.name:
            try:
                instance.zip_datei.storage.delete(instance.zip_datei.name)
            except Exception:
                logger.exception("ZIP-Datei konnte nicht gelöscht werden: %s", instance.zip_datei.name)
        instance.delete()

    @action(detail=True, methods=["get"], url_path="download")
    def download(self, request, id=None):
        upload = self.get_object()
        if not upload.zip_datei or not upload.zip_datei.name:
            return Response({"detail": "Keine ZIP-Datei vorhanden."}, status=status.HTTP_404_NOT_FOUND)
        try:
            response = FileResponse(
                upload.zip_datei.open("rb"),
                as_attachment=True,
                filename=f"{upload.uploader_name}_{upload.event.name}.zip",
            )
            return response
        except FileNotFoundError:
            return Response({"detail": "Datei nicht gefunden."}, status=status.HTTP_404_NOT_FOUND)


class PublicFotoEventViewSet(ReadOnlyModelViewSet):
    queryset = FotoEvent.objects.filter(sichtbar=True)
    serializer_class = FotoEventPublicSerializer
    permission_classes = [permissions.AllowAny]
    lookup_field = "id"
    pagination_class = None


class PublicFotoUploadView(ModelViewSet):
    queryset = FotoUpload.objects.none()
    serializer_class = FotoUploadSerializer
    permission_classes = [permissions.AllowAny]
    parser_classes = [MultiPartParser, FormParser]
    http_method_names = ["post", "head", "options"]

    def create(self, request, *args, **kwargs):
        event_id = request.data.get("event_id")
        uploader_name = (request.data.get("uploader_name") or "").strip()

        if not event_id:
            return Response({"detail": "Event-ID fehlt."}, status=status.HTTP_400_BAD_REQUEST)
        if not uploader_name:
            return Response({"detail": "Name des Uploaders fehlt."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            event = FotoEvent.objects.get(id=event_id, sichtbar=True)
        except FotoEvent.DoesNotExist:
            return Response({"detail": "Event nicht gefunden oder nicht öffentlich."}, status=status.HTTP_404_NOT_FOUND)

        fotos = request.FILES.getlist("fotos")
        if not fotos:
            return Response({"detail": "Keine Fotos hochgeladen."}, status=status.HTTP_400_BAD_REQUEST)

        if len(fotos) > MAX_PHOTOS_PER_UPLOAD:
            return Response(
                {"detail": f"Maximal {MAX_PHOTOS_PER_UPLOAD} Fotos pro Upload erlaubt."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Validate files
        for foto in fotos:
            if foto.size > MAX_FILE_SIZE_BYTES:
                return Response(
                    {"detail": f"Datei '{foto.name}' überschreitet die maximale Dateigröße von {MAX_FILE_SIZE_MB} MB."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            content_type = getattr(foto, "content_type", "") or ""
            if content_type not in ALLOWED_IMAGE_TYPES:
                return Response(
                    {"detail": f"Dateityp '{content_type}' ist nicht erlaubt. Nur Bilder sind zulässig."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        # Create ZIP in memory
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            for foto in fotos:
                foto.seek(0)
                zf.writestr(foto.name, foto.read())
        zip_buffer.seek(0)

        # Save upload record
        upload = FotoUpload(
            event=event,
            uploader_name=uploader_name,
            foto_anzahl=len(fotos),
        )
        # Save without zip first to get an id
        upload.save()

        from django.core.files.base import ContentFile
        zip_filename = f"fotos_{event.id}_{upload.id}.zip"
        upload.zip_datei.save(zip_filename, ContentFile(zip_buffer.getvalue()), save=True)

        logger.info(
            "Fotoupload: %d Fotos für Event '%s' von '%s' hochgeladen.",
            len(fotos),
            event.name,
            uploader_name,
        )

        return Response(
            {"detail": f"{len(fotos)} Foto(s) erfolgreich hochgeladen.", "foto_anzahl": len(fotos)},
            status=status.HTTP_201_CREATED,
        )
