from django.apps import AppConfig


class FotouploadConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "core_apps.fotoupload"
