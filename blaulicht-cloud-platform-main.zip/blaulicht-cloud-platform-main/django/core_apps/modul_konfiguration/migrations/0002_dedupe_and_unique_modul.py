from django.db import migrations, models


def dedupe_modul_konfiguration(apps, schema_editor):
    modul_model = apps.get_model("modul_konfiguration", "ModulKonfiguration")

    unique_modul_namen = (
        modul_model.objects.values_list("modul", flat=True)
        .distinct()
    )

    for modul_name in unique_modul_namen:
        eintraege = list(
            modul_model.objects
            .filter(modul=modul_name)
            .order_by("-updated_at", "-pkid")
        )

        if len(eintraege) <= 1:
            continue

        to_keep = eintraege[0]
        to_delete_ids = [item.pkid for item in eintraege[1:] if item.pkid != to_keep.pkid]
        if to_delete_ids:
            modul_model.objects.filter(pkid__in=to_delete_ids).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("modul_konfiguration", "0001_initial"),
    ]

    operations = [
        migrations.RunPython(dedupe_modul_konfiguration, migrations.RunPython.noop),
        migrations.AddConstraint(
            model_name="modulkonfiguration",
            constraint=models.UniqueConstraint(fields=("modul",), name="uniq_modulkonfiguration_modul"),
        ),
    ]
