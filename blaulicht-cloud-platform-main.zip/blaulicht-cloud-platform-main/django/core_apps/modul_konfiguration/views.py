from rest_framework import permissions, status
from rest_framework.parsers import JSONParser
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from .models import ModulKonfiguration
from .serializers import ModulKonfigurationSerializer
from core_apps.common.permissions import HasAnyRolePermission, HasReadOnlyRolePermission, any_of
from core_apps.users.models import Role
from core_apps.users.serializers import RoleSerializer
from core_apps.pdf.models import PdfTemplate
from core_apps.pdf.serializers import PdfTemplateSerializer
from core_apps.users.serializers import UserDetailSerializer


class ModulKonfigurationViewSet(ModelViewSet):
    queryset = ModulKonfiguration.objects.all().order_by("modul")
    serializer_class = ModulKonfigurationSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        any_of(
            HasAnyRolePermission.with_roles("ADMIN"),
            HasReadOnlyRolePermission.with_roles("MITGLIED", "JUGEND"),
        ),
    ]
    parser_classes = [JSONParser]
    lookup_field = "id"
    pagination_class = None 

    def create(self, request, *args, **kwargs):
        modul = str(request.data.get("modul") or "").strip()
        if not modul:
            return Response({"modul": ["This field is required."]}, status=status.HTTP_400_BAD_REQUEST)

        if len(modul) > 255:
            return Response({"modul": ["Ensure this field has no more than 255 characters."]}, status=status.HTTP_400_BAD_REQUEST)

        konfiguration = request.data.get("konfiguration", {})
        eintrag, created = ModulKonfiguration.objects.update_or_create(
            modul=modul,
            defaults={"konfiguration": konfiguration},
        )

        response_data = self.get_serializer(eintrag).data
        if created:
            headers = self.get_success_headers(response_data)
            return Response(response_data, status=status.HTTP_201_CREATED, headers=headers)

        return Response(response_data, status=status.HTTP_200_OK)

    def list(self, request, *args, **kwargs):
        resp = super().list(request, *args, **kwargs)
        rollen = RoleSerializer(Role.objects.all(), many=True).data
        pdf = PdfTemplateSerializer(PdfTemplate.objects.all(), many=True).data
        user = UserDetailSerializer(request.user).data
        return Response({"main": resp.data, "rollen": rollen, "pdf": pdf, "user": user})
