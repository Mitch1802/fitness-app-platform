import base64
import io
import mimetypes
import logging
from datetime import datetime, timezone as dt_timezone
from urllib.parse import quote

import requests
from django.conf import settings
from django.core.mail import EmailMessage
from django.utils import timezone
from PIL import Image, ImageOps
from rest_framework import filters, permissions, status
from rest_framework.decorators import action
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet

from core_apps.common.logging_utils import log_event, log_exception
from core_apps.common.permissions import HasAnyRolePermission
from core_apps.fahrzeuge.models import Fahrzeug
from core_apps.konfiguration.models import Konfiguration
from core_apps.konfiguration.serializers import KonfigurationSerializer
from core_apps.mitglieder.models import Mitglied
from core_apps.modul_konfiguration.models import ModulKonfiguration
from core_apps.modul_konfiguration.serializers import ModulKonfigurationSerializer
from core_apps.pdf.models import PdfTemplate
from core_apps.pdf.services import PdfTemplateService
from core_apps.users.models import User

from .models import Einsatzbericht, EinsatzberichtFoto, MitalarmierteStelle
from .serializers import EinsatzberichtSerializer

logger = logging.getLogger(__name__)
LOG_SOURCE = "einsatzberichte"


class EinsatzberichtViewSet(ModelViewSet):
    queryset = Einsatzbericht.objects.prefetch_related("fahrzeuge", "mitglieder", "mitalarmierte_stellen", "fotos").all()
    serializer_class = EinsatzberichtSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        HasAnyRolePermission.with_roles("ADMIN", "BERICHT", "VERWALTUNG"),
    ]
    parser_classes = [JSONParser, MultiPartParser, FormParser]
    lookup_field = "id"
    pagination_class = None
    filter_backends = [filters.OrderingFilter]
    ordering_fields = ["created_at", "einsatz_datum", "status", "alarmstichwort"]
    ordering = ["-created_at"]

    def get_permissions(self):
        if getattr(self, "action", None) == "destroy":
            permission_classes = [
                permissions.IsAuthenticated,
                HasAnyRolePermission.with_roles("ADMIN", "VERWALTUNG"),
            ]
            return [permission() for permission in permission_classes]
        return super().get_permissions()

    def _can_manage_status(self, user) -> bool:
        return bool(
            getattr(user, "is_authenticated", False)
            and hasattr(user, "has_any_role")
            and user.has_any_role("ADMIN", "VERWALTUNG")
        )

    def _can_edit_report_content(self, user) -> bool:
        return bool(
            getattr(user, "is_authenticated", False)
            and hasattr(user, "has_any_role")
            and user.has_any_role("ADMIN", "BERICHT", "VERWALTUNG")
        )

    def _can_send_report(self, user) -> bool:
        return bool(
            getattr(user, "is_authenticated", False)
            and hasattr(user, "has_any_role")
            and user.has_any_role("ADMIN", "BERICHT")
        )

    def _can_print_report(self, user) -> bool:
        return bool(
            getattr(user, "is_authenticated", False)
            and hasattr(user, "has_any_role")
            and user.has_any_role("ADMIN", "VERWALTUNG")
        )

    def _status_will_change(self, incoming_status, instance=None) -> bool:
        if incoming_status is None:
            return False

        normalized_status = str(incoming_status).strip()
        if not normalized_status:
            return False

        if instance is None:
            return normalized_status != Einsatzbericht.Status.ENTWURF

        return normalized_status != instance.status

    def _validate_edit_permissions(self, request, instance=None):
        payload_keys = {str(key) for key in request.data.keys()}
        has_content_changes = bool(payload_keys - {"status"})
        status_will_change = self._status_will_change(request.data.get("status"), instance=instance)

        if (
            instance is not None
            and instance.status != Einsatzbericht.Status.ENTWURF
            and has_content_changes
            and not self._can_manage_status(request.user)
        ):
            self.permission_denied(
                request,
                message="Nur Admin oder Verwaltung duerfen gesendete Einsatzberichte inhaltlich bearbeiten.",
            )

        if has_content_changes and not self._can_edit_report_content(request.user):
            self.permission_denied(
                request,
                message="Nur Bericht, Admin oder Verwaltung duerfen Einsatzbericht-Inhalte bearbeiten.",
            )

        if status_will_change and not self._can_manage_status(request.user):
            self.permission_denied(
                request,
                message="Nur Admin oder Verwaltung duerfen den Status aendern.",
            )

    def _get_pdf_konfig(self) -> dict:
        entry = (
            ModulKonfiguration.objects
            .filter(modul__iexact="pdf")
            .order_by("-updated_at", "-id")
            .first()
        )
        payload = entry.konfiguration if entry else {}
        return payload if isinstance(payload, dict) else {}

    def _resolve_user_display_name(self, user: User) -> str:
        full_name_attr = getattr(user, "get_full_name", "")
        if callable(full_name_attr):
            try:
                resolved = str(full_name_attr() or "").strip()
            except Exception:
                resolved = ""
        else:
            resolved = str(full_name_attr or "").strip()
        return resolved or user.username

    def _resolve_einsatzbericht_recipient(self, pdf_konfig: dict) -> tuple[str, str]:
        # 1. Ausgewählter User
        user_id_raw = pdf_konfig.get("einsatzberichtEmpfaengerUserId")
        user_id = str(user_id_raw or "").strip()
        if user_id:
            user = User.objects.filter(id=user_id).exclude(email__isnull=True).exclude(email="").first()
            if user and user.email:
                display = self._resolve_user_display_name(user)
                return user.email.strip(), display

        # 1b. Legacy-Fallback: gespeicherte Mitglied-PKID
        member_pkid = str(pdf_konfig.get("einsatzberichtEmpfaengerMitgliedPkid") or "").strip()
        if member_pkid.isdigit() and member_pkid != "0":
            user = User.objects.filter(mitglied__pkid=member_pkid).exclude(email__isnull=True).exclude(email="").first()
            if user and user.email:
                display = self._resolve_user_display_name(user)
                return user.email.strip(), display

        # 2. Fallback: fw_email aus Stammdaten
        konfig = Konfiguration.objects.first()
        stammdaten_email = str(getattr(konfig, "fw_email", "") or "").strip()
        if stammdaten_email:
            fw_name = str(getattr(konfig, "fw_name", "") or "").strip()
            return stammdaten_email, fw_name or stammdaten_email

        return "", ""

    def _format_pdf_date(self, value) -> str:
        if not value:
            return ""
        try:
            return value.strftime("%d.%m.%Y")
        except Exception:
            return str(value)

    def _encode_pdf_image(self, image_bytes: bytes, file_name: str) -> tuple[str, str]:
        """Shrink/normalize images for PDF to reduce render time and memory usage."""
        fallback_mime, _ = mimetypes.guess_type(file_name)
        fallback_mime = fallback_mime if fallback_mime and fallback_mime.startswith("image/") else "image/jpeg"

        try:
            with Image.open(io.BytesIO(image_bytes)) as img:
                img = ImageOps.exif_transpose(img)

                if img.mode not in ("RGB", "L"):
                    img = img.convert("RGB")
                elif img.mode == "L":
                    img = img.convert("RGB")

                # Keep enough quality for reports while controlling PDF size/CPU cost.
                img.thumbnail((1600, 1600), Image.Resampling.LANCZOS)

                out = io.BytesIO()
                img.save(out, format="JPEG", quality=78, optimize=True, progressive=True)
                optimized = out.getvalue()
                return base64.b64encode(optimized).decode("utf-8"), "image/jpeg"
        except Exception:
            return base64.b64encode(image_bytes).decode("utf-8"), fallback_mime

    def _build_pdf_payload(self, bericht: Einsatzbericht) -> dict:
        konfig = Konfiguration.objects.first()

        fahrzeuge_namen = ", ".join(
            [f.name or f.bezeichnung or f"Fahrzeug {f.pkid}" for f in bericht.fahrzeuge.all()]
        )
        mitglieder_namen = ", ".join(
            [f"{m.stbnr} {m.vorname} {m.nachname}".strip() for m in bericht.mitglieder.all()]
        )
        mitalarmiert_namen = ", ".join([s.name for s in bericht.mitalarmierte_stellen.all()])

        mitglieder_liste = [
            {"stbnr": m.stbnr or "", "vorname": m.vorname or "", "nachname": m.nachname or ""}
            for m in bericht.mitglieder.all()
        ]

        fotos_base64 = []
        fotos_relation = getattr(bericht, "fotos", None)
        if fotos_relation is not None:
            for foto in fotos_relation.all():
                if getattr(foto, "foto", None) and getattr(foto.foto, "name", ""):
                    try:
                        with foto.foto.storage.open(foto.foto.name, "rb") as fh:
                            original_bytes = fh.read()
                            data, mime_type = self._encode_pdf_image(original_bytes, foto.foto.name)
                            fotos_base64.append({"data": data, "mime_type": mime_type})
                    except Exception:
                        pass

        return {
            "druck_datum": datetime.now().strftime("%d.%m.%Y"),
            "fw_name": getattr(konfig, "fw_name", ""),
            "fw_nummer": getattr(konfig, "fw_nummer", ""),
            "fw_street": getattr(konfig, "fw_street", ""),
            "fw_plz": getattr(konfig, "fw_plz", ""),
            "fw_ort": getattr(konfig, "fw_ort", ""),
            "fw_email": getattr(konfig, "fw_email", ""),
            "fw_telefon": getattr(konfig, "fw_telefon", ""),
            "status": bericht.status,
            "einsatz_datum": self._format_pdf_date(bericht.einsatz_datum),
            "alarmstichwort": bericht.alarmstichwort,
            "einsatzart": bericht.einsatzart,
            "einsatzadresse": bericht.einsatzadresse,
            "alarmierende_stelle": bericht.alarmierende_stelle,
            "einsatzleiter": bericht.einsatzleiter,
            "ausgerueckt": bericht.ausgerueckt.strftime("%H:%M") if bericht.ausgerueckt else "",
            "eingerueckt": bericht.eingerueckt.strftime("%H:%M") if bericht.eingerueckt else "",
            "lage_beim_eintreffen": bericht.lage_beim_eintreffen,
            "gesetzte_massnahmen": bericht.gesetzte_massnahmen,
            "einsatzart_ist_brand": bericht.einsatzart == "Brandeinsatz",
            "brand_kategorie": bericht.brand_kategorie,
            "brand_aus": bericht.brand_aus.strftime("%H:%M") if bericht.brand_aus else "",
            "einsatzart_ist_technisch": bericht.einsatzart == "Technischer Einsatz",
            "technisch_kategorie": bericht.technisch_kategorie,
            "bma_meldergruppe": bericht.bma_meldergruppe,
            "bma_melder": bericht.bma_melder,
            "bma_fehl_tauschungsalarm": bericht.bma_fehl_tauschungsalarm,
            "fahrzeuge_namen": fahrzeuge_namen,
            "mitglieder_namen": mitglieder_namen,
                "mitglieder_liste": mitglieder_liste,
                "mitalarmiert_namen": mitalarmiert_namen,
                "fotos_base64": fotos_base64,
                "blaulichtsms_einsatz_id": bericht.blaulichtsms_einsatz_id,
        }

    @action(detail=True, methods=["post"], url_path="senden")
    def senden(self, request, id=None):
        bericht = self.get_object()

        if not self._can_send_report(request.user):
            self.permission_denied(request, message="Nur Bericht oder Admin duerfen Einsatzberichte senden.")

        if bericht.status != Einsatzbericht.Status.ENTWURF:
            return Response(
                {"detail": "Nur Entwuerfe koennen gesendet werden."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        pdf_konfig = self._get_pdf_konfig()
        template_id = str(pdf_konfig.get("idEinsatzberichtPdf") or "").strip()
        if not template_id:
            return Response(
                {"detail": "Kein PDF-Template fuer Einsatzbericht in den Einstellungen hinterlegt."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        recipient_email, recipient_label = self._resolve_einsatzbericht_recipient(pdf_konfig)
        if not recipient_email:
            return Response(
                {"detail": "Keine E-Mail-Adresse fuer den Empfaenger konfiguriert (Einstellungen oder Stammdaten)."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        template = PdfTemplate.objects.filter(id=template_id).first()
        if template is None:
            return Response(
                {"detail": "Konfiguriertes PDF-Template wurde nicht gefunden."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            payload = self._build_pdf_payload(bericht)
            log_event(
                logger,
                LOG_SOURCE,
                "report_pdf_payload_built",
                bericht_id=str(bericht.id),
                mitglieder_count=len(payload.get("mitglieder_liste") or []),
                fotos_count=len(payload.get("fotos_base64") or []),
            )
            html, header_html, footer_html = PdfTemplateService.render_html(template, payload)
            pdf_bytes = PdfTemplateService.render_pdf_bytes(html, header_html, footer_html)

            date_token = bericht.einsatz_datum.strftime("%Y-%m-%d") if bericht.einsatz_datum else "ohne-datum"
            filename = f"Einsatzbericht_{date_token}_{bericht.id}.pdf"
            subject = f"Einsatzbericht {date_token} - {bericht.alarmstichwort}"
            message = (
                "Der Einsatzbericht wurde finalisiert und als PDF angehaengt.\n\n"
                f"Einsatzleiter: {bericht.einsatzleiter}\n"
                f"Alarmstichwort: {bericht.alarmstichwort}\n"
                f"Einsatzadresse: {bericht.einsatzadresse}\n"
            )

            email = EmailMessage(
                subject=subject,
                body=message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[recipient_email],
            )
            email.attach(filename, pdf_bytes, "application/pdf")
            email.send(fail_silently=False)
        except Exception:
            log_exception(logger, LOG_SOURCE, "report_send_failed", bericht_id=str(bericht.id), recipient=recipient_email)
            return Response(
                {"detail": "PDF oder E-Mail-Versand ist fehlgeschlagen."},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        bericht.status = Einsatzbericht.Status.GESENDET
        bericht.save(update_fields=["status", "updated_at"])

        log_event(
            logger,
            LOG_SOURCE,
            "report_sent",
            bericht_id=str(bericht.id),
            recipient=recipient_email,
            recipient_label=recipient_label,
            template_id=template_id,
        )

        serializer = self.get_serializer(bericht)
        return Response(serializer.data, status=status.HTTP_200_OK)

    @action(detail=True, methods=["post"], url_path="fdisk-eingetragen")
    def fdisk_eingetragen(self, request, id=None):
        bericht = self.get_object()

        if not self._can_manage_status(request.user):
            self.permission_denied(request, message="Nur Verwaltung darf den FDISK-Status setzen.")

        if bericht.status != Einsatzbericht.Status.GESENDET:
            return Response(
                {"detail": "FDISK kann nur fuer bereits gesendete Berichte gesetzt werden."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        bericht.status = Einsatzbericht.Status.FDISK_EINGETRAGEN
        bericht.save(update_fields=["status", "updated_at"])

        serializer = self.get_serializer(bericht)
        return Response(serializer.data, status=status.HTTP_200_OK)

    @action(detail=True, methods=["post"], url_path="pdf-payload")
    def pdf_payload(self, request, id=None):
        bericht = self.get_object()

        if not self._can_print_report(request.user):
            self.permission_denied(request, message="Druck ist nur fuer Admin oder Verwaltung verfuegbar.")

        try:
            payload = self._build_pdf_payload(bericht)
            log_event(
                logger,
                LOG_SOURCE,
                "report_pdf_payload_built",
                bericht_id=str(bericht.id),
                mitglieder_count=len(payload.get("mitglieder_liste") or []),
                fotos_count=len(payload.get("fotos_base64") or []),
            )
        except Exception:
            log_exception(
                logger,
                LOG_SOURCE,
                "report_pdf_payload_failed",
                bericht_id=str(bericht.id),
            )
            return Response(
                {"detail": "PDF-Payload-Generierung ist fehlgeschlagen."},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        return Response(payload)

    def create(self, request, *args, **kwargs):
        self._validate_edit_permissions(request, instance=None)
        return super().create(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        self._validate_edit_permissions(request, instance=instance)
        return super().update(request, *args, **kwargs)

    def partial_update(self, request, *args, **kwargs):
        instance = self.get_object()
        self._validate_edit_permissions(request, instance=instance)
        return super().partial_update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        bericht = self.get_object()
        foto_files = [
            (f.foto.storage, f.foto.name)
            for f in bericht.fotos.all()
            if getattr(f, "foto", None) and getattr(f.foto, "name", "")
        ]

        response = super().destroy(request, *args, **kwargs)

        for storage, name in foto_files:
            try:
                storage.delete(name)
            except Exception:
                log_exception(logger, LOG_SOURCE, "report_file_delete_failed", bericht_id=bericht.id, file=name)

        return response

    @action(detail=False, methods=["get"], url_path="context")
    def context(self, request):
        fahrzeuge = [
            {
                "pkid": f.pkid,
                "id": str(f.id),
                "name": f.name,
                "bezeichnung": f.bezeichnung,
            }
            for f in Fahrzeug.objects.all().order_by("name")
        ]

        mitglieder = [
            {
                "pkid": m.pkid,
                "id": str(m.id),
                "stbnr": m.stbnr,
                "vorname": m.vorname,
                "nachname": m.nachname,
            }
            for m in Mitglied.objects.exclude(
                dienststatus__in=[Mitglied.Dienststatus.ABGEMELDET, Mitglied.Dienststatus.RESERVE]
            ).order_by("stbnr")
        ]

        mitalarmiert_stellen = [
            {
                "pkid": stelle.pkid,
                "id": str(stelle.id),
                "name": stelle.name,
            }
            for stelle in MitalarmierteStelle.objects.all().order_by("name")
        ]

        modul_konfig = ModulKonfigurationSerializer(ModulKonfiguration.objects.all(), many=True).data
        konfig = KonfigurationSerializer(Konfiguration.objects.all(), many=True).data

        users_with_email = [
            {
                "id": str(u.id),
                "username": u.username,
                "display": self._resolve_user_display_name(u),
                "email": u.email,
            }
            for u in User.objects.exclude(email__isnull=True).exclude(email="").order_by("username")
        ]

        return Response({
            "fahrzeuge": fahrzeuge,
            "mitglieder": mitglieder,
            "mitalarmiert_stellen": mitalarmiert_stellen,
            "modul_konfig": modul_konfig,
            "konfig": konfig,
            "users": users_with_email,
        })

    @action(detail=False, methods=["get"], url_path="blaulichtsms/letzter")
    def blaulichtsms_letzter(self, request):
        base_url = getattr(settings, "BLAULICHTSMS_API_URL", "").strip()
        session_id = getattr(settings, "BLAULICHTSMS_DASHBOARD_SESSION_ID", "").strip()
        timeout = getattr(settings, "BLAULICHTSMS_TIMEOUT", 10)

        if not base_url or not session_id:
            return Response(
                {
                    "detail": "BlaulichtSMS ist nicht konfiguriert.",
                    "configured": False,
                },
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )

        payload = self._fetch_blaulichtsms_payload(
            base_url=base_url,
            session_id=session_id,
            timeout=timeout,
        )

        if payload is None:
            return Response(
                {"detail": "Letzter BlaulichtSMS Alarm konnte nicht geladen werden."},
                status=status.HTTP_502_BAD_GATEWAY,
            )

        mapped = self._map_blaulichtsms_payload(payload)
        return Response({"configured": True, "mapped": mapped, "raw": payload})

    def _fetch_blaulichtsms_payload(
        self,
        base_url: str,
        session_id: str,
        timeout: int,
    ):
        url = f"{base_url.rstrip('/')}/api/alarm/v1/dashboard/{quote(session_id, safe='')}"
        headers = {"Accept": "application/json"}

        try:
            response = requests.get(url, headers=headers, timeout=timeout)
            response.raise_for_status()
            payload = response.json() if response.content else {}
        except requests.HTTPError as exc:
            response = exc.response
            if response is not None and response.status_code == status.HTTP_401_UNAUTHORIZED:
                log_event(logger, LOG_SOURCE, "blaulichtsms_dashboard_session_invalid", level="error", endpoint="dashboard", url=url)
            else:
                log_exception(logger, LOG_SOURCE, "blaulichtsms_request_failed", endpoint="dashboard", url=url)
            return None
        except requests.RequestException:
            log_exception(logger, LOG_SOURCE, "blaulichtsms_request_failed", endpoint="dashboard", url=url)
            return None

        if not isinstance(payload, dict):
            log_event(logger, LOG_SOURCE, "blaulichtsms_invalid_payload", level="error", payload_type=type(payload).__name__)
            return None

        alarms = payload.get("alarms")
        if not isinstance(alarms, list) or not alarms:
            return None

        valid_alarms = [alarm for alarm in alarms if isinstance(alarm, dict)]
        if not valid_alarms:
            return None

        return max(valid_alarms, key=self._alarm_sort_key)

    def _alarm_sort_key(self, payload: dict) -> float:
        alarm_date = self._parse_iso_datetime(payload.get("alarmDate"))
        return alarm_date.timestamp() if alarm_date else float("-inf")

    def _parse_iso_datetime(self, value):
        if not value or not isinstance(value, str):
            return None

        normalized = value.strip()
        if not normalized:
            return None

        if normalized.endswith("Z"):
            normalized = f"{normalized[:-1]}+00:00"

        try:
            return datetime.fromisoformat(normalized)
        except ValueError:
            return None


    def _map_blaulichtsms_payload(self, payload: dict) -> dict:
        einsatz_id = (
            str(payload.get("alarmId") or payload.get("einsatz_id") or payload.get("id") or "").strip()
        )
        alarm_date = self._parse_iso_datetime(payload.get("alarmDate"))
        local_alarm_date = self._to_local_timezone(alarm_date)
        alarm_groups = payload.get("alarmGroups") if isinstance(payload.get("alarmGroups"), list) else []
        first_group = alarm_groups[0] if alarm_groups and isinstance(alarm_groups[0], dict) else {}

        # Zusagende Mitglieder extrahieren
        confirmed_member_ids = self._extract_confirmed_member_ids(payload)

        return {
            "einsatzart": payload.get("type", ""),
            "alarmstichwort": payload.get("alarmText", ""),
            "alarmierende_stelle": first_group.get("authorName", ""),
            "einsatz_datum": local_alarm_date.date().isoformat() if local_alarm_date else None,
            "ausgerueckt": local_alarm_date.strftime("%H:%M") if local_alarm_date else None,
            "blaulichtsms_einsatz_id": einsatz_id,
            "blaulichtsms_payload": payload,
            "mitglieder_ids": confirmed_member_ids,  # ← neu hinzugefügt
        }

    def _to_local_timezone(self, alarm_date):
        if alarm_date is None:
            return None
        if timezone.is_naive(alarm_date):
            alarm_date = alarm_date.replace(tzinfo=dt_timezone.utc)
        return timezone.localtime(alarm_date, timezone.get_current_timezone())

    def _extract_confirmed_member_ids(self, payload: dict) -> list:
        """Extrahiert lokale Mitglieder-IDs aus BlaulichtSMS recipients mit participation='yes'"""
        recipients = payload.get("recipients", [])
        if not isinstance(recipients, list):
            return []

        confirmed_names = [
            r.get("name", "").strip()
            for r in recipients
            if isinstance(r, dict) and r.get("participation") == "yes" and r.get("name", "").strip()
        ]

        if not confirmed_names:
            return []

        # Alle Mitglieder laden für Matching
        all_members = Mitglied.objects.exclude(
            dienststatus__in=[Mitglied.Dienststatus.ABGEMELDET, Mitglied.Dienststatus.RESERVE]
        ).values_list("pkid", "vorname", "nachname")

        matched_ids = []
        for bls_name in confirmed_names:
            # Versuche zu matchen: exakt oder via Vorname + Nachname
            member_id = self._match_member_by_name(bls_name, all_members)
            if member_id is not None:
                matched_ids.append(member_id)

        return matched_ids

    def _match_member_by_name(self, bls_name: str, all_members) -> int | None:
        """Matcht einen BlaulichtSMS Namen mit einem lokalen Mitglied"""
        bls_name_lower = bls_name.lower().strip()

        for pkid, vorname, nachname in all_members:
            if not vorname or not nachname:
                continue

            full_name = f"{vorname} {nachname}".lower().strip()

            # Exaktes oder Case-insensitives Match
            if bls_name_lower == full_name:
                return pkid

            # Reverse: "Nachname Vorname" auch versuchen
            reverse_name = f"{nachname} {vorname}".lower().strip()
            if bls_name_lower == reverse_name:
                return pkid

        return None

    @action(detail=True, methods=["delete"], url_path=r"fotos/(?P<foto_id>[^/.]+)")
    def foto_loeschen(self, request, id=None, foto_id=None):
        bericht = self.get_object()
        foto = bericht.fotos.filter(id=foto_id).first()

        if foto is None:
            log_event(logger, LOG_SOURCE, "photo_not_found", level="warning", bericht_id=bericht.id, foto_id=foto_id)
            return Response({"detail": "Foto nicht gefunden."}, status=status.HTTP_404_NOT_FOUND)

        storage = foto.foto.storage if foto.foto else None
        name = foto.foto.name if foto.foto else ""

        foto.delete()

        if storage and name:
            try:
                storage.delete(name)
            except Exception:
                log_exception(logger, LOG_SOURCE, "photo_file_delete_failed", bericht_id=bericht.id, foto_id=foto_id, file=name)

        return Response(status=status.HTTP_204_NO_CONTENT)
