from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("einsatzberichte", "0008_bma_felder"),
    ]

    operations = [
        migrations.AlterField(
            model_name="einsatzbericht",
            name="status",
            field=models.CharField(
                choices=[
                    ("ENTWURF", "Entwurf"),
                    ("GESENDET", "Gesendet"),
                    ("FDISK_EINGETRAGEN", "FDISK eingetragen"),
                ],
                default="ENTWURF",
                max_length=20,
                verbose_name="Status",
            ),
        ),
    ]
