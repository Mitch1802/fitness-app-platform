from rest_framework import serializers

from core_apps.fahrzeuge.models import Fahrzeug
from core_apps.mitglieder.models import Mitglied

from .models import Einsatzbericht, EinsatzberichtFoto, MitalarmierteStelle

ALLOWED_IMAGE_CONTENT_TYPES = {"image/jpeg", "image/png", "image/gif", "image/webp", "image/bmp", "image/tiff"}


class EinsatzberichtFotoSerializer(serializers.ModelSerializer):
    foto_url = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = EinsatzberichtFoto
        fields = ["id", "foto", "foto_url", "dokument_typ", "created_at"]
        read_only_fields = ["id", "foto_url", "created_at"]

    def get_foto_url(self, obj):
        f = getattr(obj, "foto", None)
        try:
            return f.url if f and getattr(f, "name", "") else None
        except Exception:
            return None


class EinsatzberichtSerializer(serializers.ModelSerializer):
    fahrzeuge = serializers.PrimaryKeyRelatedField(queryset=Fahrzeug.objects.all(), many=True, required=False)
    mitglieder = serializers.PrimaryKeyRelatedField(queryset=Mitglied.objects.all(), many=True, required=False)
    mitalarmiert = serializers.PrimaryKeyRelatedField(
        source="mitalarmierte_stellen",
        queryset=MitalarmierteStelle.objects.all(),
        many=True,
        required=False,
    )
    einsatzleiter = serializers.CharField(required=False, allow_blank=True)
    einsatzart = serializers.CharField(required=False, allow_blank=True)
    alarmstichwort = serializers.CharField(required=False, allow_blank=True)
    einsatzadresse = serializers.CharField(required=False, allow_blank=True)
    alarmierende_stelle = serializers.CharField(required=False, allow_blank=True)
    fotos = EinsatzberichtFotoSerializer(many=True, read_only=True)

    class Meta:
        model = Einsatzbericht
        fields = [
            "id",
            "status",
            "einsatzleiter",
            "einsatzart",
            "alarmstichwort",
            "einsatzadresse",
            "alarmierende_stelle",
            "einsatz_datum",
            "ausgerueckt",
            "eingerueckt",
            "lage_beim_eintreffen",
            "gesetzte_massnahmen",
            "brand_kategorie",
            "brand_aus",
            "technisch_kategorie",
            "bma_meldergruppe",
            "bma_melder",
            "bma_fehl_tauschungsalarm",
            "mitalarmiert",
            "blaulichtsms_einsatz_id",
            "blaulichtsms_payload",
            "fahrzeuge",
            "mitglieder",
            "fotos",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "created_at", "updated_at"]

    def validate_einsatzleiter(self, value):
        normalized = str(value or "").strip()
        if not normalized:
            return normalized

        instance = getattr(self, "instance", None)
        incoming_status = self.initial_data.get("status") if hasattr(self, "initial_data") else None
        bericht_status = str(incoming_status or getattr(instance, "status", Einsatzbericht.Status.ENTWURF)).strip()
        if bericht_status == Einsatzbericht.Status.STATISTIK:
            return normalized

        instance = getattr(self, "instance", None)
        if instance and instance.einsatzleiter == normalized:
            return normalized
        valid_labels = {
            f"{m.stbnr or ''} {m.vorname or ''} {m.nachname or ''}".strip()
            for m in Mitglied.objects.exclude(
                dienststatus__in=[Mitglied.Dienststatus.ABGEMELDET, Mitglied.Dienststatus.RESERVE]
            )
        }
        if normalized not in valid_labels:
            raise serializers.ValidationError("Der Einsatzleiter muss ein aktives Mitglied sein.")
        return normalized

    def validate(self, attrs):
        request = self.context.get("request")
        if request:
            upload_keys = ("fotos", "fotos_doku", "fotos_zulassung", "fotos_versicherung")
            for key in upload_keys:
                for f in request.FILES.getlist(key):
                    content_type = getattr(f, "content_type", "") or ""
                    if not content_type.startswith("image/") or content_type not in ALLOWED_IMAGE_CONTENT_TYPES:
                        raise serializers.ValidationError(
                            {"foto": f"Nur Bilder sind erlaubt. '{f.name}' ist kein gültiges Bildformat."}
                        )

        instance = getattr(self, "instance", None)
        einsatzart = attrs.get("einsatzart", getattr(instance, "einsatzart", ""))
        bericht_status = attrs.get("status", getattr(instance, "status", Einsatzbericht.Status.ENTWURF))

        if bericht_status == Einsatzbericht.Status.STATISTIK:
            statistik_defaults = {
                "einsatzleiter": "Statistik",
                "einsatzart": "Statistik",
                "alarmstichwort": "Statistik",
                "einsatzadresse": "Statistik",
                "alarmierende_stelle": "Statistik",
                "eingerueckt": "00:00",
                "lage_beim_eintreffen": "Automatisch ergänzt (Statistik)",
                "gesetzte_massnahmen": "Automatisch ergänzt (Statistik)",
            }
            for field_name, fallback in statistik_defaults.items():
                value = attrs.get(field_name, getattr(instance, field_name, None) if instance else None)
                if value in (None, ""):
                    attrs[field_name] = fallback

            einsatzart = attrs.get("einsatzart", einsatzart)
        else:
            required_fields = (
                "einsatzleiter",
                "einsatzart",
                "alarmstichwort",
                "einsatzadresse",
                "alarmierende_stelle",
            )
            missing_fields = {}
            for field_name in required_fields:
                value = attrs.get(field_name, getattr(instance, field_name, ""))
                if not str(value or "").strip():
                    missing_fields[field_name] = "Dieses Feld ist erforderlich."
            if missing_fields:
                raise serializers.ValidationError(missing_fields)

        is_brandeinsatz = str(einsatzart).strip() in {"Brandeinsatz", "Brand"}
        is_technisch = str(einsatzart).strip() in {"Technischer Einsatz", "Technisch"}

        if not is_brandeinsatz:
            attrs["brand_kategorie"] = ""
            attrs["brand_aus"] = None

        if not is_technisch:
            attrs["technisch_kategorie"] = ""

        return attrs

    def _create_uploaded_fotos(self, request, instance):
        if not request:
            return

        upload_map = [
            ("fotos", EinsatzberichtFoto.DokumentTyp.ALLGEMEIN),
            ("fotos_doku", EinsatzberichtFoto.DokumentTyp.DOKU),
            ("fotos_zulassung", EinsatzberichtFoto.DokumentTyp.ZULASSUNG),
            ("fotos_versicherung", EinsatzberichtFoto.DokumentTyp.VERSICHERUNG),
        ]

        for key, dokument_typ in upload_map:
            for f in request.FILES.getlist(key):
                content_type = getattr(f, "content_type", "") or ""
                if not content_type.startswith("image/") or content_type not in ALLOWED_IMAGE_CONTENT_TYPES:
                    continue
                EinsatzberichtFoto.objects.create(
                    einsatzbericht=instance,
                    foto=f,
                    dokument_typ=dokument_typ,
                )

    def create(self, validated_data):
        request = self.context.get("request")
        fahrzeuge = validated_data.pop("fahrzeuge", [])
        mitglieder = validated_data.pop("mitglieder", [])
        mitalarmierte_stellen = validated_data.pop("mitalarmierte_stellen", [])

        instance = Einsatzbericht.objects.create(**validated_data)
        instance.fahrzeuge.set(fahrzeuge)
        instance.mitglieder.set(mitglieder)
        instance.mitalarmierte_stellen.set(mitalarmierte_stellen)

        if request and request.user and request.user.is_authenticated:
            instance.created_by = request.user
            instance.save(update_fields=["created_by"])

        self._create_uploaded_fotos(request, instance)

        return instance

    def update(self, instance, validated_data):
        request = self.context.get("request")
        fahrzeuge = validated_data.pop("fahrzeuge", None)
        mitglieder = validated_data.pop("mitglieder", None)
        mitalarmierte_stellen = validated_data.pop("mitalarmierte_stellen", None)

        for key, value in validated_data.items():
            setattr(instance, key, value)
        instance.save()

        if fahrzeuge is not None:
            instance.fahrzeuge.set(fahrzeuge)
        if mitglieder is not None:
            instance.mitglieder.set(mitglieder)
        if mitalarmierte_stellen is not None:
            instance.mitalarmierte_stellen.set(mitalarmierte_stellen)

        self._create_uploaded_fotos(request, instance)

        return instance


class EinsatzberichtContextSerializer(serializers.Serializer):
    fahrzeuge = serializers.ListField()
    mitglieder = serializers.ListField()