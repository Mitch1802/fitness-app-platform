from datetime import date
from unittest.mock import Mock, patch

import requests
from django.core.files.uploadedfile import SimpleUploadedFile
from rest_framework import status
from rest_framework.test import APITestCase

from core_apps.common.test_helpers import EndpointSmokeMixin
from core_apps.einsatzberichte.models import Einsatzbericht, EinsatzberichtFoto
from core_apps.mitglieder.models import Mitglied
from core_apps.modul_konfiguration.models import ModulKonfiguration
from core_apps.pdf.models import PdfTemplate
from core_apps.users.models import User


class EinsatzberichteEndpointTests(EndpointSmokeMixin, APITestCase):
    def setUp(self):
        self.user_bericht = self.create_user_with_roles("BERICHT")
        self.user_verwaltung = self.create_user_with_roles("VERWALTUNG")
        self.user_admin = self.create_user_with_roles("ADMIN")
        self.user_mitglied = self.create_user_with_roles("MITGLIED")

        self.bericht = Einsatzbericht.objects.create(
            einsatzleiter="Max Mustermann",
            einsatzart="Brandeinsatz",
            alarmstichwort="B2",
            einsatzadresse="Musterweg 1",
            alarmierende_stelle="AAZ",
            status=Einsatzbericht.Status.ENTWURF,
        )

    def test_context_payload_contains_expected_keys(self):
        self.client.force_authenticate(user=self.user_bericht)
        response = self.request_method("get", "einsatzberichte/context/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("fahrzeuge", response.data)
        self.assertIn("mitglieder", response.data)
        self.assertIn("mitalarmiert_stellen", response.data)

    def test_context_excludes_reserve_members(self):
        Mitglied.objects.create(
            stbnr=2001,
            vorname="Aktiv",
            nachname="Mitglied",
            svnr="1234",
            geburtsdatum=date(1990, 1, 1),
            dienststatus="AKTIV",
        )
        Mitglied.objects.create(
            stbnr=2002,
            vorname="Reserve",
            nachname="Mitglied",
            svnr="5678",
            geburtsdatum=date(1991, 1, 1),
            dienststatus="RESERVE",
        )

        self.client.force_authenticate(user=self.user_bericht)
        response = self.request_method("get", "einsatzberichte/context/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        stbnr_list = [item.get("stbnr") for item in response.data.get("mitglieder", [])]
        self.assertIn(2001, stbnr_list)
        self.assertNotIn(2002, stbnr_list)

    def test_mitglied_role_is_forbidden(self):
        self.client.force_authenticate(user=self.user_mitglied)
        response = self.request_method("get", "einsatzberichte/context/")
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_verwaltung_role_can_read_context(self):
        self.client.force_authenticate(user=self.user_verwaltung)
        response = self.request_method("get", "einsatzberichte/context/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_bericht_can_update_content(self):
        self.client.force_authenticate(user=self.user_bericht)
        response = self.request_method(
            "patch",
            f"einsatzberichte/{self.bericht.id}/",
            data={
                "status": self.bericht.status,
                "alarmstichwort": "B3",
            },
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.bericht.refresh_from_db()
        self.assertEqual(self.bericht.alarmstichwort, "B3")

    def test_verwaltung_can_update_content(self):
        self.client.force_authenticate(user=self.user_verwaltung)
        response = self.request_method(
            "patch",
            f"einsatzberichte/{self.bericht.id}/",
            data={"alarmstichwort": "B4"},
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.bericht.refresh_from_db()
        self.assertEqual(self.bericht.alarmstichwort, "B4")

    def test_status_change_only_admin_or_verwaltung(self):
        self.client.force_authenticate(user=self.user_bericht)
        forbidden_response = self.request_method(
            "patch",
            f"einsatzberichte/{self.bericht.id}/",
            data={"status": Einsatzbericht.Status.GESENDET},
        )
        self.assertEqual(forbidden_response.status_code, status.HTTP_403_FORBIDDEN)

        self.client.force_authenticate(user=self.user_verwaltung)
        verwaltung_response = self.request_method(
            "patch",
            f"einsatzberichte/{self.bericht.id}/",
            data={"status": Einsatzbericht.Status.GESENDET},
        )
        self.assertEqual(verwaltung_response.status_code, status.HTTP_200_OK)

        self.client.force_authenticate(user=self.user_admin)
        admin_response = self.request_method(
            "patch",
            f"einsatzberichte/{self.bericht.id}/",
            data={"status": Einsatzbericht.Status.FDISK_EINGETRAGEN},
        )
        self.assertEqual(admin_response.status_code, status.HTTP_200_OK)

    def test_verwaltung_can_create_report(self):
        self.client.force_authenticate(user=self.user_verwaltung)
        payload = {
            "status": Einsatzbericht.Status.ENTWURF,
            "einsatzleiter": "Test",
            "einsatzart": "Brandeinsatz",
            "alarmstichwort": "B1",
            "einsatzadresse": "Adresse 1",
            "alarmierende_stelle": "AAZ",
        }
        response = self.request_method("post", "einsatzberichte/", data=payload)

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_bericht_can_create_report(self):
        self.client.force_authenticate(user=self.user_bericht)
        payload = {
            "status": Einsatzbericht.Status.ENTWURF,
            "einsatzleiter": "Test",
            "einsatzart": "Brandeinsatz",
            "alarmstichwort": "B1",
            "einsatzadresse": "Adresse 1",
            "alarmierende_stelle": "AAZ",
        }
        response = self.request_method("post", "einsatzberichte/", data=payload)

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_statistik_status_auto_fills_required_fields(self):
        self.client.force_authenticate(user=self.user_verwaltung)
        payload = {
            "status": Einsatzbericht.Status.STATISTIK,
            "einsatz_datum": "2026-05-01",
            "ausgerueckt": "12:30",
            "mitglieder": [],
        }
        response = self.request_method("post", "einsatzberichte/", data=payload)

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        created = Einsatzbericht.objects.get(id=response.data["id"])
        self.assertEqual(created.status, Einsatzbericht.Status.STATISTIK)
        self.assertEqual(created.einsatzleiter, "Statistik")
        self.assertEqual(created.einsatzart, "Statistik")
        self.assertEqual(created.alarmstichwort, "Statistik")
        self.assertEqual(created.einsatzadresse, "Statistik")
        self.assertEqual(created.alarmierende_stelle, "Statistik")
        self.assertEqual(created.eingerueckt.strftime("%H:%M"), "00:00")
        self.assertEqual(created.lage_beim_eintreffen, "Automatisch ergänzt (Statistik)")
        self.assertEqual(created.gesetzte_massnahmen, "Automatisch ergänzt (Statistik)")

    def test_bericht_cannot_delete_report(self):
        self.client.force_authenticate(user=self.user_bericht)
        response = self.request_method("delete", f"einsatzberichte/{self.bericht.id}/")

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertTrue(Einsatzbericht.objects.filter(id=self.bericht.id).exists())

    def test_verwaltung_can_delete_report(self):
        self.client.force_authenticate(user=self.user_verwaltung)
        response = self.request_method("delete", f"einsatzberichte/{self.bericht.id}/")

        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Einsatzbericht.objects.filter(id=self.bericht.id).exists())

    def test_blaulichtsms_letzter_uses_dashboard_session_id(self):
        self.client.force_authenticate(user=self.user_bericht)

        response_payload = {
            "customerId": "123456",
            "customerName": "FF Test",
            "username": "dashboard",
            "integrations": [],
            "infos": [],
            "alarms": [
                {
                    "alarmId": "older",
                    "alarmDate": "2026-03-10T16:00:00.000Z",
                    "endDate": "2026-03-10T16:30:00.000Z",
                    "authorName": "Alt",
                    "alarmText": "Alter Alarm",
                    "type": "Technik",
                    "alarmGroups": [{"groupName": "AAZ"}],
                    "geolocation": {"address": "Altgasse 1"},
                },
                {
                    "alarmId": "latest",
                    "alarmDate": "2026-03-10T17:30:21.345Z",
                    "endDate": "2026-03-10T18:05:00.000Z",
                    "authorName": "Neu",
                    "alarmText": "Neuester Alarm",
                    "type": "Brand",
                    "alarmGroups": [{"groupName": "BLS"}],
                    "geolocation": {"address": "Hauptplatz 1"},
                },
            ],
        }

        mock_response = Mock()
        mock_response.content = b'{"ok": true}'
        mock_response.json.return_value = response_payload
        mock_response.raise_for_status.return_value = None

        with patch("core_apps.einsatzberichte.views.requests.get", return_value=mock_response) as mock_get, patch(
            "core_apps.einsatzberichte.views.settings.BLAULICHTSMS_API_URL",
            "https://api.blaulichtsms.net/blaulicht",
        ), patch(
            "core_apps.einsatzberichte.views.settings.BLAULICHTSMS_DASHBOARD_SESSION_ID",
            "session-123",
        ), patch("core_apps.einsatzberichte.views.settings.BLAULICHTSMS_TIMEOUT", 12):
            response = self.request_method("get", "einsatzberichte/blaulichtsms/letzter/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["mapped"]["blaulichtsms_einsatz_id"], "latest")
        self.assertEqual(response.data["mapped"]["alarmstichwort"], "Neuester Alarm")
        self.assertEqual(response.data["mapped"]["alarmierende_stelle"], "BLS")
        self.assertEqual(response.data["mapped"]["einsatzadresse"], "Hauptplatz 1")
        mock_get.assert_called_once_with(
            "https://api.blaulichtsms.net/blaulicht/api/alarm/v1/dashboard/session-123",
            headers={"Accept": "application/json"},
            timeout=12,
        )

    def test_blaulichtsms_letzter_converts_alarm_time_to_vienna_timezone(self):
        self.client.force_authenticate(user=self.user_bericht)

        response_payload = {
            "alarms": [
                {
                    "alarmId": "latest",
                    "alarmDate": "2026-03-10T23:30:00.000Z",
                    "alarmText": "Zeitzonen Test",
                    "type": "Brand",
                    "alarmGroups": [{"authorName": "AAZ"}],
                }
            ],
        }

        mock_response = Mock()
        mock_response.content = b'{"ok": true}'
        mock_response.json.return_value = response_payload
        mock_response.raise_for_status.return_value = None

        with patch("core_apps.einsatzberichte.views.requests.get", return_value=mock_response), patch(
            "core_apps.einsatzberichte.views.settings.BLAULICHTSMS_API_URL",
            "https://api.blaulichtsms.net/blaulicht",
        ), patch(
            "core_apps.einsatzberichte.views.settings.BLAULICHTSMS_DASHBOARD_SESSION_ID",
            "session-123",
        ):
            response = self.request_method("get", "einsatzberichte/blaulichtsms/letzter/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["mapped"]["einsatz_datum"], "2026-03-11")
        self.assertEqual(response.data["mapped"]["ausgerueckt"], "00:30")

    def test_blaulichtsms_letzter_requires_dashboard_session_id(self):
        self.client.force_authenticate(user=self.user_bericht)

        with patch("core_apps.einsatzberichte.views.settings.BLAULICHTSMS_API_URL", "https://api.blaulichtsms.net/blaulicht"), patch(
            "core_apps.einsatzberichte.views.settings.BLAULICHTSMS_DASHBOARD_SESSION_ID",
            "",
        ):
            response = self.request_method("get", "einsatzberichte/blaulichtsms/letzter/")

        self.assertEqual(response.status_code, status.HTTP_503_SERVICE_UNAVAILABLE)
        self.assertEqual(response.data["configured"], False)

    def test_blaulichtsms_letzter_returns_gateway_error_for_expired_dashboard_session(self):
        self.client.force_authenticate(user=self.user_bericht)

        mock_response = Mock(status_code=status.HTTP_401_UNAUTHORIZED)
        http_error = requests.HTTPError(response=mock_response)

        with patch("core_apps.einsatzberichte.views.requests.get", side_effect=http_error), patch(
            "core_apps.einsatzberichte.views.settings.BLAULICHTSMS_API_URL",
            "https://api.blaulichtsms.net/blaulicht",
        ), patch(
            "core_apps.einsatzberichte.views.settings.BLAULICHTSMS_DASHBOARD_SESSION_ID",
            "expired-session",
        ):
            response = self.request_method("get", "einsatzberichte/blaulichtsms/letzter/")

        self.assertEqual(response.status_code, status.HTTP_502_BAD_GATEWAY)

    @patch("core_apps.einsatzberichte.views.EmailMessage.send", return_value=1)
    @patch("core_apps.einsatzberichte.views.PdfTemplateService.render_pdf_bytes", return_value=b"%PDF-1.4")
    @patch("core_apps.einsatzberichte.views.PdfTemplateService.render_html", return_value=("<html></html>", "", ""))
    def test_bericht_can_send_report_and_status_changes_to_gesendet(self, *_mocks):
        template = PdfTemplate.objects.create(
            typ="EINSATZBERICHT",
            bezeichnung="Standard",
            version=1,
            status=PdfTemplate.Status.PUBLISHED,
            source="<!--PDF:BODY--><main>ok</main>",
        )
        recipient_member = Mitglied.objects.create(
            stbnr=3001,
            vorname="Empfaenger",
            nachname="Person",
            svnr="9900",
            geburtsdatum=date(1992, 1, 1),
            dienststatus="AKTIV",
        )
        recipient_user = User.objects.create_user(
            username="empfaenger_user",
            password="T3st!PasswortSehrSicher",
            email="empfaenger@example.com",
            mitglied=recipient_member,
        )
        self.assertIsNotNone(recipient_user.pk)

        ModulKonfiguration.objects.create(
            modul="pdf",
            konfiguration={
                "idEinsatzberichtPdf": str(template.id),
                "einsatzberichtEmpfaengerMitgliedPkid": recipient_member.pkid,
            },
        )

        self.client.force_authenticate(user=self.user_bericht)
        response = self.request_method("post", f"einsatzberichte/{self.bericht.id}/senden/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.bericht.refresh_from_db()
        self.assertEqual(self.bericht.status, Einsatzbericht.Status.GESENDET)

    @patch("core_apps.einsatzberichte.views.EmailMessage.send", return_value=1)
    @patch("core_apps.einsatzberichte.views.PdfTemplateService.render_pdf_bytes", return_value=b"%PDF-1.4")
    @patch("core_apps.einsatzberichte.views.PdfTemplateService.render_html", return_value=("<html></html>", "", ""))
    def test_send_requires_pdf_configuration(self, *_mocks):
        self.client.force_authenticate(user=self.user_bericht)
        response = self.request_method("post", f"einsatzberichte/{self.bericht.id}/senden/")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_only_admin_or_verwaltung_can_set_fdisk_status(self):
        self.bericht.status = Einsatzbericht.Status.GESENDET
        self.bericht.save(update_fields=["status"])

        self.client.force_authenticate(user=self.user_bericht)
        forbidden_response = self.request_method("post", f"einsatzberichte/{self.bericht.id}/fdisk-eingetragen/")
        self.assertEqual(forbidden_response.status_code, status.HTTP_403_FORBIDDEN)

        self.client.force_authenticate(user=self.user_verwaltung)
        verwaltung_response = self.request_method("post", f"einsatzberichte/{self.bericht.id}/fdisk-eingetragen/")
        self.assertEqual(verwaltung_response.status_code, status.HTTP_200_OK)

        self.bericht.status = Einsatzbericht.Status.GESENDET
        self.bericht.save(update_fields=["status"])

        self.client.force_authenticate(user=self.user_admin)
        admin_response = self.request_method("post", f"einsatzberichte/{self.bericht.id}/fdisk-eingetragen/")
        self.assertEqual(admin_response.status_code, status.HTTP_200_OK)

        self.bericht.refresh_from_db()
        self.assertEqual(self.bericht.status, Einsatzbericht.Status.FDISK_EINGETRAGEN)

    @patch("core_apps.einsatzberichte.views.PdfTemplateService.render_pdf_bytes", return_value=b"%PDF-1.4")
    @patch("core_apps.einsatzberichte.views.PdfTemplateService.render_html", return_value=("<html></html>", "", ""))
    def test_pdf_render_uses_backend_payload_with_members_and_photos(self, mock_render_html, *_mocks):
        template = PdfTemplate.objects.create(
            typ="EINSATZBERICHT",
            bezeichnung="Standard",
            version=1,
            status=PdfTemplate.Status.PUBLISHED,
            source="<!--PDF:BODY--><main>ok</main>",
        )
        ModulKonfiguration.objects.create(
            modul="pdf",
            konfiguration={
                "idEinsatzberichtPdf": str(template.id),
            },
        )

        member = Mitglied.objects.create(
            stbnr=4001,
            vorname="Druck",
            nachname="Mitglied",
            svnr="123456",
            geburtsdatum=date(1990, 5, 1),
            dienststatus="AKTIV",
        )
        self.bericht.mitglieder.add(member)

        foto_file = SimpleUploadedFile("doku.jpg", b"fake-jpg-bytes", content_type="image/jpeg")
        EinsatzberichtFoto.objects.create(
            einsatzbericht=self.bericht,
            foto=foto_file,
            dokument_typ=EinsatzberichtFoto.DokumentTyp.DOKU,
        )

        self.client.force_authenticate(user=self.user_verwaltung)
        response = self.request_method("post", f"einsatzberichte/{self.bericht.id}/pdf-render/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response["Content-Type"], "application/pdf")
        self.assertTrue(response.content.startswith(b"%PDF"))

        self.assertTrue(mock_render_html.called)
        payload = mock_render_html.call_args[0][1]
        self.assertEqual(len(payload.get("mitglieder_liste") or []), 1)
        self.assertEqual(len(payload.get("fotos_base64") or []), 1)
