"""
Celery tasks for automated backup creation and cleanup.
"""
import datetime
import logging
import os
import subprocess
import zipfile

import environ
from celery import shared_task

from core_apps.common.logging_utils import log_event, log_exception

env = environ.Env()
logger = logging.getLogger(__name__)
LOG_SOURCE = "backup"

backup_path = "/app/backups/"
uploaded_files_dir = "/app/mediafiles/"

# Tabelle, die nicht exportiert werden sollen
excluded_tables = [
    "account_emailaddress",
    "account_emailconfirmation",
    "auth_group",
    "auth_group_permissions",
    "auth_permission",
    "authtoken_token",
    "django_admin_log",
    "django_content_type",
    "django_migrations",
    "django_session",
    "socialaccount_socialaccount",
    "socialaccount_socialapp",
    "socialaccount_socialtoken",
]


@shared_task(bind=True, max_retries=3)
def auto_backup_and_cleanup(self):
    """
    Automatically create a backup and delete backups older than 2 months.

    This task runs every Sunday at 3 AM.
    """
    try:
        version = env("VERSION")
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        sql_filename = f"backup_{version}_{timestamp}.sql"
        sql_path = os.path.join(backup_path, sql_filename)

        pg_dump_cmd = [
            "pg_dump",
            "--host", env("POSTGRES_HOST"),
            "--username", env("POSTGRES_USER"),
            "--dbname", env("POSTGRES_DB"),
            "--encoding=UTF8",
            "--data-only",
            "--no-owner",
            "--no-acl",
        ]

        for table in excluded_tables:
            pg_dump_cmd.extend(["--exclude-table", f"public.{table}"])

        pg_dump_cmd.extend(["--file", sql_path])

        subprocess.run(
            pg_dump_cmd,
            check=True,
            env={"PGPASSWORD": env("POSTGRES_PASSWORD")},
        )

        zip_filename = f"backup_{version}_{timestamp}.zip"
        zip_path = os.path.join(backup_path, zip_filename)

        with zipfile.ZipFile(zip_path, "w") as zipf:
            zipf.write(sql_path, os.path.basename(sql_path))

            for root, _, files in os.walk(uploaded_files_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.join(
                        "uploaded_files",
                        os.path.relpath(file_path, uploaded_files_dir),
                    )
                    zipf.write(file_path, arcname)

        os.remove(sql_path)
        log_event(logger, LOG_SOURCE, "auto_backup_created", backup=zip_filename)
        logger.info(f"Automatisches Backup {zip_filename} wurde erfolgreich erstellt.")

        # Delete backups older than 2 months
        cutoff = datetime.datetime.now() - datetime.timedelta(days=60)
        deleted_count = 0
        for filename in os.listdir(backup_path):
            if not filename.endswith(".zip"):
                continue
            filepath = os.path.join(backup_path, filename)
            try:
                mtime = datetime.datetime.fromtimestamp(os.path.getmtime(filepath))
                if mtime < cutoff:
                    os.remove(filepath)
                    log_event(logger, LOG_SOURCE, "auto_backup_deleted_old", backup=filename)
                    logger.info(f"Altes Backup gelöscht: {filename}")
                    deleted_count += 1
            except OSError as e:
                log_exception(logger, LOG_SOURCE, "auto_backup_delete_failed", backup=filename, error=str(e))

        logger.info(
            f"Automatische Backup-Bereinigung abgeschlossen: {deleted_count} alte(s) Backup(s) gelöscht."
        )

    except subprocess.CalledProcessError as exc:
        log_exception(logger, LOG_SOURCE, "auto_backup_create_failed", error=str(exc))
        raise self.retry(exc=exc, countdown=60)
    except Exception as exc:
        logger.exception(f"Automatischer Backup-Task fehlgeschlagen: {exc}")
        raise self.retry(exc=exc, countdown=60)
