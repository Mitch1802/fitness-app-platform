from rest_framework import serializers

from .models import VerwaltungDokument


class VerwaltungDokumentSerializer(serializers.ModelSerializer):
    created_by_username = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = VerwaltungDokument
        fields = [
            "id",
            "typ",
            "title",
            "payload",
            "is_template",
            "source_template",
            "created_by",
            "created_by_username",
            "created_at",
            "updated_at",
        ]
        read_only_fields = [
            "id",
            "source_template",
            "created_by",
            "created_by_username",
            "created_at",
            "updated_at",
        ]

    def get_created_by_username(self, obj: VerwaltungDokument) -> str:
        if not obj.created_by:
            return ""
        return str(obj.created_by.username or "")
