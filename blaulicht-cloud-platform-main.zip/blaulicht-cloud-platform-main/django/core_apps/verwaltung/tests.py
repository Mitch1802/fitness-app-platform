from types import SimpleNamespace
from unittest.mock import patch

import requests
from rest_framework import status
from rest_framework.test import APITestCase

from core_apps.common.test_helpers import EndpointSmokeMixin
from core_apps.konfiguration.models import Konfiguration
from core_apps.modul_konfiguration.models import ModulKonfiguration
from core_apps.pdf.models import PdfTemplate
from core_apps.verwaltung.models import VerwaltungDokument


class VerwaltungEndpointTests(EndpointSmokeMixin, APITestCase):
    def setUp(self):
        self.admin = self.create_user_with_roles("ADMIN")
        ModulKonfiguration.objects.create(modul="news", konfiguration={"enabled": True})
        Konfiguration.objects.create(fw_nummer="123", fw_name="FF Test")

    def test_all_verwaltung_endpoints_resolve(self):
        endpoints = [
            "verwaltung/",
            "verwaltung/kontakte/",
            "verwaltung/dokumente/",
        ]

        for endpoint in endpoints:
            with self.subTest(endpoint=endpoint):
                self.assert_options_works(endpoint)

    def test_verwaltung_requires_auth_and_role(self):
        self.assert_requires_authentication("verwaltung/")
        self.assert_forbidden_without_role("verwaltung/")
        self.assert_requires_authentication("verwaltung/kontakte/")
        self.assert_forbidden_without_role("verwaltung/kontakte/")
        self.assert_requires_authentication("verwaltung/dokumente/")
        self.assert_forbidden_without_role("verwaltung/dokumente/")

    def test_verwaltung_method_matrix_no_server_error(self):
        self.assert_method_matrix_no_server_error("verwaltung/")
        self.assert_method_matrix_no_server_error("verwaltung/kontakte/")
        self.assert_method_matrix_no_server_error("verwaltung/dokumente/")

    def test_verwaltung_get_returns_config_payload(self):
        self.client.force_authenticate(user=self.admin)

        response = self.request_method("get", "verwaltung/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsInstance(response.data.get("modul_konfig"), list)
        self.assertIsInstance(response.data.get("konfig"), list)
        self.assertIsNone(response.data.get("sevdesk"))

    def test_verwaltung_include_sevdesk_success(self):
        self.client.force_authenticate(user=self.admin)

        with patch("core_apps.verwaltung.views.requests.get") as mocked_get:
            mocked_get.return_value = SimpleNamespace(status_code=200, json=lambda: {"objects": [{"id": 1}]})
            response = self.request_method("get", "verwaltung/?includeSevdesk=1&sevdeskModul=basics")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["sevdesk"]["objects"], [{"id": 1}])

    def test_verwaltung_include_sevdesk_handles_non_200(self):
        self.client.force_authenticate(user=self.admin)

        with patch("core_apps.verwaltung.views.requests.get") as mocked_get:
            mocked_get.return_value = SimpleNamespace(status_code=500, json=lambda: {})
            response = self.request_method("get", "verwaltung/?includeSevdesk=1&sevdeskModul=Contact")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("failed", response.data["sevdesk"]["error"])

    def test_verwaltung_include_sevdesk_handles_request_exception(self):
        self.client.force_authenticate(user=self.admin)

        with patch("core_apps.verwaltung.views.requests.get", side_effect=requests.RequestException("boom")):
            response = self.request_method("get", "verwaltung/?includeSevdesk=1&sevdeskModul=Contact")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("exception", str(response.data["sevdesk"]["error"]).lower())

    def test_verwaltung_include_sevdesk_missing_token(self):
        self.client.force_authenticate(user=self.admin)

        with patch.dict("os.environ", {"SEVDESK_API_TOKEN": ""}):
            response = self.request_method("get", "verwaltung/?includeSevdesk=1&sevdeskModul=Contact")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("missing", str(response.data["sevdesk"]["error"]).lower())

    def test_verwaltung_kontakte_success(self):
        self.client.force_authenticate(user=self.admin)

        with patch("core_apps.verwaltung.views.requests.get") as mocked_get:
            mocked_get.side_effect = [
                SimpleNamespace(status_code=200, json=lambda: {"objects": [{"id": "c1"}]}),
                SimpleNamespace(status_code=200, json=lambda: {"objects": [{"id": "a1"}]}),
            ]
            response = self.request_method("get", "verwaltung/kontakte/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["Contact"], [{"id": "c1"}])
        self.assertEqual(response.data["ContactAddress"], [{"id": "a1"}])

    def test_verwaltung_kontakte_handles_request_exception(self):
        self.client.force_authenticate(user=self.admin)

        with patch("core_apps.verwaltung.views.requests.get", side_effect=requests.RequestException("boom")):
            response = self.request_method("get", "verwaltung/kontakte/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("exception", str(response.data.get("error2", "")).lower())

    def test_verwaltung_kontakte_handles_second_non_200(self):
        self.client.force_authenticate(user=self.admin)

        with patch("core_apps.verwaltung.views.requests.get") as mocked_get:
            mocked_get.side_effect = [
                SimpleNamespace(status_code=200, json=lambda: {"objects": [{"id": "c1"}]}),
                SimpleNamespace(status_code=500, json=lambda: {}),
            ]
            response = self.request_method("get", "verwaltung/kontakte/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("failed", str(response.data.get("error2", "")).lower())

    def test_verwaltung_kontakte_handles_first_non_200(self):
        self.client.force_authenticate(user=self.admin)

        with patch("core_apps.verwaltung.views.requests.get") as mocked_get:
            mocked_get.side_effect = [
                SimpleNamespace(status_code=500, json=lambda: {}),
                SimpleNamespace(status_code=200, json=lambda: {"objects": [{"id": "a1"}]}),
            ]
            response = self.request_method("get", "verwaltung/kontakte/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("failed", str(response.data.get("error", "")).lower())

    def test_verwaltung_kontakte_missing_token(self):
        self.client.force_authenticate(user=self.admin)

        with patch.dict("os.environ", {"SEVDESK_API_TOKEN": ""}):
            response = self.request_method("get", "verwaltung/kontakte/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("missing", str(response.data.get("error", "")).lower())

class VerwaltungDokumentEndpointTests(EndpointSmokeMixin, APITestCase):
    def setUp(self):
        self.admin = self.create_user_with_roles("ADMIN")
        self.other_admin = self.create_user_with_roles("ADMIN")
        self.client.force_authenticate(user=self.admin)

    def test_create_and_update_document(self):
        create_payload = {
            "typ": "rechnung",
            "title": "Rechnung Mai",
            "payload": {"invoice_nummer": "R-2026-05"},
            "is_template": False,
        }
        create_response = self.request_method("post", "verwaltung/dokumente/", data=create_payload)
        self.assertEqual(create_response.status_code, status.HTTP_201_CREATED)
        doc_id = create_response.data["id"]

        patch_response = self.request_method("patch", f"verwaltung/dokumente/{doc_id}/", data={"title": "Rechnung Juni"})
        self.assertEqual(patch_response.status_code, status.HTTP_200_OK)
        self.assertEqual(patch_response.data["title"], "Rechnung Juni")

    def test_list_filter_by_typ_and_template(self):
        VerwaltungDokument.objects.create(
            typ=VerwaltungDokument.Typ.RECHNUNG,
            title="Vorlage Rechnung",
            payload={"x": 1},
            is_template=True,
            created_by=self.admin,
        )
        VerwaltungDokument.objects.create(
            typ=VerwaltungDokument.Typ.TRANSPARENT,
            title="Transparent normal",
            payload={"y": 2},
            is_template=False,
            created_by=self.admin,
        )
        VerwaltungDokument.objects.create(
            typ=VerwaltungDokument.Typ.FEST,
            title="Fest Abrechnung",
            payload={"jahr": "2026", "tag": "2026-05-01"},
            is_template=False,
            created_by=self.admin,
        )

        filtered = self.request_method("get", "verwaltung/dokumente/?typ=rechnung&is_template=1")
        self.assertEqual(filtered.status_code, status.HTTP_200_OK)
        self.assertEqual(len(filtered.data), 1)
        self.assertEqual(filtered.data[0]["typ"], "rechnung")
        self.assertTrue(filtered.data[0]["is_template"])

        filtered_fest = self.request_method("get", "verwaltung/dokumente/?typ=fest&is_template=0")
        self.assertEqual(filtered_fest.status_code, status.HTTP_200_OK)
        self.assertEqual(len(filtered_fest.data), 1)
        self.assertEqual(filtered_fest.data[0]["typ"], "fest")

    def test_copy_from_template(self):
        template = VerwaltungDokument.objects.create(
            typ=VerwaltungDokument.Typ.TRANSPARENT,
            title="Transparent Vorlage",
            payload={"nummer": "T-1"},
            is_template=True,
            created_by=self.admin,
        )

        response = self.request_method(
            "post",
            f"verwaltung/dokumente/{template.id}/from-template/",
            data={"title": "Aus Vorlage erzeugt"},
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["title"], "Aus Vorlage erzeugt")
        self.assertFalse(response.data["is_template"])
        self.assertIsNotNone(response.data["source_template"])

    def test_copy_from_non_template_fails(self):
        doc = VerwaltungDokument.objects.create(
            typ=VerwaltungDokument.Typ.RECHNUNG,
            title="Normal",
            payload={"invoice_nummer": "R-1"},
            is_template=False,
            created_by=self.admin,
        )

        response = self.request_method("post", f"verwaltung/dokumente/{doc.id}/from-template/", data={})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_delete_document(self):
        doc = VerwaltungDokument.objects.create(
            typ=VerwaltungDokument.Typ.RECHNUNG,
            title="Löschen",
            payload={"invoice_nummer": "R-2"},
            is_template=False,
            created_by=self.other_admin,
        )

        response = self.request_method("delete", f"verwaltung/dokumente/{doc.id}/")
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

    def test_send_document_to_sevdesk_creates_draft_and_uploads_pdf(self):
        doc = VerwaltungDokument.objects.create(
            typ=VerwaltungDokument.Typ.RECHNUNG,
            title="Rechnung Juli",
            payload={
                "invoice_nummer": "KR-26001",
                "adress_name": "Muster GmbH",
                "adresse_strasse": "Musterweg 1",
                "adresse_plz": "12345",
                "adresse_ort": "Musterstadt",
                "positionen": [{"bezeichnung": "Leistung", "preis": 100}],
            },
            is_template=False,
            created_by=self.admin,
        )
        tmpl = PdfTemplate.objects.create(
            typ="verwaltung-rechnung",
            version=1,
            bezeichnung="Verwaltung Rechnung",
            status=PdfTemplate.Status.PUBLISHED,
            source="<!--PDF:BODY--><div>ok</div>",
        )
        ModulKonfiguration.objects.create(modul="pdf", konfiguration={"idVerwaltungRechnung": str(tmpl.id)})
        Konfiguration.objects.create(fw_nummer="123", fw_name="FF Test")

        with patch("core_apps.verwaltung.views.PdfTemplateService.render_html", return_value=("<html></html>", "", "")):
            with patch("core_apps.verwaltung.views.PdfTemplateService.render_pdf_bytes", return_value=b"%PDF-1.4"):
                with patch("core_apps.verwaltung.views.requests.post") as mocked_post:
                    mocked_post.side_effect = [
                        # Schritt 1: uploadTempFile → gibt Dateinamen-Hash zurück
                        SimpleNamespace(status_code=201, json=lambda: {"objects": {"filename": "abc123.pdf"}}, text=""),
                        # Schritt 2: saveVoucher → gibt Voucher-ID zurück
                        SimpleNamespace(status_code=201, json=lambda: {"objects": {"id": "4711"}}, text=""),
                    ]
                    response = self.request_method("post", f"verwaltung/dokumente/{doc.id}/sevdesk-beleg/", data={})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data.get("sevdesk_voucher_id"), "4711")
        self.assertEqual(mocked_post.call_count, 2)
        # Upload muss zuerst kommen
        first_call_url = mocked_post.call_args_list[0][0][0]
        second_call_url = mocked_post.call_args_list[1][0][0]
        self.assertIn("uploadTempFile", first_call_url)
        self.assertIn("saveVoucher", second_call_url)

    def test_send_document_to_sevdesk_requires_pdf_config(self):
        doc = VerwaltungDokument.objects.create(
            typ=VerwaltungDokument.Typ.TRANSPARENT,
            title="Transparent Juli",
            payload={"nummer": "TR-26001", "adress_name": "Muster GmbH"},
            is_template=False,
            created_by=self.admin,
        )

        response = self.request_method("post", f"verwaltung/dokumente/{doc.id}/sevdesk-beleg/", data={})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("Template", str(response.data.get("detail", "")))
