from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("verwaltung", "0001_initial"),
    ]

    operations = [
        migrations.AlterField(
            model_name="verwaltungdokument",
            name="typ",
            field=models.CharField(
                choices=[("rechnung", "Rechnung"), ("transparent", "Transparent"), ("fest", "Fest")],
                max_length=20,
            ),
        ),
    ]
