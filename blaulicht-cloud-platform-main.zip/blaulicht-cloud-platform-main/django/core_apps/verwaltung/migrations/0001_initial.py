from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import uuid


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="VerwaltungDokument",
            fields=[
                ("pkid", models.BigAutoField(editable=False, primary_key=True, serialize=False, unique=True)),
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, unique=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("typ", models.CharField(choices=[("rechnung", "Rechnung"), ("transparent", "Transparent")], max_length=20)),
                ("title", models.CharField(max_length=255)),
                ("payload", models.JSONField(blank=True, default=dict)),
                ("is_template", models.BooleanField(default=False)),
                ("created_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="verwaltung_dokumente", to=settings.AUTH_USER_MODEL)),
                ("source_template", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="derived_documents", to="verwaltung.verwaltungdokument")),
            ],
            options={
                "ordering": ["-updated_at", "-created_at"],
            },
        ),
    ]
