from django.urls import path
from django.urls import include
from rest_framework.routers import DefaultRouter

from .views import (
    VerwaltungGetView,
    VerwaltungGetKontakteView,
    VerwaltungDokumentViewSet,
)

router = DefaultRouter()
router.register(r"dokumente", VerwaltungDokumentViewSet, basename="verwaltung-dokumente")

urlpatterns = [
    path("", VerwaltungGetView.as_view(), name="verwaltung-list"),
    path("kontakte/", VerwaltungGetKontakteView.as_view(), name="verwaltung-kontakte-list"),
    path("", include(router.urls)),
]
