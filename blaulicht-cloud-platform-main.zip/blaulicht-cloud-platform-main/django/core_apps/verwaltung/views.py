import os
import requests
from datetime import date

from rest_framework import permissions
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from rest_framework.views import APIView

from core_apps.common.permissions import HasAnyRolePermission
from core_apps.modul_konfiguration.models import ModulKonfiguration
from core_apps.modul_konfiguration.serializers import ModulKonfigurationSerializer
from core_apps.konfiguration.models import Konfiguration
from core_apps.konfiguration.serializers import KonfigurationSerializer
from core_apps.pdf.models import PdfTemplate
from core_apps.pdf.services import PdfTemplateService
from .models import VerwaltungDokument
from .serializers import VerwaltungDokumentSerializer


class VerwaltungGetView(APIView):
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN", "VERWALTUNG")]

    def get(self, request, *args, **kwargs):
        modul_konfig = ModulKonfigurationSerializer(ModulKonfiguration.objects.all(), many=True).data
        konfig = KonfigurationSerializer(Konfiguration.objects.all(), many=True).data

        # --- sevDesk (optional via Queryparam aktivieren) ---
        include_sevdesk = request.query_params.get("includeSevdesk", "0") == "1"
        sevdesk_modul = request.query_params.get("sevdeskModul", "basics")
        sevdesk_modul_id = request.query_params.get("sevdeskModulId")
        sevdesk_objects = None
        sevdesk_error = None
        url = ""

        if include_sevdesk:
            token = os.getenv("SEVDESK_API_TOKEN", "422acb071f99fefd3e2c74d787fdfd98")
            base_url = os.getenv("SEVDESK_BASE_URL", "https://my.sevdesk.de/api/v1")

            if sevdesk_modul == "basics": sevdesk_modul= "Tools/bookkeepingSystemVersion"

            if not token:
                sevdesk_error = "SEVDESK_API_TOKEN missing"
            else: 
                try:
                    url = f"{base_url}/{sevdesk_modul}"

                    if sevdesk_modul_id: url += f"/{sevdesk_modul_id}"

                    r = requests.get(
                        url,
                        headers={"Authorization": token},
                        timeout=20,
                    )

                    if r.status_code == 200:
                        data = r.json()
                        sevdesk_objects = data.get("objects", data)
                    else:
                        sevdesk_error = f"sevDesk request failed ({r.status_code})"
                except requests.RequestException as e:
                    sevdesk_error = f"sevDesk request exception: {str(e)}"

        payload = {
            "modul_konfig": modul_konfig,
            "konfig": konfig,
            "sevdesk": {
                "objects": sevdesk_objects,
                "error": sevdesk_error,
            } if include_sevdesk else None
        }

        return Response(payload)
    

class VerwaltungGetKontakteView(APIView):
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN", "VERWALTUNG")]

    def get(self, request, *args, **kwargs):
        sevdesk_objects = None
        sevdesk_objects2 = None
        sevdesk_error = None
        sevdesk_error2 = None
        url = ""
        url2 = ""

        token = os.getenv("SEVDESK_API_TOKEN", "422acb071f99fefd3e2c74d787fdfd98")
        base_url = os.getenv("SEVDESK_BASE_URL", "https://my.sevdesk.de/api/v1")

        if not token:
            sevdesk_error = "SEVDESK_API_TOKEN missing"
        else: 
            try:
                url = f"{base_url}/Contact"
                r = requests.get(
                    url,
                    headers={"Authorization": token},
                    timeout=20,
                )

                if r.status_code == 200:
                    data = r.json()
                    sevdesk_objects = data.get("objects", data)
                else:
                    sevdesk_error = f"sevDesk request failed ({r.status_code})"
                
                

                url2 = f"{base_url}/ContactAddress"                
                r2 = requests.get(
                    url2,
                    headers={"Authorization": token},
                    timeout=20,
                )

                if r2.status_code == 200:
                    data2 = r2.json()
                    sevdesk_objects2 = data2.get("objects", data2)
                else:
                    sevdesk_error2 = f"sevDesk request failed ({r.status_code})"
            except requests.RequestException as e:
                sevdesk_error2 = f"sevDesk request exception: {str(e)}"

        payload = {
                "Contact": sevdesk_objects,
                "ContactAddress": sevdesk_objects2,
                "error": sevdesk_error,
                "error2": sevdesk_error2,
        }

        return Response(payload)


class VerwaltungDokumentViewSet(ModelViewSet):
    queryset = VerwaltungDokument.objects.select_related("created_by", "source_template").all()
    serializer_class = VerwaltungDokumentSerializer
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN", "VERWALTUNG")]
    pagination_class = None
    lookup_field = "id"

    def get_queryset(self):
        qs = super().get_queryset()

        typ = str(self.request.query_params.get("typ", "")).strip().lower()
        if typ in (VerwaltungDokument.Typ.RECHNUNG, VerwaltungDokument.Typ.TRANSPARENT, VerwaltungDokument.Typ.FEST):
            qs = qs.filter(typ=typ)

        is_template = str(self.request.query_params.get("is_template", "")).strip().lower()
        if is_template in ("1", "true", "yes"):
            qs = qs.filter(is_template=True)
        elif is_template in ("0", "false", "no"):
            qs = qs.filter(is_template=False)

        return qs

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=True, methods=["post"], url_path="from-template")
    def from_template(self, request, id=None):
        template = self.get_object()
        if not template.is_template:
            return Response({"detail": "Nur Vorlagen können kopiert werden."}, status=status.HTTP_400_BAD_REQUEST)

        copied = VerwaltungDokument.objects.create(
            typ=template.typ,
            title=str(request.data.get("title") or f"{template.title} (Kopie)"),
            payload=template.payload,
            is_template=bool(request.data.get("is_template", False)),
            source_template=template,
            created_by=request.user,
        )
        return Response(self.get_serializer(copied).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"], url_path="sevdesk-beleg")
    def sevdesk_beleg(self, request, id=None):
        dokument = self.get_object()

        token = os.getenv("SEVDESK_API_TOKEN", "422acb071f99fefd3e2c74d787fdfd98")
        base_url = os.getenv("SEVDESK_BASE_URL", "https://my.sevdesk.de/api/v1").rstrip("/")
        if not token:
            return Response({"detail": "SEVDESK_API_TOKEN missing"}, status=status.HTTP_400_BAD_REQUEST)

        template_id = self._get_pdf_template_id_for_typ(dokument.typ)
        if not template_id:
            return Response({"detail": "Kein PDF-Template für Verwaltung konfiguriert."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            tmpl = PdfTemplate.objects.get(id=template_id)
        except PdfTemplate.DoesNotExist:
            return Response({"detail": "Konfiguriertes PDF-Template wurde nicht gefunden."}, status=status.HTTP_400_BAD_REQUEST)

        render_payload = self._build_render_payload(dokument)
        try:
            html, header_html, footer_html = PdfTemplateService.render_html(tmpl, render_payload)
            pdf_bytes = PdfTemplateService.render_pdf_bytes(html, header_html, footer_html)
        except ValueError as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)

        beleg_nummer = self._get_document_number(dokument)
        heute = date.today().strftime("%d.%m.%Y")
        file_name = f"{beleg_nummer or dokument.typ}.pdf"

        # Schritt 1: PDF temporär hochladen und Dateinamen-Hash zurückbekommen
        try:
            upload_response = requests.post(
                f"{base_url}/Voucher/Factory/uploadTempFile",
                headers={"Authorization": token},
                files={"file": (file_name, pdf_bytes, "application/pdf")},
                timeout=30,
            )
        except requests.RequestException as e:
            return Response({"detail": f"sevDesk upload request exception: {str(e)}"}, status=status.HTTP_502_BAD_GATEWAY)

        if upload_response.status_code not in (200, 201):
            return Response(
                {"detail": f"sevDesk upload failed ({upload_response.status_code})", "sevdesk": upload_response.text},
                status=status.HTTP_502_BAD_GATEWAY,
            )

        upload_filename = upload_response.json().get("objects", {}).get("filename")

        # Schritt 2: Voucher als Entwurf erstellen und PDF anhängen
        create_payload = {
            "voucher": {
                "objectName": "Voucher",
                "mapAll": True,
                "voucherDate": heute,
                "voucherType": "VOU",
                "status": "50",
                "currency": "EUR",
                "creditDebit": "D",
                "taxType": "default",
                "description": beleg_nummer,
            },
            "voucherPosSave": [],
            "voucherPosDelete": None,
            "filename": upload_filename,
        }

        try:
            create_response = requests.post(
                f"{base_url}/Voucher/Factory/saveVoucher",
                headers={"Authorization": token, "Content-Type": "application/json"},
                json=create_payload,
                timeout=30,
            )
        except requests.RequestException as e:
            return Response({"detail": f"sevDesk create request exception: {str(e)}"}, status=status.HTTP_502_BAD_GATEWAY)

        if create_response.status_code not in (200, 201):
            return Response(
                {"detail": f"sevDesk create failed ({create_response.status_code})", "sevdesk": create_response.text},
                status=status.HTTP_502_BAD_GATEWAY,
            )

        create_data = create_response.json()
        voucher_obj = create_data.get("objects")
        if isinstance(voucher_obj, list):
            voucher_obj = voucher_obj[0] if voucher_obj else {}
        elif not isinstance(voucher_obj, dict):
            voucher_obj = create_data if isinstance(create_data, dict) else {}

        voucher_id = voucher_obj.get("id")
        if not voucher_id:
            return Response({"detail": "sevDesk create response enthält keine Voucher-ID."}, status=status.HTTP_502_BAD_GATEWAY)

        return Response({"sevdesk_voucher_id": str(voucher_id)}, status=status.HTTP_200_OK)

    def _get_pdf_template_id_for_typ(self, typ: str):
        konfig = ModulKonfiguration.objects.filter(modul="pdf").first()
        config = konfig.konfiguration if konfig and isinstance(konfig.konfiguration, dict) else {}
        if typ == VerwaltungDokument.Typ.RECHNUNG:
            return config.get("idVerwaltungRechnung")
        return config.get("idVerwaltungTransparent")

    def _get_document_number(self, dokument: VerwaltungDokument) -> str:
        payload = dokument.payload if isinstance(dokument.payload, dict) else {}
        if dokument.typ == VerwaltungDokument.Typ.RECHNUNG:
            return str(payload.get("invoice_nummer") or dokument.title)
        return str(payload.get("nummer") or dokument.title)

    def _build_render_payload(self, dokument: VerwaltungDokument):
        payload = dokument.payload if isinstance(dokument.payload, dict) else {}
        stammdaten = Konfiguration.objects.first()
        heute = date.today().strftime("%d.%m.%Y")

        basis = {
            "fw_name": getattr(stammdaten, "fw_name", ""),
            "fw_nummer": getattr(stammdaten, "fw_nummer", ""),
            "fw_street": getattr(stammdaten, "fw_street", ""),
            "fw_plz": getattr(stammdaten, "fw_plz", ""),
            "fw_ort": getattr(stammdaten, "fw_ort", ""),
            "fw_email": getattr(stammdaten, "fw_email", ""),
            "fw_telefon": getattr(stammdaten, "fw_telefon", ""),
            "fw_konto": getattr(stammdaten, "fw_konto", ""),
            "fw_iban": getattr(stammdaten, "fw_iban", ""),
            "fw_bic": getattr(stammdaten, "fw_bic", ""),
            "fw_kdt": getattr(stammdaten, "fw_kdt", ""),
            "invoice_datum": heute,
        }

        if dokument.typ == VerwaltungDokument.Typ.RECHNUNG:
            positionen = payload.get("positionen") if isinstance(payload.get("positionen"), list) else []
            invoice_items = []
            betrag_total = 0.0
            for item in positionen:
                pos = item if isinstance(item, dict) else {}
                preis = float(pos.get("preis") or 0)
                betrag_total += preis
                invoice_items.append(
                    {
                        "bezeichnung": str(pos.get("bezeichnung") or ""),
                        "preis": f"{preis:.2f}",
                    }
                )

            basis.update(
                {
                    "invoice_nummer": str(payload.get("invoice_nummer") or ""),
                    "customer_name": str(payload.get("adress_name") or ""),
                    "customer_street": str(payload.get("adresse_strasse") or ""),
                    "customer_plz": str(payload.get("adresse_plz") or ""),
                    "customer_ort": str(payload.get("adresse_ort") or ""),
                    "invoice_betreff": str(payload.get("betreff") or ""),
                    "invoice_anrede": str(payload.get("anrede") or ""),
                    "invoice_text": str(payload.get("text") or ""),
                    "invoice_items": invoice_items,
                    "invoice_total_betrag": f"{betrag_total:.2f}",
                }
            )
            return basis

        basis.update(
            {
                "customer_name": str(payload.get("adress_name") or ""),
                "customer_street": str(payload.get("adresse_strasse") or ""),
                "customer_plz": str(payload.get("adresse_plz") or ""),
                "customer_ort": str(payload.get("adresse_ort") or ""),
                "transparent_nummer": str(payload.get("nummer") or ""),
                "transparent_datumsbereich": str(payload.get("datumsbereich") or ""),
                "transparent_betrag": str(payload.get("betrag") or ""),
            }
        )
        return basis
