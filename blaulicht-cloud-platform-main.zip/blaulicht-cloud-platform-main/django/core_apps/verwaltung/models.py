from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _

from core_apps.common.models import TimeStampedModel


class VerwaltungDokument(TimeStampedModel):
    class Typ(models.TextChoices):
        RECHNUNG = "rechnung", _("Rechnung")
        TRANSPARENT = "transparent", _("Transparent")
        FEST = "fest", _("Fest")

    typ = models.CharField(max_length=20, choices=Typ.choices)
    title = models.CharField(max_length=255)
    payload = models.JSONField(blank=True, default=dict)
    is_template = models.BooleanField(default=False)
    source_template = models.ForeignKey(
        "self",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="derived_documents",
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="verwaltung_dokumente",
    )

    class Meta:
        ordering = ["-updated_at", "-created_at"]

    def __str__(self) -> str:
        return f"{self.typ}: {self.title}"
