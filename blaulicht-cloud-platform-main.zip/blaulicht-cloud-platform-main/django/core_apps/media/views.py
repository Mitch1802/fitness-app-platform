import os
from pathlib import Path

from django.conf import settings
from django.http import FileResponse, Http404
from django.db.utils import OperationalError, ProgrammingError
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from core_apps.common.permissions import HasAnyRolePermission
from core_apps.anwesenheitsliste.models import AnwesenheitslisteFoto
from core_apps.einsatzberichte.models import EinsatzberichtFoto
from core_apps.fahrzeuge.models import Fahrzeug, FahrzeugRaum
from core_apps.homepage.models import HomepageDienstposten
from core_apps.inventar.models import Inventar
from core_apps.news.models import News


def _as_bool(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "ja", "y", "j"}
    return bool(value)


def _safe_refset(model_class, image_field, subdirectory=None):
    prefix = f"{str(subdirectory).strip('/')}/" if subdirectory else ""

    try:
        values = model_class.objects.exclude(**{f"{image_field}__isnull": True}).exclude(
            **{image_field: ""}
        ).values_list(image_field, flat=True)

        references = set()
        for value in values:
            if not value:
                continue

            normalized = str(value).replace("\\", "/").lstrip("/")
            if prefix and normalized.startswith(prefix):
                references.add(normalized[len(prefix):])
                continue

            if prefix:
                references.add(normalized if "/" in normalized else Path(normalized).name)
                continue

            references.add(Path(normalized).name)

        return references, False
    except (OperationalError, ProgrammingError):
        return set(), True


def _collect_media_files(base_folder):
    return {
        file_path.relative_to(base_folder).as_posix()
        for file_path in base_folder.rglob("*")
        if file_path.is_file()
    }


class BaseMediaGetFileView(APIView):
    """Basisklasse für den Dateiabruf von Mediendateien."""
    permission_classes = [permissions.IsAuthenticated]
    subdirectory = ""

    def _resolve_file_path(self, filename: str) -> Path:
        media_root = Path(settings.MEDIA_ROOT).resolve()
        base_dir = (media_root / self.subdirectory).resolve() if self.subdirectory else media_root
        requested = (base_dir / filename).resolve()

        if not str(requested).startswith(str(base_dir)):
            raise Http404("Ungültiger Dateipfad!")

        return requested

    def get(self, request, filename, *args, **kwargs):
        file_path = self._resolve_file_path(filename)

        if not file_path.exists() or not file_path.is_file():
            raise Http404("Datei nicht gefunden!")

        return FileResponse(open(file_path, "rb"), as_attachment=False, filename=file_path.name)


class MediaNewsGetFileView(BaseMediaGetFileView):
    """Abruf von News-Mediendateien."""
    permission_classes = [permissions.AllowAny]
    subdirectory = "news"


class MediaHomepageGetFileView(BaseMediaGetFileView):
    """Abruf von Homepage-Mediendateien."""
    permission_classes = [permissions.AllowAny]
    subdirectory = "homepage"


class MediaFahrzeugeGetFileView(BaseMediaGetFileView):
    """Abruf von Fahrzeug-Mediendateien (inkl. Public-Checkliste)."""
    permission_classes = [permissions.AllowAny]
    subdirectory = "fahrzeuge"


class MediaInventarGetFileView(BaseMediaGetFileView):
    """Abruf von Inventar-Mediendateien."""
    subdirectory = "inventar"


class MediaEinsatzberichteGetFileView(BaseMediaGetFileView):
    """Abruf von Einsatzberichte-Mediendateien."""
    subdirectory = "einsatzberichte"


class MediaAnwesenheitslisteGetFileView(BaseMediaGetFileView):
    """Abruf von Anwesenheitslisten-Mediendateien."""
    subdirectory = "anwesenheitsliste"


class MediaAusbildungGetFileView(BaseMediaGetFileView):
    """Abruf von Ausbildungs-Mediendateien (nur intern)."""
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN", "AUSBILDUNG")]
    subdirectory = "ausbildung"


class MediaCleanupOrphansView(APIView):
    permission_classes = [permissions.IsAuthenticated, HasAnyRolePermission.with_roles("ADMIN")]

    def post(self, request, *args, **kwargs):
        target = request.data.get("target", "all")
        valid_targets = {"all", "news", "homepage", "fahrzeuge", "inventar", "einsatzberichte", "anwesenheitsliste"}
        if target not in valid_targets:
            allowed = ", ".join(sorted(valid_targets))
            return Response({"detail": f"target muss einer der folgenden Werte sein: {allowed}."}, status=status.HTTP_400_BAD_REQUEST)

        should_delete = _as_bool(request.data.get("delete", False))
        allow_missing_db = _as_bool(request.data.get("allow_missing_db", False))

        checks = []
        if target in ("all", "news"):
            checks.append(("news", lambda: _safe_refset(News, "foto")))
        if target in ("all", "homepage"):
            checks.append(("homepage", lambda: _safe_refset(HomepageDienstposten, "photo", "homepage")))
        if target in ("all", "fahrzeuge"):
            def _fahrzeuge_refs():
                fahrzeug_refs, fahrzeug_missing = _safe_refset(Fahrzeug, "foto", "fahrzeuge")
                raum_refs, raum_missing = _safe_refset(FahrzeugRaum, "foto", "fahrzeuge")
                return fahrzeug_refs | raum_refs, fahrzeug_missing or raum_missing

            checks.append(("fahrzeuge", _fahrzeuge_refs))
        if target in ("all", "inventar"):
            checks.append(("inventar", lambda: _safe_refset(Inventar, "foto")))
        if target in ("all", "einsatzberichte"):
            checks.append(("einsatzberichte", lambda: _safe_refset(EinsatzberichtFoto, "foto", "einsatzberichte")))
        if target in ("all", "anwesenheitsliste"):
            checks.append(("anwesenheitsliste", lambda: _safe_refset(AnwesenheitslisteFoto, "foto", "anwesenheitsliste")))

        media_root = Path(settings.MEDIA_ROOT)
        if not media_root.exists():
            return Response({"detail": f"MEDIA_ROOT existiert nicht: {media_root}"}, status=status.HTTP_400_BAD_REQUEST)

        summary = {
            "files": 0,
            "refs": 0,
            "orphan": 0,
        }
        result = {
            "dry_run": not should_delete,
            "deleted": 0,
            "missing_db_tables": False,
            "items": [],
            "summary": summary,
        }

        all_orphans = []

        for folder_name, ref_loader in checks:
            folder_path = media_root / folder_name
            if not folder_path.exists():
                result["items"].append(
                    {
                        "target": folder_name,
                        "skipped": True,
                        "reason": f"Ordner fehlt: {folder_path}",
                        "files": 0,
                        "refs": 0,
                        "orphan": 0,
                        "orphans": [],
                    }
                )
                continue

            files = _collect_media_files(folder_path)
            refs, missing_db = ref_loader()
            orphans = sorted(files - refs)

            summary["files"] += len(files)
            summary["refs"] += len(refs)
            summary["orphan"] += len(orphans)
            result["missing_db_tables"] = result["missing_db_tables"] or missing_db
            all_orphans.extend((folder_name, filename) for filename in orphans)

            result["items"].append(
                {
                    "target": folder_name,
                    "skipped": False,
                    "files": len(files),
                    "refs": len(refs),
                    "orphan": len(orphans),
                    "orphans": orphans,
                }
            )

        if should_delete and result["missing_db_tables"] and not allow_missing_db:
            return Response(
                {
                    **result,
                    "detail": "DB-Tabellen fehlen. Löschung blockiert. Nutze allow_missing_db=true nur bewusst.",
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        if should_delete:
            deleted = 0
            for folder_name, filename in all_orphans:
                file_path = media_root / folder_name / filename
                if file_path.exists() and file_path.is_file():
                    file_path.unlink()
                    deleted += 1
            result["deleted"] = deleted
            result["dry_run"] = False

        return Response(result)