from django.urls import path
from .views import (
    MediaFahrzeugeGetFileView,
    MediaHomepageGetFileView,
    MediaNewsGetFileView,
    MediaInventarGetFileView,
    MediaEinsatzberichteGetFileView,
    MediaAnwesenheitslisteGetFileView,
    MediaAusbildungGetFileView,
    MediaCleanupOrphansView,
)


urlpatterns = [
    path("news/<path:filename>", MediaNewsGetFileView.as_view(), name="news-file-get"),
    path("homepage/<path:filename>", MediaHomepageGetFileView.as_view(), name="homepage-file-get"),
    path("fahrzeuge/<path:filename>", MediaFahrzeugeGetFileView.as_view(), name="fahrzeuge-file-get"),
    path("inventar/<path:filename>", MediaInventarGetFileView.as_view(), name="inventar-file-get"),
    path("einsatzberichte/<path:filename>", MediaEinsatzberichteGetFileView.as_view(), name="einsatzberichte-file-get"),
    path("anwesenheitsliste/<path:filename>", MediaAnwesenheitslisteGetFileView.as_view(), name="anwesenheitsliste-file-get"),
    path("ausbildung/<path:filename>", MediaAusbildungGetFileView.as_view(), name="ausbildung-file-get"),
    path("cleanup-orphans/", MediaCleanupOrphansView.as_view(), name="media-cleanup-orphans"),
]
