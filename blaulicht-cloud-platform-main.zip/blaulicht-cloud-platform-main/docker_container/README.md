# Neuen Server aufsetzen

## Zielarchitektur

```text
Portainer   = Docker-Container verwalten
NPM         = Routing, Domains, SSL, Reverse Proxy
Uptime Kuma = Verfügbarkeit der Apps überwachen
Netdata     = Ressourcenverbrauch überwachen: CPU, RAM, Disk, Netzwerk
```

## Wichtige Docker-Infos

```text
ports  = vom Host / Internet erreichbar
expose = nur für andere Docker-Container im selben Docker-Netzwerk erreichbar

127.0.0.1:PORT:PORT = nur lokal auf dem Server erreichbar
localhost im Container = der Container selbst, nicht der Host
```

Empfohlene Grundregel:

```text
NPM: ports 80/443 öffentlich
NPM Admin 81: möglichst nur 127.0.0.1 oder per Access List/VPN schützen
Apps/Netdata/Uptime Kuma/Portainer: expose statt ports
```

## Hinweis:
NPM, Portainer und Uptime Kuma haben eigene Logins.
Trotzdem sollten Admin-Oberflächen zusätzlich geschützt werden, z. B. per NPM Access List, VPN oder IP-Whitelist.

Grund:
Diese Dienste sind administrative Kontrollflächen. Ein kompromittierter Login reicht aus, um Container, Proxy-Routen, Secrets oder Serverinformationen offenzulegen bzw. zu verändern.


## Docker & Docker Compose installieren

Docker nach offizieller Anleitung installieren.

## Docker-Netzwerk erstellen

```bash
docker network create -d bridge proxy
```

Dieses Netzwerk wird von Nginx Proxy Manager verwendet, um andere Container per Containername zu erreichen.

## Portainer starten

```bash
docker compose -f docker-compose-portainer.yml up -d
```

## Nginx Proxy Manager starten

```bash
docker compose -f docker-compose-npm.yml up -d
```

## Monitoring starten

```bash
docker compose -f docker-compose-monitoring.yml up -d
```

---

# Nginx Proxy Manager Konfiguration

## Proxy Host für NPM Admin UI

```text
Domain: npm.example.com
Scheme: http
Forward Hostname/IP: nginx-proxy-manager
Forward Port: 81
Websockets: enabled
SSL: Let's Encrypt
Force SSL: enabled
Access List: required
```

Wichtig: Die NPM Admin UI nicht ungeschützt öffentlich erreichbar machen.

## Proxy Host für Portainer

```text
Domain: portainer.example.com
Scheme: https
Forward Hostname/IP: portainer
Forward Port: 9443
Websockets: enabled
SSL: Let's Encrypt
Force SSL: enabled
Access List: required
```

Falls Portainer intern über HTTP läuft:

```text
Scheme: http
Forward Port: 9000
```

## Proxy Host für Netdata

```text
Domain: netdata.example.com
Scheme: http
Forward Hostname/IP: netdata
Forward Port: 19999
Websockets: enabled
SSL: Let's Encrypt
Force SSL: enabled
Access List: required
```

Netdata zeigt viele Host- und Containerdetails. Nicht öffentlich ohne Schutz bereitstellen.

## Proxy Host für Uptime Kuma Admin UI

```text
Domain: kuma.example.com
Scheme: http
Forward Hostname/IP: uptime-kuma
Forward Port: 3001
Websockets: enabled
SSL: Let's Encrypt
Force SSL: enabled
Access List: required
```

## Optional: Öffentliche Uptime Kuma Status Page

```text
Domain: status.example.com
Scheme: http
Forward Hostname/IP: uptime-kuma
Forward Port: 3001
Websockets: enabled
SSL: Let's Encrypt
Force SSL: enabled
Access List: optional
```

Die öffentliche Status Page kann ohne Access List erreichbar sein. Die Admin-Oberfläche sollte geschützt bleiben.

---

# Sicherheitsregeln

Öffentlich erreichbar sollten nur diese Ports sein:

```text
80/tcp
443/tcp
```

Nicht frei öffentlich erreichbar:

```text
81/tcp      NPM Admin UI
9443/tcp    Portainer
19999/tcp   Netdata
3001/tcp    Uptime Kuma Admin UI
```

Empfohlen:

```text
NPM Admin UI, Portainer, Netdata und Kuma Admin nur per Access List, VPN oder IP-Whitelist erreichbar machen.
```

---

# Monitoring-Regeln

## Uptime Kuma

Uptime Kuma überwacht die echte Erreichbarkeit der Apps über die öffentlichen Domains:

```text
https://app.example.com
https://api.example.com/health
https://status.example.com
```

Primär HTTP(s)-Checks verwenden, weil damit der echte Zugriffspfad geprüft wird:

```text
Internet -> NPM -> App
```

## Netdata

Netdata überwacht Ressourcenverbrauch:

```text
CPU pro Container
RAM pro Container
Disk I/O
Netzwerktraffic
Host-Auslastung
Docker-Metriken
```

Docker-Socket bei Netdata ist sinnvoll, wenn Container-Metriken benötigt werden.

Docker-Socket bei Uptime Kuma nur verwenden, wenn Docker-Container direkt in Uptime Kuma überwacht werden sollen. Für reine Erreichbarkeitschecks ist er nicht nötig.
