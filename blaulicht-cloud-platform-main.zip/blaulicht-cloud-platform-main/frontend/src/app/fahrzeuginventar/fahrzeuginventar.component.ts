import {
  AfterViewInit,
  Component,
  DestroyRef,
  OnInit,
  ViewChild,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatAutocompleteModule, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { DateInputMaskDirective } from '../_directive/date-input-mask.directive';
import { normalizeDateInput } from '../_utils/date-normalization.util';
import { TABLE_PAGINATION_DEFAULT_PAGE_SIZE, TABLE_PAGINATION_PAGE_SIZE_OPTIONS } from '../_utils/table-pagination-options';

import {
  IFahrzeugDetail,
  IFahrzeugInventarItem,
  IFahrzeugList,
  IFahrzeugRaum,
  IFahrzeugUnterinventarItem,
} from '../_interface/fahrzeug';
import { ApiHttpService } from '../_service/api-http.service';
import { AuthSessionService } from '../_service/auth-session.service';
import { NavigationService } from '../_service/navigation.service';
import { UiMessageService } from '../_service/ui-message.service';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../imr-ui-library';

@Component({
  selector: 'app-fahrzeuginventar',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatTooltipModule,
    DateInputMaskDirective,
  ],
  templateUrl: './fahrzeuginventar.component.html',
  styleUrl: './fahrzeuginventar.component.sass',
})
export class FahrzeuginventarComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator) paginator?: MatPaginator;
  @ViewChild(MatSort) sort?: MatSort;

  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  private destroyRef = inject(DestroyRef);

  breadcrumb: ImrBreadcrumbItem[] = [];
  title = 'Fahrzeug Inventar';
  modul = 'fahrzeug-inventar';

  fahrzeuge: IFahrzeugList[] = [];
  raeumeOptionen: IFahrzeugRaum[] = [];
  private raeumeByFahrzeug = new Map<string, IFahrzeugRaum[]>();
  inventarArray: IFahrzeugInventarItem[] = [];
  einheitOptionen: string[] = ['Stk', 'L', 'Pkg'];
  raumNameOptionen: string[] = [];
  itemNameOptionen: string[] = [];
  bereichOptionen: string[] = [];
  unterinventarNameOptionen: string[] = [];
  gefilterteRaumNamen: string[] = [];
  gefilterteItemNamen: string[] = [];
  gefilterteBereiche: string[] = [];
  gefilterteUnterinventarNamen: string[] = [];

  dataSource = new MatTableDataSource<IFahrzeugInventarItem>([]);
  readonly pageSizeOptions = TABLE_PAGINATION_PAGE_SIZE_OPTIONS.standard;
  readonly pageSize = TABLE_PAGINATION_DEFAULT_PAGE_SIZE.standard;
  sichtbareSpalten: string[] = [
    'fahrzeug_name',
    'raum_name',
    'bereich',
    'name',
    'menge',
    'wartung_naechstes_am',
    'actions',
  ];

  formModul = new FormGroup({
    id: new FormControl<string>(''),
    fahrzeug_id: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    raum_id: new FormControl<string>('', { nonNullable: true }),
    raum_name: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    bereich: new FormControl<string>('', { nonNullable: true }),
    name: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    unterinventar_name: new FormControl<string>('', { nonNullable: true }),
    unterinventar_menge: new FormControl<number>(1, { nonNullable: true, validators: [Validators.required, Validators.min(1)] }),
    unterinventar_liste: new FormControl<IFahrzeugUnterinventarItem[]>([], { nonNullable: true }),
    menge: new FormControl<number>(1, { nonNullable: true }),
    einheit: new FormControl<string>('', { nonNullable: true }),
    reihenfolge: new FormControl<number>(0, { nonNullable: true }),
    wartung_zuletzt_am: new FormControl<string>(''),
    wartung_naechstes_am: new FormControl<string>(''),
  });

  ngOnInit(): void {
    sessionStorage.setItem('PageNumber', '2');
    sessionStorage.setItem('Page2', 'FZINV');
    this.breadcrumb = this.navigationService.ladeBreadcrumb();
    this.formModul.disable();
    this.observeFahrzeugSelection();

    this.dataSource.filterPredicate = (row: IFahrzeugInventarItem, filter: string) => {
      const haystack = [
        row.fahrzeug_name,
        row.raum_name,
        row.bereich,
        row.name,
        this.formatUnterinventar(row),
        this.formatMenge(row),
      ]
        .join(' ')
        .toLowerCase();
      return haystack.includes(filter);
    };

    this.loadFahrzeuge();
    this.loadInventar();
  }

  private observeFahrzeugSelection(): void {
    this.formModul.controls['fahrzeug_id'].valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((fahrzeugId) => {
        if (!fahrzeugId) {
          this.raeumeOptionen = [];
          this.formModul.controls['raum_id'].setValue('');
          this.formModul.controls['raum_name'].setValue('');
          this.refreshRaumNameOptionen();
          return;
        }
        this.loadRaeumeForFahrzeug(fahrzeugId);
      });
  }

  private loadFahrzeuge(): void {
    this.apiHttpService.get<IFahrzeugList[]>('fahrzeuge').subscribe({
      next: (res) => {
        this.fahrzeuge = res ?? [];
        this.preloadRaeumeVonAllenFahrzeugen();
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  private preloadRaeumeVonAllenFahrzeugen(): void {
    for (const fahrzeug of this.fahrzeuge) {
      this.loadRaeumeForFahrzeug(fahrzeug.id);
    }
  }

  private loadInventar(): void {
    this.apiHttpService.get<IFahrzeugInventarItem[]>(this.modul).subscribe({
      next: (res) => {
        this.inventarArray = res ?? [];
        this.dataSource.data = this.inventarArray;
        this.refreshAutocompleteOptionen();
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  ngAfterViewInit(): void {
    this.bindTableControls();
  }

  private bindTableControls(): void {
    if (this.paginator) {
      this.dataSource.paginator = this.paginator;
    }
    if (this.sort) {
      this.dataSource.sort = this.sort;
    }
  }

  applyFilter(value: string): void {
    this.dataSource.filter = (value ?? '').trim().toLowerCase();
    this.paginator?.firstPage();
  }

  formatMenge(item: IFahrzeugInventarItem): string {
    const menge = this.formatMengeWert(item.menge);
    const einheit = String(item.einheit ?? '').trim();
    return einheit ? `${menge} ${einheit}` : menge;
  }

  formatUnterinventar(item: IFahrzeugInventarItem): string {
    return this.normalizeUnterinventar(item.unterinventar)
      .map((entry) => `${this.formatMengeWert(entry.menge)}x ${entry.name}`)
      .join(', ');
  }

  get mobileEintraege(): IFahrzeugInventarItem[] {
    return this.dataSource.filteredData;
  }

  private formatMengeWert(value: number): string {
    const normalized = Number(value);
    if (!Number.isFinite(normalized)) {
      return '0';
    }
    if (Number.isInteger(normalized)) {
      return String(normalized);
    }
    return String(normalized);
  }

  neueDetails(): void {
    this.formModul.enable();
    this.raeumeOptionen = [];
    this.formModul.reset({
      id: '',
      fahrzeug_id: '',
      raum_id: '',
      raum_name: '',
      bereich: '',
      name: '',
      unterinventar_name: '',
      unterinventar_menge: 1,
      unterinventar_liste: [],
      menge: 1,
      einheit: '',
      reihenfolge: 0,
      wartung_zuletzt_am: '',
      wartung_naechstes_am: '',
    });
  }

  auswahlBearbeiten(element: IFahrzeugInventarItem): void {
    this.formModul.enable();
    this.formModul.setValue({
      id: element.id,
      fahrzeug_id: element.fahrzeug_id,
      raum_id: element.raum_id,
      raum_name: element.raum_name,
      bereich: element.bereich ?? '',
      name: element.name,
      unterinventar_name: '',
      unterinventar_menge: 1,
      unterinventar_liste: this.normalizeUnterinventar(element.unterinventar),
      menge: Number(element.menge ?? 0),
      einheit: element.einheit ?? '',
      reihenfolge: element.reihenfolge ?? 0,
      wartung_zuletzt_am: element.wartung_zuletzt_am ? String(element.wartung_zuletzt_am).slice(0, 10) : '',
      wartung_naechstes_am: element.wartung_naechstes_am ? String(element.wartung_naechstes_am).slice(0, 10) : '',
    });
    this.loadRaeumeForFahrzeug(element.fahrzeug_id, element.raum_id);
  }

  abbrechen(): void {
    this.formModul.disable();
    this.formModul.reset({
      id: '',
      fahrzeug_id: '',
      raum_id: '',
      raum_name: '',
      bereich: '',
      name: '',
      unterinventar_name: '',
      unterinventar_menge: 1,
      unterinventar_liste: [],
      menge: 1,
      einheit: '',
      reihenfolge: 0,
      wartung_zuletzt_am: '',
      wartung_naechstes_am: '',
    });
    this.raeumeOptionen = [];
  }

  private normalizeDateInput(value: string | null | undefined): string | null {
    const normalized = normalizeDateInput(value);
    return normalized || null;
  }

  private isWartungWindowInvalid(zuletzt: string | null, naechstes: string | null): boolean {
    if (!zuletzt || !naechstes) {
      return false;
    }

    const zuletztTime = Date.parse(zuletzt);
    const naechstesTime = Date.parse(naechstes);
    if (Number.isNaN(zuletztTime) || Number.isNaN(naechstesTime)) {
      return false;
    }

    return naechstesTime < zuletztTime;
  }

  private loadRaeumeForFahrzeug(fahrzeugId: string, preferredRaumId?: string): void {
    const existing = this.raeumeByFahrzeug.get(fahrzeugId);
    if (existing) {
      this.raeumeOptionen = existing;
      this.ensureValidRaumSelection(preferredRaumId);
      this.refreshRaumNameOptionen();
      return;
    }

    this.apiHttpService.get<IFahrzeugDetail>(`fahrzeuge/${fahrzeugId}`).subscribe({
      next: (res) => {
        const raeume = res?.raeume ?? [];
        this.raeumeByFahrzeug.set(fahrzeugId, raeume);
        if (this.formModul.controls['fahrzeug_id'].value === fahrzeugId) {
          this.raeumeOptionen = raeume;
          this.ensureValidRaumSelection(preferredRaumId);
          this.refreshRaumNameOptionen();
        }
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  private ensureValidRaumSelection(preferredRaumId?: string): void {
    const current = this.formModul.controls['raum_id'].value;
    const allowed = new Set(this.raeumeOptionen.map((raum) => raum.id));
    if (preferredRaumId && allowed.has(preferredRaumId)) {
      this.formModul.controls['raum_id'].setValue(preferredRaumId);
      const selected = this.raeumeOptionen.find((raum) => raum.id === preferredRaumId);
      if (selected) {
        this.formModul.controls['raum_name'].setValue(selected.name);
      }
      return;
    }
    if (current && allowed.has(current)) {
      const selected = this.raeumeOptionen.find((raum) => raum.id === current);
      if (selected) {
        this.formModul.controls['raum_name'].setValue(selected.name);
      }
      return;
    }
    this.formModul.controls['raum_id'].setValue('');
  }

  onRaumNameInput(value: string): void {
    this.filterRaumNamen(value);
    const match = this.raeumeOptionen.find((raum) => raum.name.toLowerCase() === String(value ?? '').trim().toLowerCase());
    this.formModul.controls['raum_id'].setValue(match?.id ?? '');
  }

  onRaumNameSelected(event: MatAutocompleteSelectedEvent): void {
    const selectedName = String(event.option.value ?? '').trim();
    this.formModul.controls['raum_name'].setValue(selectedName);
    const match = this.raeumeOptionen.find((raum) => raum.name.toLowerCase() === selectedName.toLowerCase());
    this.formModul.controls['raum_id'].setValue(match?.id ?? '');
  }

  onItemNameInput(value: string): void {
    this.filterItemNamen(value);
  }

  onBereichInput(value: string): void {
    this.filterBereiche(value);
  }

  onUnterinventarNameInput(value: string): void {
    this.filterUnterinventarNamen(value);
  }

  private refreshAutocompleteOptionen(): void {
    const itemNamen = new Set<string>();
    const bereiche = new Set<string>();
    const unterinventarNamen = new Set<string>();
    for (const item of this.inventarArray) {
      const itemName = String(item.name ?? '').trim();
      const bereich = String(item.bereich ?? '').trim();
      const unterinventarListe = this.normalizeUnterinventar(item.unterinventar);
      if (itemName) {
        itemNamen.add(itemName);
      }
      if (bereich) {
        bereiche.add(bereich);
      }
      for (const unterinventar of unterinventarListe) {
        const unterinventarName = String(unterinventar.name ?? '').trim();
        if (unterinventarName) {
          unterinventarNamen.add(unterinventarName);
        }
      }
    }
    this.itemNameOptionen = Array.from(itemNamen).sort((a, b) => a.localeCompare(b, 'de'));
    this.bereichOptionen = Array.from(bereiche).sort((a, b) => a.localeCompare(b, 'de'));
    this.unterinventarNameOptionen = Array.from(unterinventarNamen).sort((a, b) => a.localeCompare(b, 'de'));
    this.filterItemNamen(this.formModul.controls['name'].value);
    this.filterBereiche(this.formModul.controls['bereich'].value);
    this.filterUnterinventarNamen(this.formModul.controls['unterinventar_name'].value);
    this.refreshRaumNameOptionen();
  }

  private refreshRaumNameOptionen(): void {
    const raumNamen = new Set<string>();
    for (const raum of this.raeumeOptionen) {
      const name = String(raum.name ?? '').trim();
      if (name) {
        raumNamen.add(name);
      }
    }
    for (const raeume of this.raeumeByFahrzeug.values()) {
      for (const raum of raeume) {
        const name = String(raum.name ?? '').trim();
        if (name) {
          raumNamen.add(name);
        }
      }
    }
    this.raumNameOptionen = Array.from(raumNamen).sort((a, b) => a.localeCompare(b, 'de'));
    this.filterRaumNamen(this.formModul.controls['raum_name'].value);
  }

  private filterRaumNamen(value: string): void {
    const search = String(value ?? '').trim().toLowerCase();
    this.gefilterteRaumNamen = this.raumNameOptionen.filter((name) => name.toLowerCase().includes(search));
  }

  private filterItemNamen(value: string): void {
    const search = String(value ?? '').trim().toLowerCase();
    this.gefilterteItemNamen = this.itemNameOptionen.filter((name) => name.toLowerCase().includes(search));
  }

  private filterBereiche(value: string): void {
    const search = String(value ?? '').trim().toLowerCase();
    this.gefilterteBereiche = this.bereichOptionen.filter((name) => name.toLowerCase().includes(search));
  }

  private filterUnterinventarNamen(value: string): void {
    const search = String(value ?? '').trim().toLowerCase();
    this.gefilterteUnterinventarNamen = this.unterinventarNameOptionen.filter((name) => name.toLowerCase().includes(search));
  }

  private normalizeUnterinventar(value: unknown): IFahrzeugUnterinventarItem[] {
    if (!Array.isArray(value)) {
      return [];
    }
    return value
      .map((entry) => {
        if (entry && typeof entry === 'object' && !Array.isArray(entry)) {
          const name = String((entry as { name?: unknown }).name ?? '').trim();
          const mengeRaw = Number((entry as { menge?: unknown }).menge ?? 1);
          const menge = Number.isFinite(mengeRaw) && mengeRaw > 0 ? mengeRaw : 1;
          if (!name) {
            return null;
          }
          return { name, menge };
        }
        const fallbackName = String(entry ?? '').trim();
        if (!fallbackName) {
          return null;
        }
        return { name: fallbackName, menge: 1 };
      })
      .filter((entry): entry is IFahrzeugUnterinventarItem => entry !== null);
  }

  addUnterinventarPosition(): void {
    const name = String(this.formModul.controls['unterinventar_name'].value ?? '').trim();
    const mengeRaw = Number(this.formModul.controls['unterinventar_menge'].value ?? 1);
    const menge = Number.isFinite(mengeRaw) && mengeRaw > 0 ? mengeRaw : 1;

    if (!name) {
      this.uiMessageService.erstelleMessage('error', 'Bitte eine Unterinventar-Bezeichnung eingeben.');
      return;
    }

    const current = this.normalizeUnterinventar(this.formModul.controls['unterinventar_liste'].value);
    this.formModul.controls['unterinventar_liste'].setValue([...current, { name, menge }]);
    this.formModul.controls['unterinventar_name'].setValue('');
    this.formModul.controls['unterinventar_menge'].setValue(1);
    this.filterUnterinventarNamen('');
  }

  removeUnterinventarPosition(index: number): void {
    const current = this.normalizeUnterinventar(this.formModul.controls['unterinventar_liste'].value);
    this.formModul.controls['unterinventar_liste'].setValue(current.filter((_, idx) => idx !== index));
  }

  get unterinventarListeImForm(): IFahrzeugUnterinventarItem[] {
    return this.normalizeUnterinventar(this.formModul.controls['unterinventar_liste'].value);
  }

  datenSpeichern(): void {
    this.formModul.markAllAsTouched();
    if (this.formModul.invalid) {
      this.uiMessageService.erstelleMessage('error', 'Bitte Fahrzeug, Raumname und Bezeichnung ausfüllen.');
      return;
    }

    const wartungZuletztAm = this.normalizeDateInput(this.formModul.controls['wartung_zuletzt_am'].value);
    const wartungNaechstesAm = this.normalizeDateInput(this.formModul.controls['wartung_naechstes_am'].value);

    if (this.isWartungWindowInvalid(wartungZuletztAm, wartungNaechstesAm)) {
      this.uiMessageService.erstelleMessage(
        'error',
        'Wartung: Das nächste Datum darf nicht vor dem zuletzt erledigten Datum liegen.'
      );
      return;
    }

    const payload = {
      fahrzeug_id: this.formModul.controls['fahrzeug_id'].value!,
      raum_id: this.formModul.controls['raum_id'].value || null,
      raum_name: this.formModul.controls['raum_name'].value!,
      name: this.formModul.controls['name'].value!,
      bereich: this.formModul.controls['bereich'].value ?? '',
      unterinventar: this.normalizeUnterinventar(this.formModul.controls['unterinventar_liste'].value),
      menge: Number(this.formModul.controls['menge'].value ?? 0),
      einheit: this.formModul.controls['einheit'].value ?? '',
      reihenfolge: Number(this.formModul.controls['reihenfolge'].value ?? 0),
      wartung_zuletzt_am: wartungZuletztAm,
      wartung_naechstes_am: wartungNaechstesAm,
    };
    const id = this.formModul.controls['id'].value || '';

    if (!id) {
      this.apiHttpService.post<IFahrzeugInventarItem>(this.modul, payload, false).subscribe({
        next: (created) => {
          this.inventarArray = [...this.inventarArray, created];
          this.dataSource.data = this.inventarArray;
          this.refreshAutocompleteOptionen();
          this.bindTableControls();
          this.abbrechen();
          this.uiMessageService.erstelleMessage('success', 'Fahrzeuginventar erfolgreich gespeichert.');
        },
        error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
      });
      return;
    }

    this.apiHttpService.patch<IFahrzeugInventarItem>(this.modul, id, payload, false).subscribe({
      next: (updated) => {
        this.inventarArray = this.inventarArray.map((entry) => (entry.id === updated.id ? updated : entry));
        this.dataSource.data = this.inventarArray;
        this.refreshAutocompleteOptionen();
        this.bindTableControls();
        this.abbrechen();
        this.uiMessageService.erstelleMessage('success', 'Fahrzeuginventar erfolgreich geändert.');
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  datenLoeschen(): void {
    const id = this.formModul.controls['id'].value || '';
    if (!id) {
      return;
    }

    this.apiHttpService.delete(this.modul, id).subscribe({
      next: () => {
        this.inventarArray = this.inventarArray.filter((entry) => entry.id !== id);
        this.dataSource.data = this.inventarArray;
        this.refreshAutocompleteOptionen();
        this.bindTableControls();
        this.abbrechen();
        this.uiMessageService.erstelleMessage('success', 'Eintrag erfolgreich gelöscht.');
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }
}
