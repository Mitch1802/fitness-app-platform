export interface IFotoEvent {
  id: string;
  name: string;
  beschreibung: string;
  datum: string | null;
  sichtbar: boolean;
  upload_count: number;
  foto_total_count: number;
  created_at: string;
  updated_at: string;
}

export interface IFotoEventPublic {
  id: string;
  name: string;
  beschreibung: string;
  datum: string | null;
}

export interface IFotoUpload {
  id: string;
  event: string;
  event_name: string;
  uploader_name: string;
  foto_anzahl: number;
  zip_url: string | null;
  created_at: string;
}
