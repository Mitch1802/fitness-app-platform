import { CheckStatus } from "../fahrzeug-check/fahrzeug-check.constants";

export interface IFahrzeugPublic {
  name: string;
  bezeichnung: string;
  reihenfolge: number;
  beschreibung: string;
  public_id: string;
  service_zuletzt_am?: string | null;
  service_naechstes_am?: string | null;
  pickerl_zuletzt_am?: string | null;
  pickerl_naechstes_am?: string | null;
  foto_url?: string | null;
  raeume: Array<{
    name: string;
    reihenfolge: number;
    foto_url?: string | null;
    items: Array<{
      name: string;
      bereich: string;
      menge: number;
      einheit: string;
      notiz: string;
      unterinventar: IFahrzeugUnterinventarItem[];
      reihenfolge: number;
      wartung_zuletzt_am?: string | null;
      wartung_naechstes_am?: string | null;
    }>;
  }>;
}

export interface IFahrzeugPublicList {
  name: string;
  bezeichnung: string;
  reihenfolge: number;
  public_id: string;
  foto_url?: string | null;
}

export interface IFahrzeugAuth extends IFahrzeugPublic {
  id: string;
  raeume: Array<{
    id: string;
    name: string;
    reihenfolge: number;
    items: Array<{
      id: string;
      name: string;
      bereich: string;
      menge: number;
      einheit: string;
      notiz: string;
      unterinventar: IFahrzeugUnterinventarItem[];
      reihenfolge: number;
    }>;
  }>;
}

export interface ICheckDraftItem {
  status: CheckStatus;
  menge_aktuel?: number | null;
  notiz?: string;
}

export interface IFahrzeugList {
  id: string;
  name: string;
  bezeichnung: string;
  reihenfolge: number;
  public_id: string;
  service_zuletzt_am?: string | null;
  service_naechstes_am?: string | null;
  pickerl_zuletzt_am?: string | null;
  pickerl_naechstes_am?: string | null;
  foto_url?: string | null;
}

export interface IRaumItem {
  id: string;
  name: string;
  bereich: string;
  menge: number;
  einheit: string;
  notiz: string;
  unterinventar: IFahrzeugUnterinventarItem[];
  reihenfolge: number;
  wartung_zuletzt_am?: string | null;
  wartung_naechstes_am?: string | null;
}

export interface IFahrzeugRaum {
  id: string;
  name: string;
  reihenfolge: number;
  foto_url?: string | null;
  items: IRaumItem[];
  // UI-State für Editor
  editItemId?: string | null;
  showNewItem?: boolean;
  selectedItemId?: string | null;
}

export interface IFahrzeugDetail {
  id: string;
  name: string;
  bezeichnung: string;
  reihenfolge: number;
  beschreibung: string;
  public_id: string;
  service_zuletzt_am?: string | null;
  service_naechstes_am?: string | null;
  pickerl_zuletzt_am?: string | null;
  pickerl_naechstes_am?: string | null;
  foto_url?: string | null;
  raeume: IFahrzeugRaum[];
}

export interface IFahrzeugInventarItem {
  id: string;
  fahrzeug_id: string;
  fahrzeug_name: string;
  raum_id: string;
  raum_name: string;
  name: string;
  bereich: string;
  menge: number;
  einheit: string;
  notiz: string;
  unterinventar: IFahrzeugUnterinventarItem[];
  reihenfolge: number;
  wartung_zuletzt_am?: string | null;
  wartung_naechstes_am?: string | null;
}

export interface IFahrzeugUnterinventarItem {
  name: string;
  menge: number;
}

export interface IFahrzeugCheckProblemItem {
  id: string;
  item_name: string;
  raum_name: string;
  status: CheckStatus;
  menge_soll: number | null;
  menge_aktuel: number | null;
  einheit: string;
  notiz: string;
}

export interface IFahrzeugCheckHistoryEntry {
  id: string;
  fahrzeug_name: string;
  title: string;
  notiz: string;
  created_at: string;
  problem_count: number;
  problem_items: IFahrzeugCheckProblemItem[];
}
