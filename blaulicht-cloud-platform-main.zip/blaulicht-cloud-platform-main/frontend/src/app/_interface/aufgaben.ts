export type AufgabenStatus = 'OFFEN' | 'IN_BEARBEITUNG' | 'GESCHLOSSEN';

export interface IAufgabenTicket {
  id: string;
  titel: string;
  melder: string | null;
  melder_username: string;
  zustaendiger_user: string | null;
  zustaendiger_username: string;
  beschreibung: string;
  zu_erledigen_bis: string | null;
  status: AufgabenStatus;
  geschlossen_datum: string | null;
  email_versendet_datum: string | null;
  quelle_modul: string;
  created_at: string;
  updated_at: string;
}

export interface IAufgabenUserOption {
  id: string;
  username: string;
}

export interface IAufgabenContextResponse {
  users: IAufgabenUserOption[];
  current_user?: {
    id: string;
    username: string;
  };
  can_see_all?: boolean;
}

export interface IAufgabenSummary {
  offen: number;
  in_bearbeitung: number;
  gesamt_offen: number;
}
