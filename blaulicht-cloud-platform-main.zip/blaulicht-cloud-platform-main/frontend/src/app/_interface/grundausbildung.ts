export interface IGrundausbildung {
  id: string;
  pkid: number;
  mitglied_id: string;
  mitglied_pkid: number;
  stbnr: number;
  vorname: string;
  nachname: string;
  dienstgrad?: string;
  dienststatus?: 'JUGEND' | 'AKTIV' | 'RESERVE' | 'ABGEMELDET';
  station_basisausbildung: boolean;
  station_atemschutz: boolean;
  station_grundlagen_fuehren: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface IGrundausbildungContext {
  mitglieder: Array<{
    id: string;
    pkid: number;
    stbnr: number;
    vorname: string;
    nachname: string;
    dienstgrad?: string;
    dienststatus?: 'JUGEND' | 'AKTIV' | 'RESERVE' | 'ABGEMELDET';
  }>;
}
