export type VerwaltungDokumentTyp = 'rechnung' | 'transparent' | 'fest';

export interface IVerwaltungDokument {
  id: string;
  typ: VerwaltungDokumentTyp;
  title: string;
  payload: Record<string, unknown>;
  is_template: boolean;
  source_template: string | null;
  created_by: string | null;
  created_by_username: string;
  created_at: string;
  updated_at: string;
}
