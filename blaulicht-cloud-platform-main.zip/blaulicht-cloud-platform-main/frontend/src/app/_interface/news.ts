﻿export interface INews {
  id: string;
  title: string;
  text: string;
  typ: string;
  infoscreen_anzeige_ab?: string | null;
  infoscreen_anzeige_bis?: string | null;
  foto_url?: string | null;
  created_at: string;
  updated_at: string;
}
