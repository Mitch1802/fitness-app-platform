export interface IAusbildungDatei {
  id?: string;
  dateiname: string;
  datei_url?: string;
  created_at?: string;
}

export interface IAusbildungThemenbereich {
  id?: string;
  pkid?: number;
  titel: string;
  beschreibung?: string;
  dateien?: IAusbildungDatei[];
  datei_anzahl?: number;
  created_at?: string;
  updated_at?: string;
}
