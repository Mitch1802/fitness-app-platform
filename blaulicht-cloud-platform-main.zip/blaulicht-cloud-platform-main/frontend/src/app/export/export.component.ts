import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { forkJoin } from 'rxjs';

import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';

import { IPdfTemplate } from '../_interface/pdf_template';
import { IStammdaten } from '../_interface/stammdaten';
import { formatDateOutput } from '../_utils/date-normalization.util';
import { ApiHttpService } from '../_service/api-http.service';
import { AuthSessionService } from '../_service/auth-session.service';
import { NavigationService } from '../_service/navigation.service';
import { UiMessageService } from '../_service/ui-message.service';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../imr-ui-library';

type ModulKonfigurationEintrag = {
  id?: string | number;
  modul?: string;
  konfiguration?: Record<string, unknown>;
  updated_at?: string;
};

type ModulKonfigurationResponse = {
  user?: { roles?: string[] | string };
  main?: ModulKonfigurationEintrag[];
} | ModulKonfigurationEintrag[];

type ExportContextResponse = {
  modul_konfig?: ModulKonfigurationEintrag[];
  konfig?: IStammdaten[];
};

type PdfTemplatesResponse = { main?: IPdfTemplate[] } | IPdfTemplate[];

type ModulKonfigurationSaveResult = {
  id: string | number;
  modul: string;
  konfiguration?: Record<string, unknown>;
};

type StandeslisteEintrag = {
  stbnr: number;
  dienstgrad: string;
  name: string;
};

type EinsatzstatistikEintrag = {
  stbnr: number;
  name: string;
  einsaetze: number;
};

type EinsatzauflistungEintrag = {
  id: string;
  einsatz_datum: string;
  alarmstichwort: string;
  einsatzart: string;
  einsatzadresse: string;
  einsatzleiter: string;
  alarmierende_stelle: string;
  status: string;
  mitglieder_anzahl: number;
  fahrzeuge_anzahl: number;
  alarmiert_zeit: string;
  dauer_stunden: number;
};

type ExportTyp = 'standesliste' | 'einsatzstatistik' | 'einsatzauflistung';

@Component({
  selector: 'app-export',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatSelectModule,
    MatOptionModule,
    MatTableModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
  ],
  templateUrl: './export.component.html',
  styleUrl: './export.component.sass',
})
export class ExportComponent implements OnInit, OnDestroy {
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  private sanitizer = inject(DomSanitizer);

  private readonly modul = 'export';
  private readonly modulKonfigurationEndpoint = 'modul_konfiguration';
  private readonly adminRoleKey = 'ADMIN';
  private readonly pdfViewerFragment = 'toolbar=0&navpanes=0&scrollbar=0&view=FitH&zoom=page-width';

  breadcrumb: ImrBreadcrumbItem[] = [];
  meine_rollen: string[] = [];
  stammdaten: IStammdaten | null = null;

  pdfKonfigId: string | null = null;
  pdf_konfig: Record<string, unknown> = {};
  pdfTemplates: IPdfTemplate[] = [];
  private pdfTemplatesLoaded = false;

  previewPdfUrl: SafeResourceUrl | null = null;
  private previewPdfObjectUrl: string | null = null;
  previewLoaded = false;
  previewTyp: ExportTyp = 'standesliste';
  settingsPanelOpen = false;

  standesliste: StandeslisteEintrag[] = [];
  einsatzstatistik: EinsatzstatistikEintrag[] = [];
  einsatzauflistung: EinsatzauflistungEintrag[] = [];

  readonly jahre: string[] = this.buildJahreAuswahl();

  formExport = new FormGroup({
    typ: new FormControl<ExportTyp>('standesliste', {
      nonNullable: true,
      validators: [Validators.required],
    }),
    jahr: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required],
    }),
  });

  formSettings = new FormGroup({
    idExportStandesliste: new FormControl<string | null>(null),
    idExportEinsatzstatistik: new FormControl<string | null>(null),
    idExportEinsatzauflistung: new FormControl<string | null>(null),
  });

  get isAdmin(): boolean {
    return this.meine_rollen.includes(this.adminRoleKey);
  }

  ngOnInit(): void {
    sessionStorage.setItem('PageNumber', '2');
    sessionStorage.setItem('Page2', 'Export');
    this.breadcrumb = this.navigationService.ladeBreadcrumb();

    const aktuellesJahr = String(new Date().getFullYear());
    this.formExport.controls.jahr.setValue(aktuellesJahr);

    forkJoin({
      context: this.apiHttpService.get<ExportContextResponse>(`${this.modul}/context`),
      modulKonfig: this.apiHttpService.get<ModulKonfigurationResponse>(this.modulKonfigurationEndpoint),
    }).subscribe({
      next: ({ context, modulKonfig }) => {
        const contextModulKonfig = Array.isArray(context?.modul_konfig) ? context.modul_konfig : [];
        const pdfEntry = contextModulKonfig.find((item) => String(item.modul ?? '').trim().toLowerCase() === 'pdf');
        this.pdf_konfig = (pdfEntry?.konfiguration ?? {}) as Record<string, unknown>;
        this.pdfKonfigId = this.stringOrNull(pdfEntry?.id);
        this.stammdaten = Array.isArray(context?.konfig) ? (context.konfig[0] ?? null) : null;

        this.meine_rollen = this.extractRolesFromPayload(modulKonfig);
        this.syncSettingsForm();

        if (this.isAdmin) {
          this.loadPdfTemplatesOnce();
        }
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  ngOnDestroy(): void {
    this.cleanupPreviewObjectUrl();
  }

  refreshPreview(): void {
    if (this.formExport.invalid) {
      this.formExport.markAllAsTouched();
      return;
    }

    const typ = this.formExport.controls.typ.value;
    const jahr = String(this.formExport.controls.jahr.value || '').trim();

    if (!/^\d{4}$/.test(jahr)) {
      this.uiMessageService.erstelleMessage('error', 'Bitte ein gueltiges Jahr (YYYY) auswaehlen.');
      return;
    }

    this.previewTyp = typ;

    switch (typ) {
      case 'standesliste':
        this.apiHttpService.get<StandeslisteEintrag[]>(`${this.modul}/exporte/standesliste`).subscribe({
          next: (rows) => {
            this.standesliste = Array.isArray(rows) ? rows : [];
            this.renderPreviewWithPayload(typ, jahr);
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
        });
        break;
      case 'einsatzstatistik':
        this.apiHttpService.get<EinsatzstatistikEintrag[]>(`${this.modul}/exporte/einsatzstatistik`, { jahr }).subscribe({
          next: (rows) => {
            this.einsatzstatistik = (Array.isArray(rows) ? rows : [])
              .slice()
              .sort((a, b) => {
                const diff = Number(b.einsaetze || 0) - Number(a.einsaetze || 0);
                if (diff !== 0) {
                  return diff;
                }
                return Number(a.stbnr || 0) - Number(b.stbnr || 0);
              });
            this.renderPreviewWithPayload(typ, jahr);
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
        });
        break;
      case 'einsatzauflistung':
        this.apiHttpService.get<EinsatzauflistungEintrag[]>(`${this.modul}/exporte/einsatzauflistung`, { jahr }).subscribe({
          next: (rows) => {
            this.einsatzauflistung = Array.isArray(rows) ? rows : [];
            this.renderPreviewWithPayload(typ, jahr);
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
        });
        break;
    }
  }

  printExport(): void {
    if (this.formExport.invalid) {
      this.formExport.markAllAsTouched();
      return;
    }

    const typ = this.formExport.controls.typ.value;
    const jahr = String(this.formExport.controls.jahr.value || '').trim();
    const templateId = this.getTemplateIdForTyp(typ);

    if (!templateId) {
      this.uiMessageService.erstelleMessage('error', 'Kein PDF-Template konfiguriert. Bitte Einstellungen pflegen.');
      return;
    }

    const payload = this.buildRenderPayload(typ, jahr);
    const endpoint = `pdf/templates/${templateId}/render`;

    this.apiHttpService.postBlob(endpoint, payload).subscribe({
      next: (blob: Blob) => {
        if (!blob || blob.size === 0) {
          this.uiMessageService.erstelleMessage('error', 'PDF ist leer (0 Bytes).');
          return;
        }

        const rawUrl = URL.createObjectURL(blob);
        const viewerUrl = this.withPdfViewerDefaults(rawUrl);
        window.open(viewerUrl, '_blank');
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  saveSettings(): void {
    if (!this.isAdmin) {
      return;
    }

    const payload: Record<string, unknown> = {
      ...this.pdf_konfig,
      idExportStandesliste: this.stringOrNull(this.formSettings.controls.idExportStandesliste.value),
      idExportEinsatzstatistik: this.stringOrNull(this.formSettings.controls.idExportEinsatzstatistik.value),
      idExportEinsatzauflistung: this.stringOrNull(this.formSettings.controls.idExportEinsatzauflistung.value),
    };

    const req$ = this.pdfKonfigId
      ? this.apiHttpService.patch<ModulKonfigurationSaveResult>(this.modulKonfigurationEndpoint, this.pdfKonfigId, {
        modul: 'pdf',
        konfiguration: payload,
      })
      : this.apiHttpService.post<ModulKonfigurationSaveResult>(this.modulKonfigurationEndpoint, {
        modul: 'pdf',
        konfiguration: payload,
      });

    req$.subscribe({
      next: (saved) => {
        this.pdfKonfigId = this.stringOrNull(saved?.id);
        this.pdf_konfig = (saved?.konfiguration ?? payload) as Record<string, unknown>;
        this.syncSettingsForm();
        this.uiMessageService.erstelleMessage('ok', 'Einstellungen gespeichert.');
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  resetSettings(): void {
    this.syncSettingsForm();
  }

  openSettings(): void {
    this.settingsPanelOpen = true;
  }

  closeSettings(): void {
    this.settingsPanelOpen = false;
  }

  toggleSettings(): void {
    if (this.settingsPanelOpen) {
      this.closeSettings();
    } else {
      this.openSettings();
    }
  }

  formatDatum(value: string): string {
    return formatDateOutput(value);
  }

  private renderPreviewWithPayload(typ: ExportTyp, jahr: string): void {
    const templateId = this.getTemplateIdForTyp(typ);
    if (!templateId) {
      this.cleanupPreviewObjectUrl();
      this.previewPdfUrl = null;
      this.previewLoaded = false;
      this.uiMessageService.erstelleMessage('error', 'Kein PDF-Template fuer diesen Export konfiguriert.');
      return;
    }

    const payload = this.buildRenderPayload(typ, jahr);
    const endpoint = `pdf/templates/${templateId}/render`;

    this.apiHttpService.postBlob(endpoint, payload).subscribe({
      next: (blob: Blob) => {
        if (!blob || blob.size === 0) {
          this.cleanupPreviewObjectUrl();
          this.previewPdfUrl = null;
          this.previewLoaded = false;
          this.uiMessageService.erstelleMessage('error', 'PDF Vorschau ist leer (0 Bytes).');
          return;
        }

        this.cleanupPreviewObjectUrl();
        this.previewPdfObjectUrl = URL.createObjectURL(blob);
        this.previewPdfUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
          this.withPdfViewerDefaults(this.previewPdfObjectUrl),
        );
        this.previewLoaded = true;
      },
      error: (error: unknown) => {
        this.cleanupPreviewObjectUrl();
        this.previewPdfUrl = null;
        this.previewLoaded = false;
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  private cleanupPreviewObjectUrl(): void {
    if (this.previewPdfObjectUrl) {
      URL.revokeObjectURL(this.previewPdfObjectUrl);
      this.previewPdfObjectUrl = null;
    }
  }

  private withPdfViewerDefaults(url: string): string {
    return `${url}#${this.pdfViewerFragment}`;
  }

  private buildRenderPayload(typ: ExportTyp, jahr: string): Record<string, unknown> {
    const common = {
      fw_name: this.stammdaten?.fw_name,
      fw_street: this.stammdaten?.fw_street,
      fw_plz: this.stammdaten?.fw_plz,
      fw_ort: this.stammdaten?.fw_ort,
      fw_email: this.stammdaten?.fw_email,
      fw_telefon: this.stammdaten?.fw_telefon,
      fw_konto: this.stammdaten?.fw_konto,
      fw_iban: this.stammdaten?.fw_iban,
      fw_bic: this.stammdaten?.fw_bic,
      fw_kdt: this.stammdaten?.fw_kdt,
      export_datum: formatDateOutput(new Date()),
      statistik_jahr: jahr,
      export_jahr: jahr,
    };

    if (typ === 'standesliste') {
      return {
        ...common,
        standesliste: this.standesliste.map((item) => ({
          stbnr: item.stbnr,
          dienstgrad: item.dienstgrad,
          name: item.name,
        })),
      };
    }

    if (typ === 'einsatzstatistik') {
      return {
        ...common,
        einsatzstatistik: this.einsatzstatistik.map((item) => ({
          stbnr: item.stbnr,
          name: item.name,
          einsaetze: Number(item.einsaetze || 0),
        })),
      };
    }

    return {
      ...common,
      einsatzauflistung: this.einsatzauflistung.map((item) => ({
        id: item.id,
        einsatz_datum: this.formatDatum(item.einsatz_datum),
        alarmstichwort: item.alarmstichwort,
        einsatzart: item.einsatzart,
        einsatzadresse: item.einsatzadresse,
        einsatzleiter: item.einsatzleiter,
        alarmierende_stelle: item.alarmierende_stelle,
        status: item.status,
        mitglieder_anzahl: Number(item.mitglieder_anzahl || 0),
        fahrzeuge_anzahl: Number(item.fahrzeuge_anzahl || 0),
        alarmiert_zeit: item.alarmiert_zeit,
        dauer_stunden: Number(item.dauer_stunden || 0),
      })),
    };
  }

  private getTemplateIdForTyp(typ: ExportTyp): string {
    const keyMap: Record<ExportTyp, string> = {
      standesliste: 'idExportStandesliste',
      einsatzstatistik: 'idExportEinsatzstatistik',
      einsatzauflistung: 'idExportEinsatzauflistung',
    };

    return String(this.pdf_konfig[keyMap[typ]] ?? '').trim();
  }

  private buildJahreAuswahl(range = 15): string[] {
    const current = new Date().getFullYear();
    return Array.from({ length: range + 1 }, (_, index) => String(current - index));
  }

  private loadPdfTemplatesOnce(): void {
    if (this.pdfTemplatesLoaded) {
      return;
    }

    this.apiHttpService.get<PdfTemplatesResponse>('pdf/templates').subscribe({
      next: (erg) => {
        this.pdfTemplates = Array.isArray(erg) ? erg : (erg.main ?? []);
        this.pdfTemplatesLoaded = true;
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  private syncSettingsForm(): void {
    this.formSettings.patchValue({
      idExportStandesliste: this.stringOrNull(this.pdf_konfig.idExportStandesliste),
      idExportEinsatzstatistik: this.stringOrNull(this.pdf_konfig.idExportEinsatzstatistik),
      idExportEinsatzauflistung: this.stringOrNull(this.pdf_konfig.idExportEinsatzauflistung),
    }, { emitEvent: false });

    this.formSettings.markAsPristine();
    this.formSettings.markAsUntouched();
  }

  private extractRolesFromPayload(payload: unknown): string[] {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return [];
    }

    return this.normalizeRoles((payload as { user?: { roles?: unknown } }).user?.roles);
  }

  private normalizeRoles(value: unknown): string[] {
    if (Array.isArray(value)) {
      return value.map((item) => String(item).trim().toUpperCase()).filter(Boolean);
    }

    return String(value ?? '')
      .split(',')
      .map((item) => item.trim().toUpperCase())
      .filter(Boolean);
  }

  private stringOrNull(value: unknown): string | null {
    if (value === null || value === undefined || value === '') {
      return null;
    }

    return String(value);
  }
}
