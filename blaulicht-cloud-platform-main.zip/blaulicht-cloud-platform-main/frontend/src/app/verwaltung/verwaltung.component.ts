﻿import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ApiHttpService } from 'src/app/_service/api-http.service';
import { AuthSessionService } from 'src/app/_service/auth-session.service';
import { CollectionUtilsService } from 'src/app/_service/collection-utils.service';
import { NavigationService } from 'src/app/_service/navigation.service';
import { UiMessageService } from 'src/app/_service/ui-message.service';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../imr-ui-library';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTabsModule } from '@angular/material/tabs';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { IStammdaten } from '../_interface/stammdaten';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';
import { IPdfTemplate } from '../_interface/pdf_template';
import { MatTableModule } from '@angular/material/table';
import { MatExpansionModule } from '@angular/material/expansion';
import { IVerwaltungDokument, VerwaltungDokumentTyp } from '../_interface/verwaltung_dokument';
import { DateInputMaskDirective } from '../_directive/date-input-mask.directive';
import { formatDateOutput, normalizeDateInput } from '../_utils/date-normalization.util';

type RechnungPosition = {
  bezeichnung: string;
  preis: number;
};

type SevdeskKontakt = {
  id: string | number;
  name: string;
};

type ModulKonfigurationEintrag = {
  id?: string | number;
  modul?: string;
  konfiguration?: Record<string, unknown>;
  updated_at?: string;
};

type ModulKonfigurationResponse = {
  user?: { roles?: string[] | string };
  main?: ModulKonfigurationEintrag[];
} | ModulKonfigurationEintrag[];

type ModulKonfigurationSaveResult = {
  id: string | number;
  modul: string;
  konfiguration?: Record<string, unknown>;
};

type PdfTemplatesResponse = { main?: IPdfTemplate[] } | IPdfTemplate[];

type VerwaltungResponse = {
  sevdesk?: { objects?: SevdeskKontakt[] };
  modul_konfig?: ModulKonfigurationEintrag[];
  konfig?: IStammdaten[];
};

type KontaktAddressEintrag = {
  contact?: { id?: string | number };
  street?: string;
  zip?: string;
  city?: string;
};

type VerwaltungKontakteResponse = {
  Contact?: SevdeskKontakt[];
  ContactAddress?: KontaktAddressEintrag[];
};

type SevdeskVoucherResponse = {
  sevdesk_voucher_id?: string;
};

type RechnungPayload = {
  invoice_nummer: string;
  adress_name: string;
  adresse_strasse: string;
  adresse_plz: string;
  adresse_ort: string;
  betreff: string;
  anrede: string;
  text: string;
  positionen: RechnungPosition[];
};

type TransparentPayload = {
  adress_name: string;
  adresse_strasse: string;
  adresse_plz: string;
  adresse_ort: string;
  nummer: string;
  datumsbereich: string;
  betrag: string;
};

type FestEingang = {
  betrag: number;
  notiz: string;
};

type FestStation = {
  bezeichnung: string;
  wechselgeld: number;
  eingaenge: FestEingang[];
};

type FestPayload = {
  jahr: string;
  tag: string;
  stationen: FestStation[];
};

type FestAbrechnungEintrag = {
  id: string;
  jahr: string;
  tag: string;
  stationen: FestStation[];
  tagesstand: number;
};

@Component({
  selector: 'app-verwaltung',
  standalone: true,
  imports: [
    CommonModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    MatTabsModule,
    MatButtonModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    FormsModule,
    MatInputModule,
    MatIconModule,
    MatSelectModule,
    MatOptionModule,
    MatTableModule,
    MatExpansionModule,
    DateInputMaskDirective,
  ],
  templateUrl: './verwaltung.component.html',
  styleUrl: './verwaltung.component.sass'
})
export class VerwaltungComponent implements OnInit {
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private collectionUtilsService = inject(CollectionUtilsService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  private readonly adminRoleKey = 'ADMIN';
  private readonly modulKonfigurationEndpoint = 'modul_konfiguration';
  title = 'Verwaltung';
  modul = 'verwaltung';

  breadcrumb: ImrBreadcrumbItem[] = [];
  meine_rollen: string[] = [];
  pdfKonfigId: string | null = null;
  pdf_konfig: Record<string, unknown> = {};
  pdfTemplates: IPdfTemplate[] = [];
  private pdfTemplatesLoaded = false;
  stammdaten: IStammdaten | null = null;
  kontakte: SevdeskKontakt[] = [];
  verwaltungDokumente: IVerwaltungDokument[] = [];
  currentRechnungDokumentId: string | null = null;
  currentTransparentDokumentId: string | null = null;
  currentFestDokumentId: string | null = null;
  festStationen: FestStation[] = [];
  festEingangEntwuerfe: Array<{ betrag: string; notiz: string }> = [];
  festStationEditMode: boolean[] = [];
  festAbrechnungUebersicht: FestAbrechnungEintrag[] = [];

  /** erlaubt: 12 | 12,5 | 12,50 | 12.50 */
  private readonly PREIS_REGEX = /^\d+([.,]\d{1,2})?$/;

  formAuswahl = new FormGroup({
    name: new FormControl('')
  });

  formAuswahlTransparent = new FormGroup({
    name: new FormControl('')
  });

  formSettings = new FormGroup({
    idVerwaltungRechnung: new FormControl<string | null>(null),
    idVerwaltungTransparent: new FormControl<string | null>(null),
    idVerwaltungFestAbrechnung: new FormControl<string | null>(null),
  });

  formRechnung = new FormGroup({
    invoice_nummer: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    adress_name: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    adresse_strasse: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    adresse_plz: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    adresse_ort: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    betreff: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    anrede: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    text: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    positionen: new FormControl<RechnungPosition[]>([], {
      nonNullable: true,
      validators: [Validators.required]
    })
  });

  formRechnungPositionen = new FormGroup({
    bezeichnung: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required]
    }),
    preis: new FormControl('', {
      nonNullable: true,
      validators: [
        Validators.required,
        Validators.pattern(this.PREIS_REGEX)
      ]
    })
  });

  formTransparent = new FormGroup({
    adress_name: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    adresse_strasse: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    adresse_plz: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    adresse_ort: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    nummer: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    datumsbereich: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    betrag: new FormControl('', { nonNullable: true, validators: [Validators.required] })
  });

  formFest = new FormGroup({
    jahr: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.pattern(/^\d{4}$/)]
    }),
    tag: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
  });

  formAbrechnung = new FormGroup({
    jahr: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.pattern(/^\d{4}$/)]
    }),
  });

  formFestStation = new FormGroup({
    bezeichnung: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required]
    }),
    wechselgeld: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.pattern(this.PREIS_REGEX)]
    }),
  });

  formDokumente = new FormGroup({
    rechnungId: new FormControl<string | null>(null),
    transparentId: new FormControl<string | null>(null),
    festId: new FormControl<string | null>(null),
  });

  formatPreis(p: number): string {
    return p.toFixed(2).replace('.', ',');
  }

  readonly sichtbareSpaltenPositionen: string[] = ['bezeichnung', 'preis', 'actions'];

  get isAdmin(): boolean {
    return this.meine_rollen.includes(this.adminRoleKey);
  }

  ngOnInit(): void {
    sessionStorage.setItem('PageNumber', '2');
    sessionStorage.setItem('Page2', 'VER');

    this.breadcrumb = this.navigationService.ladeBreadcrumb();

    let param = {
      'includeSevdesk': '1',
      'sevdeskModul': 'Contact'
    };

    this.apiHttpService.get<VerwaltungResponse>(this.modul, param).subscribe({
      next: (erg: VerwaltungResponse) => {
        try {
          this.kontakte = erg.sevdesk?.objects ?? [];
          const templates = (erg.modul_konfig ?? []).find((m: ModulKonfigurationEintrag) => m.modul === 'pdf');
          this.pdf_konfig = templates?.konfiguration ?? {};
          this.stammdaten = erg.konfig?.[0] ?? null;
          this.syncSettingsForm();
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error)
    });

    this.loadSettingsContext();
    this.loadVerwaltungDokumente(() => {
      this.formRechnungReset();
      this.formTransparentReset();
      this.formFestReset();
      this.formAbrechnungReset();
    });
  }

  saveSettings(): void {
    if (!this.isAdmin) {
      return;
    }

    const payload = {
      modul: 'pdf',
      konfiguration: {
        ...this.pdf_konfig,
        idVerwaltungRechnung: this.stringOrNull(this.formSettings.controls.idVerwaltungRechnung.value),
        idVerwaltungTransparent: this.stringOrNull(this.formSettings.controls.idVerwaltungTransparent.value),
        idVerwaltungFestAbrechnung: this.stringOrNull(this.formSettings.controls.idVerwaltungFestAbrechnung.value),
      },
    };

    if (this.pdfKonfigId) {
      this.apiHttpService.patch<ModulKonfigurationSaveResult>(this.modulKonfigurationEndpoint, this.pdfKonfigId, payload, false).subscribe({
        next: (saved) => {
          this.applySavedPdfKonfig(saved);
          this.uiMessageService.erstelleMessage('success', 'PDF-Zuweisungen gespeichert.');
        },
        error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
      });
      return;
    }

    this.apiHttpService.post<ModulKonfigurationSaveResult>(this.modulKonfigurationEndpoint, payload, false).subscribe({
      next: (saved) => {
        this.applySavedPdfKonfig(saved);
        this.uiMessageService.erstelleMessage('success', 'PDF-Zuweisungen gespeichert.');
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  resetSettings(): void {
    this.syncSettingsForm();
  }

  private parsePreis(input: string): number | null {
    const s = input.trim();
    if (!this.PREIS_REGEX.test(s)) return null;

    const normalized = s.replace(',', '.');
    const value = Number(normalized);
    return Number.isFinite(value) ? value : null;
  }

  private parseSignedPreis(input: string): number | null {
    const s = input.trim();
    if (!/^[-]?\d+([.,]\d{1,2})?$/.test(s)) return null;
    const normalized = s.replace(',', '.');
    const value = Number(normalized);
    return Number.isFinite(value) ? value : null;
  }

  normalizeNumber(value: unknown): number {
    if (typeof value === 'number' && Number.isFinite(value)) {
      return value;
    }
    if (typeof value === 'string') {
      const parsed = this.parseSignedPreis(value);
      return parsed ?? 0;
    }
    return 0;
  }

  addPosition(): void {
    if (this.formRechnungPositionen.invalid) {
      this.formRechnungPositionen.markAllAsTouched();
      return;
    }

    const bezeichnung = this.formRechnungPositionen.controls.bezeichnung.value.trim();
    const preisText = this.formRechnungPositionen.controls.preis.value.trim();

    const preis = this.parsePreis(preisText);
    if (preis === null) {
      this.formRechnungPositionen.controls.preis.setErrors({ pattern: true });
      this.formRechnungPositionen.controls.preis.markAsTouched();
      return;
    }

    const current = this.formRechnung.controls.positionen.value;
    this.formRechnung.controls.positionen.setValue([
      ...current,
      { bezeichnung, preis }
    ]);

    this.formRechnung.controls.positionen.markAsDirty();
    this.formRechnungPositionen.reset({ bezeichnung: '', preis: '' });
  }

  removePosition(index: number): void {
    const current = this.formRechnung.controls.positionen.value;
    if (index < 0 || index >= current.length) return;

    this.formRechnung.controls.positionen.setValue(
      current.filter((_, i) => i !== index)
    );

    this.formRechnung.controls.positionen.markAsDirty();
  }

  toggleFestStationEdit(index: number): void {
    if (index < 0 || index >= this.festStationen.length) {
      return;
    }
    this.festStationEditMode[index] = !this.festStationEditMode[index];
  }

  addFestStation(): void {
    if (this.formFestStation.invalid) {
      this.formFestStation.markAllAsTouched();
      return;
    }

    const wechselgeld = this.parsePreis(this.formFestStation.controls.wechselgeld.value);

    if (wechselgeld === null) {
      this.formFestStation.controls.wechselgeld.setErrors({ pattern: true });
      return;
    }

    this.festStationen.push({
      bezeichnung: this.formFestStation.controls.bezeichnung.value.trim(),
      wechselgeld: -wechselgeld, // Wechselgeld als Negativbetrag speichern (Kassenausgabe zu Beginn)
      eingaenge: [],
    });
    this.festEingangEntwuerfe.push({ betrag: '', notiz: '' });
    this.festStationEditMode.push(false);
    this.formFestStation.reset({ bezeichnung: '', wechselgeld: '' });
    this.formFest.markAsDirty();
  }

  removeFestStation(index: number): void {
    if (index < 0 || index >= this.festStationen.length) {
      return;
    }
    this.festStationen.splice(index, 1);
    this.festEingangEntwuerfe.splice(index, 1);
    this.festStationEditMode.splice(index, 1);
    this.formFest.markAsDirty();
  }

  addFestEingang(stationIndex: number): void {
    const station = this.festStationen[stationIndex];
    const entwurf = this.festEingangEntwuerfe[stationIndex];
    if (!station || !entwurf) {
      return;
    }

    const betrag = this.parsePreis(entwurf.betrag);
    if (betrag === null) {
      this.uiMessageService.erstelleMessage('error', 'Ungültiger Eingangs-Betrag.');
      return;
    }

    station.eingaenge.push({
      betrag,
      notiz: entwurf.notiz.trim(),
    });
    entwurf.betrag = '';
    entwurf.notiz = '';
    this.formFest.markAsDirty();
  }

  removeFestEingang(stationIndex: number, eingangIndex: number): void {
    const station = this.festStationen[stationIndex];
    if (!station || eingangIndex < 0 || eingangIndex >= station.eingaenge.length) {
      return;
    }
    station.eingaenge.splice(eingangIndex, 1);
    this.formFest.markAsDirty();
  }

  removeFestEingangByStation(station: FestStation, eingangIndex: number): void {
    const stationIndex = this.festStationen.indexOf(station);
    if (stationIndex < 0) {
      return;
    }
    this.removeFestEingang(stationIndex, eingangIndex);
  }

  sumFestEingaenge(station: FestStation): number {
    return station.eingaenge.reduce((sum, item) => sum + this.normalizeNumber(item.betrag), 0);
  }

  sumFestKassenstand(station: FestStation): number {
    return this.normalizeNumber(station.wechselgeld) + this.sumFestEingaenge(station);
  }

  private generateNummer(typ: 'rechnung' | 'transparent'): string {
    const year = new Date().getFullYear().toString().slice(-2);
    const prefix = typ === 'rechnung' ? 'KR' : 'TR';
    const pattern = new RegExp(`^${prefix}-${year}(\\d+)$`);
    let maxNum = 0;
    for (const doc of this.verwaltungDokumente) {
      if (doc.typ !== typ) continue;
      const payload = doc.payload as Record<string, unknown>;
      const num = typ === 'rechnung'
        ? String(payload['invoice_nummer'] ?? '')
        : String(payload['nummer'] ?? '');
      const match = pattern.exec(num);
      if (match) maxNum = Math.max(maxNum, parseInt(match[1], 10));
    }
    return `${prefix}-${year}${String(maxNum + 1).padStart(3, '0')}`;
  }

  formRechnungReset(): void {
    this.formRechnung.reset({
      invoice_nummer: this.generateNummer('rechnung'),
      adress_name: '',
      adresse_strasse: '',
      adresse_plz: '',
      adresse_ort: '',
      betreff: '',
      anrede: '',
      text: '',
      positionen: []
    });
    this.currentRechnungDokumentId = null;
    this.formDokumente.controls.rechnungId.setValue(null);
  }

  formTransparentReset(): void {
    this.formTransparent.reset({
      adress_name: '',
      adresse_strasse: '',
      adresse_plz: '',
      adresse_ort: '',
      nummer: this.generateNummer('transparent'),
      datumsbereich: '',
      betrag: ''
    });
    this.currentTransparentDokumentId = null;
    this.formDokumente.controls.transparentId.setValue(null);
  }

  formFestReset(): void {
    const heute = normalizeDateInput(formatDateOutput(new Date()));
    this.formFest.reset({
      jahr: String(new Date().getFullYear()),
      tag: heute,
    });
    this.formFestStation.reset({ bezeichnung: '', wechselgeld: '' });
    this.festStationen = [];
    this.festEingangEntwuerfe = [];
    this.festStationEditMode = [];
    this.currentFestDokumentId = null;
    this.formDokumente.controls.festId.setValue(null);
  }

  formAbrechnungReset(): void {
    this.formAbrechnung.reset({
      jahr: String(new Date().getFullYear()),
    });
    this.festAbrechnungUebersicht = [];
  }

  printRechnung(): void {
    this.executePdfAction('rechnung', 'render');
  }

  sendRechnungToSevdesk(): void {
    this.sendDokumentToSevdesk('rechnung');
  }

  printTransparent(): void {
    this.executePdfAction('transparent', 'render');
  }

  sendTransparentToSevdesk(): void {
    this.sendDokumentToSevdesk('transparent');
  }

  saveRechnung(): void {
    this.saveDokument('rechnung', false);
  }

  saveTransparent(): void {
    this.saveDokument('transparent', false);
  }

  saveFest(): void {
    this.saveDokument('fest', false);
  }

  loadFestAbrechnungUebersicht(): void {
    if (this.formAbrechnung.invalid) {
      this.formAbrechnung.markAllAsTouched();
      return;
    }
    const jahr = this.formAbrechnung.controls.jahr.value;
    this.festAbrechnungUebersicht = this.collectFestAbrechnungByJahr(jahr);
  }

  printFestAbrechnung(): void {
    if (this.formAbrechnung.invalid) {
      this.formAbrechnung.markAllAsTouched();
      return;
    }

    const jahr = this.formAbrechnung.controls.jahr.value;
    const daten = this.collectFestAbrechnungByJahr(jahr);
    this.festAbrechnungUebersicht = daten;

    if (daten.length === 0) {
      this.uiMessageService.erstelleMessage('error', `Keine Festdaten für das Jahr ${jahr} gefunden.`);
      return;
    }

    this.executeConfiguredTemplateRender('idVerwaltungFestAbrechnung', this.buildFestAbrechnungRenderPayload(jahr, daten));
  }

  loadRechnungDokument(): void {
    const id = this.formDokumente.controls.rechnungId.value;
    if (!id) return;
    const doc = this.verwaltungDokumente.find((m) => m.id === id);
    if (!doc || doc.typ !== 'rechnung') return;
    this.applyRechnungPayload(doc.payload);
    this.currentRechnungDokumentId = doc.id;
  }

  useRechnungAsDraft(): void {
    const id = this.formDokumente.controls.rechnungId.value;
    if (!id) return;
    const doc = this.verwaltungDokumente.find((m) => m.id === id);
    if (!doc || doc.typ !== 'rechnung') return;
    this.applyRechnungPayload(doc.payload);
    this.formRechnung.controls.invoice_nummer.setValue(this.generateNummer('rechnung'));
    this.currentRechnungDokumentId = null;
    this.formDokumente.controls.rechnungId.setValue(null);
  }

  loadTransparentDokument(): void {
    const id = this.formDokumente.controls.transparentId.value;
    if (!id) return;
    const doc = this.verwaltungDokumente.find((m) => m.id === id);
    if (!doc || doc.typ !== 'transparent') return;
    this.applyTransparentPayload(doc.payload);
    this.currentTransparentDokumentId = doc.id;
  }

  useTransparentAsDraft(): void {
    const id = this.formDokumente.controls.transparentId.value;
    if (!id) return;
    const doc = this.verwaltungDokumente.find((m) => m.id === id);
    if (!doc || doc.typ !== 'transparent') return;
    this.applyTransparentPayload(doc.payload);
    this.formTransparent.controls.nummer.setValue(this.generateNummer('transparent'));
    this.currentTransparentDokumentId = null;
    this.formDokumente.controls.transparentId.setValue(null);
  }

  loadFestDokument(): void {
    const id = this.formDokumente.controls.festId.value;
    if (!id) return;
    const doc = this.verwaltungDokumente.find((m) => m.id === id);
    if (!doc || doc.typ !== 'fest') return;
    this.applyFestPayload(doc.payload);
    this.currentFestDokumentId = doc.id;
  }

  deleteRechnungDokument(): void {
    const id = this.formDokumente.controls.rechnungId.value;
    if (!id) return;
    this.apiHttpService.delete('verwaltung/dokumente', id).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Rechnungsdatensatz gelöscht.');
        if (this.currentRechnungDokumentId === id) {
          this.currentRechnungDokumentId = null;
        }
        this.formDokumente.controls.rechnungId.setValue(null);
        this.loadVerwaltungDokumente();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  deleteTransparentDokument(): void {
    const id = this.formDokumente.controls.transparentId.value;
    if (!id) return;
    this.apiHttpService.delete('verwaltung/dokumente', id).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Transparent-Datensatz gelöscht.');
        if (this.currentTransparentDokumentId === id) {
          this.currentTransparentDokumentId = null;
        }
        this.formDokumente.controls.transparentId.setValue(null);
        this.loadVerwaltungDokumente();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  deleteFestDokument(): void {
    const id = this.formDokumente.controls.festId.value;
    if (!id) return;
    if (!confirm('Fest-Datensatz wirklich löschen?')) return;
    this.apiHttpService.delete('verwaltung/dokumente', id).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Fest-Datensatz gelöscht.');
        if (this.currentFestDokumentId === id) {
          this.currentFestDokumentId = null;
        }
        this.formDokumente.controls.festId.setValue(null);
        this.loadVerwaltungDokumente();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  get rechnungDokumente(): IVerwaltungDokument[] {
    return this.verwaltungDokumente.filter((m) => m.typ === 'rechnung' && !m.is_template);
  }

  get transparentDokumente(): IVerwaltungDokument[] {
    return this.verwaltungDokumente.filter((m) => m.typ === 'transparent' && !m.is_template);
  }

  get festDokumente(): IVerwaltungDokument[] {
    return this.verwaltungDokumente.filter((m) => m.typ === 'fest' && !m.is_template);
  }

  get sumFestEingaengeGesamt(): number {
    return this.festStationen.reduce((sum, station) => sum + this.sumFestEingaenge(station), 0);
  }

  get sumFestTagesstandGesamt(): number {
    return this.festStationen.reduce((sum, station) => sum + this.sumFestKassenstand(station), 0);
  }

  get sumFestAbrechnungTagesstandGesamt(): number {
    return this.festAbrechnungUebersicht.reduce((sum, item) => sum + item.tagesstand, 0);
  }

  getDokumentLabel(doc: IVerwaltungDokument): string {
    const p = doc.payload as Record<string, unknown>;
    if (doc.typ === 'rechnung') {
      const nummer = String(p['invoice_nummer'] ?? '');
      const name = String(p['adress_name'] ?? '');
      return [nummer, name].filter(Boolean).join(' ');
    }
    if (doc.typ === 'transparent') {
      const nummer = String(p['nummer'] ?? '');
      const name = String(p['adress_name'] ?? '');
      return [nummer, name].filter(Boolean).join(' ');
    }
    const jahr = String(p['jahr'] ?? '');
    const tag = String(p['tag'] ?? '');
    const stationen = Array.isArray(p['stationen']) ? (p['stationen'] as Record<string, unknown>[]) : [];
    const tagesstand = stationen.reduce((total, station) => {
      const wechselgeld = Number(station['wechselgeld']) || 0;
      const eingaenge = Array.isArray(station['eingaenge']) ? (station['eingaenge'] as Record<string, unknown>[]) : [];
      const eingaengeSumme = eingaenge.reduce((s, e) => s + (Number(e['betrag']) || 0), 0);
      return total + wechselgeld + eingaengeSumme;
    }, 0);
    const tagesstandStr = tagesstand !== 0 ? ` | Tagesstand: ${this.formatPreis(tagesstand)} €` : '';
    if (!tag) {
      return [jahr].filter(Boolean).join(' ') + tagesstandStr;
    }
    const normalizedTag = normalizeDateInput(tag);
    const parts = normalizedTag.split('-');
    const dateObj = parts.length === 3 ? new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2])) : null;
    const wochentag = dateObj
      ? dateObj.toLocaleDateString('de-DE', { weekday: 'long' })
      : '';
    const tagMonat = dateObj
      ? `${String(dateObj.getDate()).padStart(2, '0')}.${String(dateObj.getMonth() + 1).padStart(2, '0')}.`
      : formatDateOutput(tag);
    return [jahr, wochentag, tagMonat].filter(Boolean).join(' ') + tagesstandStr;
  }

  private handlePrintError(error: unknown): void {
    void this.resolvePrintErrorMessage(error).then((message) => {
      if (message) {
        this.uiMessageService.erstelleMessage('error', message);
        return;
      }
      this.authSessionService.errorAnzeigen(error);
    });
  }

  private executeConfiguredTemplateRender(konfigKey: string, payload: Record<string, unknown>): void {
    const templateId = String(this.pdf_konfig[konfigKey] ?? '').trim();
    if (!templateId) {
      this.uiMessageService.erstelleMessage('error', 'Kein PDF-Template konfiguriert. Bitte die PDF-Zuordnung im Einstellungstab pflegen.');
      return;
    }

    const endpoint = `pdf/templates/${templateId}/render`;
    const targetWindow = window.open('', '_blank');
    if (!targetWindow) {
      this.uiMessageService.erstelleMessage('error', 'Popup blockiert. Bitte Popups für diese Seite erlauben und erneut versuchen.');
      return;
    }

    this.apiHttpService.postBlob(endpoint, payload).subscribe({
      next: (blob: Blob) => {
        if (!blob || blob.size === 0) {
          targetWindow.close();
          this.uiMessageService.erstelleMessage('error', 'PDF ist leer (0 Bytes).');
          return;
        }
        const pdfUrl = URL.createObjectURL(blob);
        targetWindow.location.href = pdfUrl;
      },
      error: (error: unknown) => {
        targetWindow.close();
        this.handlePrintError(error);
      },
    });
  }

  private collectFestAbrechnungByJahr(jahr: string): FestAbrechnungEintrag[] {
    const daten = this.festDokumente
      .map((doc) => {
        const payload = (doc.payload ?? {}) as Record<string, unknown>;
        const payloadJahr = String(payload['jahr'] ?? '');
        if (payloadJahr !== jahr) {
          return null;
        }

        const stationenRaw = Array.isArray(payload['stationen']) ? payload['stationen'] : [];
        const stationen = stationenRaw.map((stationRaw) => {
          const station = (stationRaw ?? {}) as Record<string, unknown>;
          const eingaengeRaw = Array.isArray(station['eingaenge']) ? station['eingaenge'] : [];
          const eingaenge = eingaengeRaw.map((entryRaw) => {
            const entry = (entryRaw ?? {}) as Record<string, unknown>;
            return {
              betrag: this.normalizeNumber(entry['betrag']),
              notiz: String(entry['notiz'] ?? ''),
            };
          });
          return {
            bezeichnung: String(station['bezeichnung'] ?? ''),
            wechselgeld: this.normalizeNumber(station['wechselgeld']),
            eingaenge,
          };
        });

        const tagesstand = stationen.reduce((sum, station) => {
          const eingaengeSumme = station.eingaenge.reduce((entrySum, entry) => entrySum + this.normalizeNumber(entry.betrag), 0);
          return sum + this.normalizeNumber(station.wechselgeld) + eingaengeSumme;
        }, 0);

        return {
          id: doc.id,
          jahr: payloadJahr,
          tag: String(payload['tag'] ?? ''),
          stationen,
          tagesstand,
        } satisfies FestAbrechnungEintrag;
      })
      .filter((item): item is FestAbrechnungEintrag => item !== null);

    return daten.sort((a, b) => a.tag.localeCompare(b.tag));
  }

  private buildFestAbrechnungRenderPayload(jahr: string, daten: FestAbrechnungEintrag[]): Record<string, unknown> {
    return {
      fw_name: this.stammdaten?.fw_name,
      abrechnung_jahr: jahr,
      export_datum: formatDateOutput(new Date()),
      festdaten: daten.map((item) => ({
        tag: item.tag,
        stationen: item.stationen.map((station) => ({
          bezeichnung: station.bezeichnung,
          wechselgeld: this.formatPreis(this.normalizeNumber(station.wechselgeld)),
          eingaenge: station.eingaenge.map((entry) => ({
            betrag: this.formatPreis(this.normalizeNumber(entry.betrag)),
            notiz: entry.notiz,
          })),
          eingaenge_summe: this.formatPreis(this.sumFestEingaenge(station)),
          kassenstand: this.formatPreis(this.sumFestKassenstand(station)),
        })),
        tagesstand: this.formatPreis(item.tagesstand),
      })),
      tagesstand_gesamt: this.formatPreis(daten.reduce((sum, item) => sum + item.tagesstand, 0)),
    };
  }

  private async resolvePrintErrorMessage(error: unknown): Promise<string> {
    if (!(error instanceof HttpErrorResponse)) {
      return '';
    }

    const payload = error.error;
    if (payload instanceof Blob) {
      const text = (await payload.text()).trim();
      if (!text) {
        return `Druck fehlgeschlagen (HTTP ${error.status || 'unbekannt'}).`;
      }

      try {
        const parsed = JSON.parse(text) as Record<string, unknown>;
        const msg = Object.values(parsed).map((v) => String(v)).join('\n').trim();
        return msg || `Druck fehlgeschlagen (HTTP ${error.status || 'unbekannt'}).`;
      } catch {
        return text.slice(0, 400);
      }
    }

    if (typeof payload === 'string' && payload.trim() !== '') {
      return payload.trim();
    }

    return '';
  }

  private loadSettingsContext(): void {
    this.apiHttpService.get<ModulKonfigurationResponse>(this.modulKonfigurationEndpoint).subscribe({
      next: (erg) => {
        this.meine_rollen = this.extractRolesFromPayload(erg);
        const eintraege = this.normalizeModulKonfigEntries(erg);
        const pdfEntry = eintraege
          .filter((item) => String(item.modul ?? '').trim().toLowerCase() === 'pdf')
          .sort((a, b) => String(b.updated_at ?? '').localeCompare(String(a.updated_at ?? '')))[0];
        this.pdfKonfigId = this.stringOrNull(pdfEntry?.id);
        this.pdf_konfig = pdfEntry?.konfiguration ?? this.pdf_konfig;
        this.syncSettingsForm();

        if (this.isAdmin) {
          this.loadPdfTemplatesOnce();
        }
      },
      error: () => {
        this.meine_rollen = [];
        this.pdfKonfigId = null;
        this.syncSettingsForm();
      },
    });
  }

  private loadPdfTemplatesOnce(): void {
    if (this.pdfTemplatesLoaded) {
      return;
    }

    this.apiHttpService.get<PdfTemplatesResponse>('pdf/templates').subscribe({
      next: (erg) => {
        this.pdfTemplates = Array.isArray(erg) ? erg : (erg.main ?? []);
        this.pdfTemplatesLoaded = true;
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  private syncSettingsForm(): void {
    this.formSettings.patchValue({
      idVerwaltungRechnung: this.stringOrNull(this.pdf_konfig['idVerwaltungRechnung']),
      idVerwaltungTransparent: this.stringOrNull(this.pdf_konfig['idVerwaltungTransparent']),
      idVerwaltungFestAbrechnung: this.stringOrNull(this.pdf_konfig['idVerwaltungFestAbrechnung']),
    }, { emitEvent: false });
    this.formSettings.markAsPristine();
    this.formSettings.markAsUntouched();
  }

  private applySavedPdfKonfig(saved: ModulKonfigurationSaveResult): void {
    this.pdfKonfigId = this.stringOrNull(saved.id);
    this.pdf_konfig = saved.konfiguration ?? {};
    this.syncSettingsForm();
  }

  private normalizeModulKonfigEntries(payload: unknown): ModulKonfigurationEintrag[] {
    if (Array.isArray(payload)) {
      return payload as ModulKonfigurationEintrag[];
    }

    if (payload && typeof payload === 'object') {
      const main = (payload as { main?: unknown }).main;
      if (Array.isArray(main)) {
        return main as ModulKonfigurationEintrag[];
      }
    }

    return [];
  }

  private extractRolesFromPayload(payload: unknown): string[] {
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return [];
    }

    return this.normalizeRoles((payload as { user?: { roles?: unknown } }).user?.roles);
  }

  private normalizeRoles(value: unknown): string[] {
    if (Array.isArray(value)) {
      return value.map((item) => String(item).trim().toUpperCase()).filter(Boolean);
    }

    return String(value ?? '')
      .split(',')
      .map((item) => item.trim().toUpperCase())
      .filter(Boolean);
  }

  private stringOrNull(value: unknown): string | null {
    if (value === null || value === undefined || value === '') {
      return null;
    }

    return String(value);
  }

  private loadVerwaltungDokumente(onLoaded?: () => void): void {
    this.apiHttpService.get<IVerwaltungDokument[]>('verwaltung/dokumente').subscribe({
      next: (docs) => {
        this.verwaltungDokumente = Array.isArray(docs) ? docs : [];
        onLoaded?.();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  private saveDokument(typ: VerwaltungDokumentTyp, isTemplate: boolean): void {
    if (typ === 'rechnung' && this.formRechnung.invalid) {
      this.formRechnung.markAllAsTouched();
      this.uiMessageService.erstelleMessage('error', 'Rechnung unvollständig. Bitte alle Pflichtfelder inkl. mindestens einer Position ausfüllen.');
      return;
    }
    if (typ === 'transparent' && this.formTransparent.invalid) {
      this.formTransparent.markAllAsTouched();
      this.uiMessageService.erstelleMessage('error', 'Daten unvollständig. Bitte alle Pflichtfelder ausfüllen.');
      return;
    }
    if (typ === 'fest' && !this.validateFestForm()) {
      return;
    }

    const payload = typ === 'rechnung'
      ? this.getRechnungPayload()
      : typ === 'transparent'
        ? this.getTransparentPayload()
        : this.getFestPayload();

    const title = typ === 'rechnung'
      ? `Rechnung ${this.formRechnung.controls.invoice_nummer.value || 'ohne Nummer'}`
      : typ === 'transparent'
        ? `Transparent ${this.formTransparent.controls.nummer.value || 'ohne Nummer'}`
        : `Fest ${this.formFest.controls.jahr.value || ''} ${this.formFest.controls.tag.value || ''}`.trim();

    const data = {
      typ,
      title,
      payload,
      is_template: isTemplate,
    };

    const currentId = typ === 'rechnung'
      ? this.currentRechnungDokumentId
      : typ === 'transparent'
        ? this.currentTransparentDokumentId
        : this.currentFestDokumentId;
    const request$ = currentId
      ? this.apiHttpService.patch<IVerwaltungDokument>('verwaltung/dokumente', currentId, data, false)
      : this.apiHttpService.post<IVerwaltungDokument>('verwaltung/dokumente', data, false);

    request$.subscribe({
      next: (saved) => {
        if (typ === 'rechnung') {
          this.currentRechnungDokumentId = saved.id;
          this.formDokumente.controls.rechnungId.setValue(saved.is_template ? null : saved.id);
        } else if (typ === 'transparent') {
          this.currentTransparentDokumentId = saved.id;
          this.formDokumente.controls.transparentId.setValue(saved.is_template ? null : saved.id);
        } else {
          this.currentFestDokumentId = saved.id;
          this.formDokumente.controls.festId.setValue(saved.is_template ? null : saved.id);
        }
        this.uiMessageService.erstelleMessage('success', isTemplate ? 'Als Vorlage gespeichert.' : 'Datensatz gespeichert.');
        this.loadVerwaltungDokumente();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  private applyRechnungPayload(payload: Record<string, unknown>): void {
    const positionenRaw = Array.isArray(payload['positionen']) ? payload['positionen'] : [];
    const positionen = positionenRaw.map((p) => {
      const item = (p ?? {}) as Record<string, unknown>;
      return {
        bezeichnung: String(item['bezeichnung'] ?? ''),
        preis: Number(item['preis'] ?? 0),
      };
    });
    this.formRechnung.patchValue({
      invoice_nummer: String(payload['invoice_nummer'] ?? ''),
      adress_name: String(payload['adress_name'] ?? ''),
      adresse_strasse: String(payload['adresse_strasse'] ?? ''),
      adresse_plz: String(payload['adresse_plz'] ?? ''),
      adresse_ort: String(payload['adresse_ort'] ?? ''),
      betreff: String(payload['betreff'] ?? ''),
      anrede: String(payload['anrede'] ?? ''),
      text: String(payload['text'] ?? ''),
      positionen,
    });
  }

  private applyTransparentPayload(payload: Record<string, unknown>): void {
    this.formTransparent.patchValue({
      adress_name: String(payload['adress_name'] ?? ''),
      adresse_strasse: String(payload['adresse_strasse'] ?? ''),
      adresse_plz: String(payload['adresse_plz'] ?? ''),
      adresse_ort: String(payload['adresse_ort'] ?? ''),
      nummer: String(payload['nummer'] ?? ''),
      datumsbereich: String(payload['datumsbereich'] ?? ''),
      betrag: String(payload['betrag'] ?? ''),
    });
  }

  private applyFestPayload(payload: Record<string, unknown>): void {
    const rawStationen = Array.isArray(payload['stationen']) ? payload['stationen'] : [];
    this.festStationen = rawStationen.map((stationRaw) => {
      const station = (stationRaw ?? {}) as Record<string, unknown>;
      const rawEingaenge = Array.isArray(station['eingaenge']) ? station['eingaenge'] : [];
      return {
        bezeichnung: String(station['bezeichnung'] ?? ''),
        wechselgeld: this.normalizeNumber(station['wechselgeld']),
        eingaenge: rawEingaenge.map((itemRaw) => {
          const item = (itemRaw ?? {}) as Record<string, unknown>;
          return {
            betrag: this.normalizeNumber(item['betrag']),
            notiz: String(item['notiz'] ?? ''),
          };
        }),
      };
    });
    this.festEingangEntwuerfe = this.festStationen.map(() => ({ betrag: '', notiz: '' }));
    this.festStationEditMode = this.festStationen.map(() => false);
    this.formFest.patchValue({
      jahr: String(payload['jahr'] ?? ''),
      tag: String(payload['tag'] ?? ''),
    });
  }

  private getRechnungPayload(): RechnungPayload {
    return {
      invoice_nummer: this.formRechnung.controls.invoice_nummer.value,
      adress_name: this.formRechnung.controls.adress_name.value,
      adresse_strasse: this.formRechnung.controls.adresse_strasse.value,
      adresse_plz: this.formRechnung.controls.adresse_plz.value,
      adresse_ort: this.formRechnung.controls.adresse_ort.value,
      betreff: this.formRechnung.controls.betreff.value,
      anrede: this.formRechnung.controls.anrede.value,
      text: this.formRechnung.controls.text.value,
      positionen: this.formRechnung.controls.positionen.value,
    };
  }

  private getTransparentPayload(): TransparentPayload {
    return {
      adress_name: this.formTransparent.controls.adress_name.value,
      adresse_strasse: this.formTransparent.controls.adresse_strasse.value,
      adresse_plz: this.formTransparent.controls.adresse_plz.value,
      adresse_ort: this.formTransparent.controls.adresse_ort.value,
      nummer: this.formTransparent.controls.nummer.value,
      datumsbereich: this.formTransparent.controls.datumsbereich.value,
      betrag: this.formTransparent.controls.betrag.value,
    };
  }

  private getFestPayload(): FestPayload {
    const normalizedTag = normalizeDateInput(this.formFest.controls.tag.value);
    return {
      jahr: this.formFest.controls.jahr.value,
      tag: normalizedTag,
      stationen: this.festStationen.map((station) => ({
        bezeichnung: String(station.bezeichnung ?? '').trim(),
        wechselgeld: this.normalizeNumber(station.wechselgeld),
        eingaenge: station.eingaenge.map((item) => ({
          betrag: this.normalizeNumber(item.betrag),
          notiz: String(item.notiz ?? '').trim(),
        })),
      })),
    };
  }

  private validateFestForm(): boolean {
    if (this.formFest.invalid) {
      this.formFest.markAllAsTouched();
      this.uiMessageService.erstelleMessage('error', 'Bitte Jahr und Tag im Fest-Tab ausfüllen.');
      return false;
    }
    if (this.festStationen.length === 0) {
      this.uiMessageService.erstelleMessage('error', 'Bitte mindestens eine Station/Kassa/Kellner hinzufügen.');
      return false;
    }

    const hasInvalidStation = this.festStationen.some((station) => !String(station.bezeichnung ?? '').trim());
    if (hasInvalidStation) {
      this.uiMessageService.erstelleMessage('error', 'Jede Station benötigt eine Bezeichnung.');
      return false;
    }
    return true;
  }

  private executePdfAction(typ: VerwaltungDokumentTyp, mode: 'preview' | 'render'): void {
    if (!this.stammdaten) {
      this.uiMessageService.erstelleMessage('error', 'Stammdaten nicht geladen. Bitte Seite neu laden und erneut versuchen.');
      return;
    }

    if (typ === 'rechnung') {
      if (this.formRechnung.invalid) {
        this.formRechnung.markAllAsTouched();
        this.uiMessageService.erstelleMessage('error', 'Rechnung unvollständig. Bitte alle Pflichtfelder inkl. mindestens einer Position ausfüllen.');
        return;
      }
      const pos = this.formRechnung.controls.positionen.value;
      if (!Array.isArray(pos) || pos.length === 0) {
        this.uiMessageService.erstelleMessage('error', 'Mindestens eine Rechnungsposition ist erforderlich.');
        return;
      }
    } else if (this.formTransparent.invalid) {
      this.formTransparent.markAllAsTouched();
      this.uiMessageService.erstelleMessage('error', 'Daten unvollständig. Bitte alle Pflichtfelder ausfüllen.');
      return;
    }

    const templateId = typ === 'rechnung'
      ? String(this.pdf_konfig['idVerwaltungRechnung'] ?? '').trim()
      : String(this.pdf_konfig['idVerwaltungTransparent'] ?? '').trim();

    if (!templateId) {
      this.uiMessageService.erstelleMessage('error', 'Kein PDF-Template konfiguriert. Bitte die PDF-Zuordnung im Einstellungstab pflegen.');
      return;
    }

    const endpoint = `pdf/templates/${templateId}/${mode}`;
    const payload = typ === 'rechnung'
      ? this.buildRechnungRenderPayload()
      : this.buildTransparentRenderPayload();
    const targetWindow = window.open('', '_blank');
    if (!targetWindow) {
      this.uiMessageService.erstelleMessage('error', 'Popup blockiert. Bitte Popups für diese Seite erlauben und erneut versuchen.');
      return;
    }

    if (mode === 'preview') {
      this.apiHttpService.postText(endpoint, payload).subscribe({
        next: (html) => {
          targetWindow.document.open();
          targetWindow.document.write(html);
          targetWindow.document.close();
        },
        error: (error: unknown) => {
          targetWindow.close();
          this.handlePrintError(error);
        },
      });
      return;
    }

    this.apiHttpService.postBlob(endpoint, payload).subscribe({
      next: (blob: Blob) => {
        if (!blob || blob.size === 0) {
          targetWindow.close();
          this.uiMessageService.erstelleMessage('error', 'PDF ist leer (0 Bytes).');
          return;
        }
        const pdfUrl = URL.createObjectURL(blob);
        targetWindow.location.href = pdfUrl;
      },
      error: (error: unknown) => {
        targetWindow.close();
        this.handlePrintError(error);
      },
    });
  }

  private sendDokumentToSevdesk(typ: VerwaltungDokumentTyp): void {
    const id = typ === 'rechnung'
      ? this.currentRechnungDokumentId
      : typ === 'transparent'
        ? this.currentTransparentDokumentId
        : this.currentFestDokumentId;
    if (!id) {
      this.uiMessageService.erstelleMessage('error', 'Bitte zuerst speichern, bevor der Beleg an SevDesk gesendet wird.');
      return;
    }

    this.apiHttpService.post<SevdeskVoucherResponse>(`verwaltung/dokumente/${id}/sevdesk-beleg`, {}, false).subscribe({
      next: (result) => {
        const voucherId = String(result?.sevdesk_voucher_id ?? '').trim();
        const message = voucherId
          ? `Beleg als Entwurf in SevDesk angelegt (ID: ${voucherId}).`
          : 'Beleg als Entwurf in SevDesk angelegt.';
        this.uiMessageService.erstelleMessage('success', message);
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  private buildRechnungRenderPayload(): Record<string, unknown> {
    const heute = formatDateOutput(new Date());
    const rechnung = this.getRechnungPayload();
    const positionen = rechnung.positionen;
    const betrag_total = positionen.reduce((sum, p) => sum + p.preis, 0);
    const invoice_items = positionen.map((p) => ({
      bezeichnung: p.bezeichnung,
      preis: p.preis.toFixed(2),
    }));

    return {
      fw_name: this.stammdaten?.fw_name,
      fw_nummer: this.stammdaten?.fw_nummer,
      fw_street: this.stammdaten?.fw_street,
      fw_plz: this.stammdaten?.fw_plz,
      fw_ort: this.stammdaten?.fw_ort,
      fw_email: this.stammdaten?.fw_email,
      fw_telefon: this.stammdaten?.fw_telefon,
      fw_konto: this.stammdaten?.fw_konto,
      fw_iban: this.stammdaten?.fw_iban,
      fw_bic: this.stammdaten?.fw_bic,
      fw_kdt: this.stammdaten?.fw_kdt,
      invoice_datum: heute,
      invoice_nummer: rechnung.invoice_nummer,
      customer_name: rechnung.adress_name,
      customer_street: rechnung.adresse_strasse,
      customer_plz: rechnung.adresse_plz,
      customer_ort: rechnung.adresse_ort,
      invoice_betreff: rechnung.betreff,
      invoice_anrede: rechnung.anrede,
      invoice_text: rechnung.text,
      invoice_items,
      invoice_total_betrag: betrag_total.toFixed(2),
    };
  }

  private buildTransparentRenderPayload(): Record<string, unknown> {
    const heute = formatDateOutput(new Date());
    const transparent = this.getTransparentPayload();

    return {
      fw_name: this.stammdaten?.fw_name,
      fw_nummer: this.stammdaten?.fw_nummer,
      fw_street: this.stammdaten?.fw_street,
      fw_plz: this.stammdaten?.fw_plz,
      fw_ort: this.stammdaten?.fw_ort,
      fw_email: this.stammdaten?.fw_email,
      fw_telefon: this.stammdaten?.fw_telefon,
      fw_konto: this.stammdaten?.fw_konto,
      fw_iban: this.stammdaten?.fw_iban,
      fw_bic: this.stammdaten?.fw_bic,
      fw_kdt: this.stammdaten?.fw_kdt,
      invoice_datum: heute,
      customer_name: transparent.adress_name,
      customer_street: transparent.adresse_strasse,
      customer_plz: transparent.adresse_plz,
      customer_ort: transparent.adresse_ort,
      transparent_nummer: transparent.nummer,
      transparent_datumsbereich: transparent.datumsbereich,
      transparent_betrag: transparent.betrag,
    };
  }

  sevdeskKontaktUebernehmen(): void {
    const kontaktId = this.formAuswahl.controls.name.value;
    if (!kontaktId) return;

    this.apiHttpService.get<VerwaltungKontakteResponse>('verwaltung/kontakte').subscribe({
      next: (erg: VerwaltungKontakteResponse) => {
        try {
          const kontakte = erg.Contact ?? [];
          const kontaktAdressen = erg.ContactAddress ?? [];

          const kontakt = kontakte.find((m: SevdeskKontakt) => String(m.id) === kontaktId);
          const kontaktAddresse = kontaktAdressen.find((m: KontaktAddressEintrag) => String(m.contact?.id ?? '') === kontaktId);
          this.formRechnung.controls.adress_name.setValue(kontakt?.name ?? '');
          this.formRechnung.controls.adresse_strasse.setValue(kontaktAddresse?.street ?? '');
          this.formRechnung.controls.adresse_plz.setValue(kontaktAddresse?.zip ?? '');
          this.formRechnung.controls.adresse_ort.setValue(kontaktAddresse?.city ?? '');
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error)
    });
    
  }

  sevdeskKontaktTransparentUebernehmen(): void {
    const kontaktId = this.formAuswahlTransparent.controls.name.value;
    if (!kontaktId) return;

    this.apiHttpService.get<VerwaltungKontakteResponse>('verwaltung/kontakte').subscribe({
      next: (erg: VerwaltungKontakteResponse) => {
        try {
          const kontakte = erg.Contact ?? [];
          const kontaktAdressen = erg.ContactAddress ?? [];

          const kontakt = kontakte.find((m: SevdeskKontakt) => String(m.id) === kontaktId);
          const kontaktAddresse = kontaktAdressen.find((m: KontaktAddressEintrag) => String(m.contact?.id ?? '') === kontaktId);
          this.formTransparent.controls.adress_name.setValue(kontakt?.name ?? '');
          this.formTransparent.controls.adresse_strasse.setValue(kontaktAddresse?.street ?? '');
          this.formTransparent.controls.adresse_plz.setValue(kontaktAddresse?.zip ?? '');
          this.formTransparent.controls.adresse_ort.setValue(kontaktAddresse?.city ?? '');
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error)
    });
    
  }
}
