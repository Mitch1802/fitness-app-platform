﻿import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerwaltungComponent } from './verwaltung.component';

describe('VerwaltungComponent', () => {
  let component: VerwaltungComponent;
  let fixture: ComponentFixture<VerwaltungComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VerwaltungComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VerwaltungComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add station and calculate total incoming sum', () => {
    component.formFestStation.setValue({
      bezeichnung: 'Kasse 1',
      wechselgeld: '100',
    });
    component.addFestStation();
    component.festEingangEntwuerfe[0] = { betrag: '25,50', notiz: 'Mittag' };
    component.addFestEingang(0);

    expect(component.festStationen.length).toBe(1);
    expect(component.sumFestEingaengeGesamt).toBe(25.5);
    expect(component.sumFestKassenstand(component.festStationen[0])).toBe(125.5);
  });
});
