import { Component, ElementRef, OnInit, ViewChild, inject } from '@angular/core';
import { FormControl, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { CommonModule } from '@angular/common';
import { ApiHttpService } from 'src/app/_service/api-http.service';
import { UiMessageService } from 'src/app/_service/ui-message.service';
import { IFotoEventPublic } from 'src/app/_interface/fotoupload';
import { ImrPageLayoutComponent } from '../imr-ui-library';
import { formatDateOutput } from '../_utils/date-normalization.util';

@Component({
  selector: 'app-fotoupload-extern',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ImrPageLayoutComponent,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
  ],
  templateUrl: './fotoupload-extern.component.html',
  styleUrl: './fotoupload-extern.component.sass',
})
export class FotouploadExternComponent implements OnInit {
  @ViewChild('fotoInput') fotoInputRef?: ElementRef<HTMLInputElement>;

  private apiHttpService = inject(ApiHttpService);
  private uiMessageService = inject(UiMessageService);

  events: IFotoEventPublic[] = [];
  selectedFiles: File[] = [];
  uploading = false;
  uploadSuccess = false;
  uploadedCount = 0;

  form = new FormGroup({
    event_id: new FormControl<string>('', [Validators.required]),
    uploader_name: new FormControl<string>('', [Validators.required, Validators.maxLength(255)]),
  });

  ngOnInit(): void {
    this.ladeEvents();
  }

  ladeEvents(): void {
    this.apiHttpService.get<IFotoEventPublic[]>('fotoupload/public/events').subscribe({
      next: (data) => {
        this.events = data;
      },
      error: () => {
        this.uiMessageService.erstelleMessage('error', 'Events konnten nicht geladen werden.');
      },
    });
  }

  onFotoAuswahl(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files) return;
    const files = Array.from(input.files);
    const MAX = 200;
    if (files.length > MAX) {
      this.uiMessageService.erstelleMessage('error', `Maximal ${MAX} Fotos pro Upload erlaubt.`);
      input.value = '';
      return;
    }
    this.selectedFiles = files;
  }

  fotoEntfernen(index: number): void {
    this.selectedFiles = this.selectedFiles.filter((_, i) => i !== index);
  }

  get formattedFileSize(): string {
    const total = this.selectedFiles.reduce((sum, f) => sum + f.size, 0);
    if (total < 1024 * 1024) return `${(total / 1024).toFixed(1)} KB`;
    return `${(total / (1024 * 1024)).toFixed(1)} MB`;
  }

  hochladen(): void {
    if (this.form.invalid || this.selectedFiles.length === 0 || this.uploading) return;

    const fd = new FormData();
    fd.append('event_id', this.form.value.event_id!);
    fd.append('uploader_name', this.form.value.uploader_name!);
    this.selectedFiles.forEach((f) => fd.append('fotos', f, f.name));

    this.uploading = true;
    this.apiHttpService.post<{ detail: string; foto_anzahl: number }>('fotoupload/public/upload', fd).subscribe({
      next: (res) => {
        this.uploading = false;
        this.uploadSuccess = true;
        this.uploadedCount = res.foto_anzahl;
        this.form.reset();
        this.selectedFiles = [];
        if (this.fotoInputRef?.nativeElement) {
          this.fotoInputRef.nativeElement.value = '';
        }
      },
      error: (err) => {
        this.uploading = false;
        const msg = err?.error?.detail ?? 'Upload fehlgeschlagen. Bitte versuche es erneut.';
        this.uiMessageService.erstelleMessage('error', msg);
      },
    });
  }

  weiteresFotoHochladen(): void {
    this.uploadSuccess = false;
    this.uploadedCount = 0;
    this.form.reset();
    this.selectedFiles = [];
    this.ladeEvents();
    if (this.fotoInputRef?.nativeElement) {
      this.fotoInputRef.nativeElement.value = '';
    }
  }

  formatEventDate(dateValue: string | null): string {
    return formatDateOutput(dateValue);
  }
}
