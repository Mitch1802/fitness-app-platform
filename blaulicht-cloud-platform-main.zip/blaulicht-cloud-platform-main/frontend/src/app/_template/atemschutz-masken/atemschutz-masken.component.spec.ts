﻿import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AtemschutzMaskenComponent } from './atemschutz-masken.component';
import { IAtemschutzMaske } from 'src/app/_interface/atemschutz_maske';

describe('AtemschutzMaskenComponent', () => {
  let component: AtemschutzMaskenComponent;
  let fixture: ComponentFixture<AtemschutzMaskenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AtemschutzMaskenComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AtemschutzMaskenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should reset protocol id when starting a new protocol entry', () => {
    component.formPruefung.setValue({
      id: 'existing-id',
      maske_id: 123,
      datum: '01.01.2026',
      taetigkeit: 'Check',
      verwendung_typ: 'E',
      verwendung_min: 10,
      wartung_2_punkt: true,
      wartung_unterdruck: true,
      wartung_oeffnungsdruck: true,
      wartung_scheibe: true,
      wartung_ventile: true,
      wartung_maengel: true,
      ausser_dienst: false,
      tausch_sprechmembran: false,
      tausch_ausatemventil: false,
      tausch_sichtscheibe: false,
      name_pruefer: 'Tester',
      notiz: 'Altwert',
    });

    component.neuePruefung();

    expect(component.formPruefung.controls['id'].value).toBe('');
    expect(component.formPruefung.controls['maske_id'].value).toBe(0);
    expect(component.showPruefungForm).toBeTrue();
  });

  it('should clear stale id and set selected maske in row action', () => {
    component.formPruefung.setValue({
      id: 'old-id',
      maske_id: 0,
      datum: '',
      taetigkeit: '',
      verwendung_typ: '',
      verwendung_min: 0,
      wartung_2_punkt: false,
      wartung_unterdruck: false,
      wartung_oeffnungsdruck: false,
      wartung_scheibe: false,
      wartung_ventile: false,
      wartung_maengel: false,
      ausser_dienst: false,
      tausch_sprechmembran: false,
      tausch_ausatemventil: false,
      tausch_sichtscheibe: false,
      name_pruefer: '',
      notiz: '',
    });

    const maske = { pkid: 77 } as IAtemschutzMaske;

    component.neuePruefungVonMaske(maske);

    expect(component.formPruefung.controls['id'].value).toBe('');
    expect(component.formPruefung.controls['maske_id'].value).toBe(77);
    expect(component.formPruefung.controls['maske_id'].disabled).toBeTrue();
  });
});

