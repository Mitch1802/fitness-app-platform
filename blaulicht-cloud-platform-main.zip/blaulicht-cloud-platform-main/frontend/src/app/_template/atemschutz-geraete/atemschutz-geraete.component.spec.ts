﻿import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AtemschutzGeraeteComponent } from './atemschutz-geraete.component';
import { IAtemschutzGeraet } from 'src/app/_interface/atemschutz_geraet';

describe('AtemschutzComponent', () => {
  let component: AtemschutzGeraeteComponent;
  let fixture: ComponentFixture<AtemschutzGeraeteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AtemschutzGeraeteComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AtemschutzGeraeteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should reset protocol id when starting a new protocol entry', () => {
    component.formPruefung.setValue({
      id: 'existing-id',
      geraet_id: 123,
      datum: '01.01.2026',
      taetigkeit: 'Check',
      verwendung_typ: 'E',
      verwendung_min: 10,
      mitglied_id: 0,
      geraet_ok: true,
      name_pruefer: 'Tester',
      tausch_hochdruckdichtring: true,
      tausch_membran: true,
      tausch_gleitring: true,
      pruefung_10jahre: true,
      pruefung_jaehrlich: true,
      preufung_monatlich: true,
      notiz: 'Altwert',
    });

    component.neuePruefung();

    expect(component.formPruefung.controls['id'].value).toBe('');
    expect(component.formPruefung.controls['geraet_id'].value).toBe(0);
    expect(component.showPruefungForm).toBeTrue();
  });

  it('should clear stale id and set selected geraet in row action', () => {
    component.formPruefung.setValue({
      id: 'old-id',
      geraet_id: 0,
      datum: '',
      taetigkeit: '',
      verwendung_typ: '',
      verwendung_min: 0,
      mitglied_id: 0,
      geraet_ok: false,
      name_pruefer: '',
      tausch_hochdruckdichtring: false,
      tausch_membran: false,
      tausch_gleitring: false,
      pruefung_10jahre: false,
      pruefung_jaehrlich: false,
      preufung_monatlich: false,
      notiz: '',
    });

    const geraet = { pkid: 77 } as IAtemschutzGeraet;

    component.neuePruefungVonMaske(geraet);

    expect(component.formPruefung.controls['id'].value).toBe('');
    expect(component.formPruefung.controls['geraet_id'].value).toBe(77);
    expect(component.formPruefung.controls['geraet_id'].disabled).toBeTrue();
  });
});

