﻿import { Component, OnInit, inject } from '@angular/core';
import { ApiHttpService } from 'src/app/_service/api-http.service';
import { AuthSessionService } from 'src/app/_service/auth-session.service';
import { CollectionUtilsService } from 'src/app/_service/collection-utils.service';
import { NavigationService } from 'src/app/_service/navigation.service';
import { UiMessageService } from 'src/app/_service/ui-message.service';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../../imr-ui-library';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { IMessgeraet } from 'src/app/_interface/messgeraet';
import { IMessgeraetProtokoll } from 'src/app/_interface/messgeraet_protokoll';
import { DateInputMaskDirective } from '../../_directive/date-input-mask.directive';

type AtemschutzRolesResponse = {
  roles?: unknown;
  user?: { roles?: unknown };
  main?: { user?: { roles?: unknown } };
};

@Component({
  selector: 'app-atemschutz-messgeraete',
  imports: [
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatIconModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    MatInputModule,
    MatSelectModule,
    MatTabsModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    DateInputMaskDirective,
  ],
  templateUrl: './atemschutz-messgeraete.component.html',
  styleUrl: './atemschutz-messgeraete.component.sass'
})
export class AtemschutzMessgeraeteComponent implements OnInit {
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private collectionUtilsService = inject(CollectionUtilsService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  title = 'Messgeräte verwalten';
  title_modul = this.title;
  title_pruefung = 'Messgeräte prüfen';
  modul = 'atemschutz/messgeraete';
  showPruefungForm: boolean = false;
  showPruefungTable: boolean = false;

  messgeraete: IMessgeraet[] = [];
  pruefungen: IMessgeraetProtokoll[] = [];
  userRoles: string[] = [];
  canEditProtocol = false;
  canCreateProtocol = false;
  rolesResolved = false;
  breadcrumb: ImrBreadcrumbItem[] = [];
  dataSource = new MatTableDataSource<IMessgeraet>(this.messgeraete);
  dataSourcePruefungen = new MatTableDataSource<IMessgeraetProtokoll>(
    this.pruefungen
  );
  sichtbareSpalten: string[] = ['inv_nr', 'bezeichnung', 'letzte_pruefung', 'naechste_pruefung', 'actions'];
  sichtbareSpaltenPruefungen: string[] = [
    'datum',
    'name_pruefer',
    'actions',
  ];

  formModul = new FormGroup({
    id: new FormControl(''),
    inv_nr: new FormControl('', Validators.required),
    bezeichnung: new FormControl('', Validators.required),
    eigentuemer: new FormControl(''),
    barcode: new FormControl(''),
    baujahr: new FormControl(''),
    kalibrierung_intervall_tage: new FormControl(365, [Validators.required, Validators.min(1)]),
  });

  formPruefung = new FormGroup({
    id: new FormControl(''),
    geraet_id: new FormControl(0, Validators.required),
    datum: new FormControl('', [
      Validators.pattern(/^([0-3]\d)\.([0-1]\d)\.(\d{4})$/),
      this.validDateDDMMYYYY(),
      Validators.required,
    ]),
    kalibrierung: new FormControl(false),
    kontrolle_woechentlich: new FormControl(false),
    wartung_jaehrlich: new FormControl(false),
    name_pruefer: new FormControl('', Validators.required),
    notiz: new FormControl(''),
  });

  ngOnInit(): void {
    sessionStorage.setItem("PageNumber", "3");
    sessionStorage.setItem("Page3", "ATM_MG");
    this.breadcrumb = this.navigationService.ladeBreadcrumb();
    this.formModul.disable();
    this.formPruefung.disable();
    this.loadCurrentUserRoles();

    this.reloadMessgeraeteKontext();
  }

  private reloadMessgeraeteKontext(): void {
    this.apiHttpService.get<IMessgeraet[]>(this.modul).subscribe({
      next: (erg: IMessgeraet[]) => {
        try {
          this.messgeraete = erg;
          this.dataSource.data = erg;
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => {
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  neueDetails(): void {
    this.formModul.enable();
  }

  neuePruefung(): void {
    if (this.rolesResolved && !this.canCreateProtocol) {
      this.uiMessageService.erstelleMessage('info', 'Nur ADMIN/PROTOKOLL/ATEMSCHUTZ dürfen Protokolle anlegen.');
      return;
    }
    this.formPruefung.reset({
      id: '',
      geraet_id: 0,
      datum: '',
      kalibrierung: false,
      kontrolle_woechentlich: false,
      wartung_jaehrlich: false,
      name_pruefer: '',
      notiz: '',
    });
    this.showPruefungForm = true;
    this.formPruefung.enable();
    this.title = this.title_pruefung;
  }

  neuePruefungVonMessgeraet(element: IMessgeraet): void {
    if (this.rolesResolved && !this.canCreateProtocol) {
      this.uiMessageService.erstelleMessage('info', 'Nur ADMIN/PROTOKOLL/ATEMSCHUTZ dürfen Protokolle anlegen.');
      return;
    }
    this.formPruefung.reset({
      id: '',
      geraet_id: 0,
      datum: '',
      kalibrierung: false,
      kontrolle_woechentlich: false,
      wartung_jaehrlich: false,
      name_pruefer: '',
      notiz: '',
    });
    this.showPruefungForm = true;
    this.formPruefung.enable();
    this.title = this.title_pruefung;
    this.formPruefung.controls['geraet_id'].setValue(element.pkid);
    this.formPruefung.controls['geraet_id'].disable();
  }

  auswahlBearbeiten(element: IMessgeraet): void {
    if (!element.id || element.id === '0') {
      return;
    }
    const abfrageUrl = `${this.modul}/${element.id}`;

    this.apiHttpService.get<IMessgeraet>(abfrageUrl).subscribe({
      next: (erg: IMessgeraet) => {
        try {
          const details: IMessgeraet = erg;

          this.formModul.enable();
          this.formModul.setValue({
            id: details.id,
            inv_nr: details.inv_nr,
            bezeichnung: details.bezeichnung,
            eigentuemer: details.eigentuemer,
            barcode: details.barcode,
            baujahr: details.baujahr,
            kalibrierung_intervall_tage: details.kalibrierung_intervall_tage ?? 365,
          });
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => {
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  showMessgeraete(): void {
    this.showPruefungTable = false;
    this.title = this.title_modul;
  }

  showPruefungen(element: IMessgeraet): void {
    if (!element.id || element.id === '0') {
      return;
    }
    this.title = this.title_pruefung;

    const abfrageUrl = `${this.modul}/protokoll`;
    const param = { geraet_id: element.pkid };

    this.apiHttpService.get<IMessgeraetProtokoll[]>(abfrageUrl, param, true).subscribe({
      next: (erg: IMessgeraetProtokoll[]) => {
        try {
          this.showPruefungTable = true;
          this.pruefungen = erg;
          this.dataSourcePruefungen.data = this.pruefungen;
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => {
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  auswahlBearbeitenProtokoll(element: IMessgeraetProtokoll): void {
    if (!element.id || element.id === '0') {
      return;
    }
    const abfrageUrl = `${this.modul}/protokoll/${element.id}`;

    this.apiHttpService.get<IMessgeraetProtokoll>(abfrageUrl).subscribe({
      next: (erg: IMessgeraetProtokoll) => {
        try {
          this.showPruefungTable = false;
          this.showPruefungForm = true;
          const details: IMessgeraetProtokoll = erg;
          this.formPruefung.setValue({
            id: details.id,
            geraet_id: details.geraet_id,
            datum: details.datum,
            kalibrierung: details.kalibrierung,
            kontrolle_woechentlich: details.kontrolle_woechentlich,
            wartung_jaehrlich: details.wartung_jaehrlich,
            name_pruefer: details.name_pruefer,
            notiz: details.notiz ?? '',
          });

          this.formPruefung.enable();
          if (this.rolesResolved && !this.canEditProtocol) {
            this.applyNoteOnlyMode();
          }
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => {
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  datenSpeichern(): void {
    if (this.formModul.invalid) {
      this.uiMessageService.erstelleMessage(
        'error',
        'Bitte alle Pflichtfelder korrekt ausfüllen!'
      );
      return;
    }

    const objekt = this.formModul.getRawValue();
    const idValue = this.formModul.controls['id'].value;

    if (!idValue) {
      this.apiHttpService.post<IMessgeraet>(this.modul, objekt, false).subscribe({
        next: (erg: IMessgeraet) => {
          try {
            const newMask: IMessgeraet = erg;
            this.messgeraete.push(newMask);
            this.messgeraete = this.collectionUtilsService.arraySortByKey(
              this.messgeraete,
              'inv_nr'
            );
            this.dataSource.data = this.messgeraete;

            this.formModul.reset({
              id: '',
              inv_nr: '',
              bezeichnung: '',
              eigentuemer: '',
              barcode: '',
              baujahr: '',
              kalibrierung_intervall_tage: 365,
            });
            this.formModul.disable();
            this.uiMessageService.erstelleMessage(
              'success',
              'Messgerät gespeichert!'
            );
          } catch (e: unknown) {
            this.uiMessageService.erstelleMessage('error', String(e));
          }
        },
        error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
      });
    } else {
      this.apiHttpService
        .patch<IMessgeraet>(this.modul, idValue, objekt, false)
        .subscribe({
          next: (_erg: IMessgeraet) => {
            try {
              this.reloadMessgeraeteKontext();

              this.formModul.reset({
                id: '',
                inv_nr: '',
                bezeichnung: '',
                eigentuemer: '',
                barcode: '',
                baujahr: '',
                kalibrierung_intervall_tage: 365,
              });
              this.formModul.disable();

              this.uiMessageService.erstelleMessage(
                'success',
                'Messgerät geändert!'
              );
            } catch (e: unknown) {
              this.uiMessageService.erstelleMessage('error', String(e));
            }
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
        });
    }
  }

  datenSpeichernProtokoll(): void {
    if (this.formPruefung.invalid) {
      this.uiMessageService.erstelleMessage(
        'error',
        'Bitte alle Pflichtfelder korrekt ausfüllen!'
      );
      return;
    }
    const idValue = this.getCurrentProtocolId();

    if (!idValue) {
      if (this.rolesResolved && !this.canCreateProtocol) {
        this.uiMessageService.erstelleMessage('error', 'Nur ADMIN/PROTOKOLL/ATEMSCHUTZ dürfen Protokolle anlegen.');
        return;
      }

      const objekt = this.formPruefung.getRawValue();

      this.apiHttpService
        .post<IMessgeraetProtokoll>(`${this.modul}/protokoll`, objekt, false)
        .subscribe({
          next: (erg: IMessgeraetProtokoll) => {
            try {
              const newPrufung: IMessgeraetProtokoll = erg;
              this.pruefungen.push(newPrufung);
              this.pruefungen = this.collectionUtilsService.arraySortByKey(
                this.pruefungen,
                'datum'
              );
              this.dataSourcePruefungen.data = this.pruefungen;
              this.reloadMessgeraeteKontext();

              this.formPruefung.reset({
                id: '',
                geraet_id: 0,
                datum: '',
                kalibrierung: false,
                kontrolle_woechentlich: false,
                wartung_jaehrlich: false,
                name_pruefer: '',
                notiz: '',
              });
              this.formPruefung.disable();
              this.showPruefungForm = false;
              this.showPruefungTable = false;
              this.uiMessageService.erstelleMessage(
                'success',
                'Protokoll gespeichert!'
              );
            } catch (e: unknown) {
              this.uiMessageService.erstelleMessage('error', String(e));
            }
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
        });
    } else {
      const objekt = this.canEditProtocol
        ? this.formPruefung.getRawValue()
        : { notiz: this.formPruefung.controls['notiz'].value ?? '' };

      this.apiHttpService
        .patch<IMessgeraetProtokoll>(`${this.modul}/protokoll`, idValue, objekt, false)
        .subscribe({
          next: (erg: IMessgeraetProtokoll) => {
            try {
              const updated = erg;
              this.pruefungen = this.pruefungen
                .map((m) => (m.id === updated.id ? updated : m))
                .sort((a, b) => a.datum.localeCompare(b.datum));

              this.dataSourcePruefungen.data = this.pruefungen;
              this.reloadMessgeraeteKontext();

              this.formPruefung.reset({
                id: '',
                geraet_id: 0,
                datum: '',
                kalibrierung: false,
                kontrolle_woechentlich: false,
                wartung_jaehrlich: false,
                name_pruefer: '',
                notiz: '',
              });
              this.formPruefung.disable();
              this.showPruefungForm = false;
              this.showPruefungTable = true;
              this.uiMessageService.erstelleMessage(
                'success',
                'Protokoll geändert!'
              );
            } catch (e: unknown) {
              this.uiMessageService.erstelleMessage('error', String(e));
            }
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
        });
    }
  }

  abbrechen(): void {
    this.uiMessageService.erstelleMessage('info', 'Messgerät nicht gespeichert!');
    this.formModul.reset({
      id: '',
      inv_nr: '',
      bezeichnung: '',
      eigentuemer: '',
      barcode: '',
      baujahr: '',
      kalibrierung_intervall_tage: 365,
    });
    this.formModul.disable();
  }

  pruefungAbbrechen(): void {
    this.uiMessageService.erstelleMessage(
      'info',
      'Prüfung nicht gespeichert!'
    );
    this.formPruefung.reset({
      id: '',
      geraet_id: 0,
      datum: '',
      kalibrierung: false,
      kontrolle_woechentlich: false,
      wartung_jaehrlich: false,
      name_pruefer: '',
      notiz: '',
    });
    this.formPruefung.disable();
    this.title = this.title_modul;
    this.showPruefungForm = false;
    this.showPruefungTable = false;
  }

  datenLoeschen(): void {
    const id = this.formModul.controls['id'].value!;
    if (!id) {
      this.uiMessageService.erstelleMessage(
        'error',
        'Keine Maske ausgewählt zum Löschen!'
      );
      return;
    }

    this.apiHttpService.delete(this.modul, id).subscribe({
      next: () => {
        try {
          this.messgeraete = this.messgeraete.filter((m) => m.id !== id);
          this.dataSource.data = this.messgeraete;

          this.formModul.reset({
            id: '',
            inv_nr: '',
            bezeichnung: '',
            eigentuemer: '',
            barcode: '',
            baujahr: '',
            kalibrierung_intervall_tage: 365,
          });
          this.formModul.disable();

          this.uiMessageService.erstelleMessage(
            'success',
            'Messgerät erfolgreich gelöscht!'
          );
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => {
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  datenProtokollLoeschen(): void {
    if (this.rolesResolved && !this.canEditProtocol) {
      this.uiMessageService.erstelleMessage('error', 'Nur ADMIN/PROTOKOLL dürfen Protokolle löschen.');
      return;
    }

    const id = this.formPruefung.controls['id'].value!;
    if (!id) {
      this.uiMessageService.erstelleMessage(
        'error',
        'Kein Protokoll ausgewählt zum Löschen!'
      );
      return;
    }

    this.apiHttpService.delete(`${this.modul}/protokoll`, id).subscribe({
      next: () => {
        try {
          this.pruefungen = this.pruefungen.filter((m) => m.id !== id);
          this.dataSourcePruefungen.data = this.pruefungen;
          this.reloadMessgeraeteKontext();

          this.formPruefung.reset({
            id: '',
            geraet_id: 0,
            datum: '',
            kalibrierung: false,
            kontrolle_woechentlich: false,
            wartung_jaehrlich: false,
            name_pruefer: '',
            notiz: '',
          });
          this.formPruefung.disable();
          this.showPruefungForm = false;
          this.showPruefungTable = true;
          this.uiMessageService.erstelleMessage(
            'success',
            'Protokoll erfolgreich gelöscht!'
          );
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => {
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  validDateDDMMYYYY(): ValidatorFn {
    return (control: AbstractControl) => {
      const v: string = control.value;
      if (!v || !/^([0-3]\d)\.([0-1]\d)\.(\d{4})$/.test(v)) {
        return null;
      }
      const [t, m, j] = v.split('.').map((x) => +x);
      const d = new Date(j, m - 1, t);
      return d.getFullYear() === j &&
        d.getMonth() === m - 1 &&
        d.getDate() === t
        ? null
        : { dateInvalid: true };
    };
  }

  jahrAusDatum(value?: string | null): string {
    const input = String(value ?? '').trim();
    if (!input) {
      return '-';
    }

    const isoMatch = /^(\d{4})-\d{2}-\d{2}$/.exec(input);
    if (isoMatch) {
      return isoMatch[1];
    }

    if (/^\d{4}$/.test(input)) {
      return input;
    }

    const parts = input.split('.');
    const yearPart = parts[parts.length - 1]?.trim();
    return /^\d{4}$/.test(yearPart) ? yearPart : input;
  }

  kwJahrAusDatum(value?: string | null): string {
    const input = String(value ?? '').trim();
    if (!input) {
      return '-';
    }

    const kwPattern = /^(?:KW\s*)?(\d{1,2})\s*[/.-]\s*(\d{4})$/i.exec(input);
    if (kwPattern) {
      return `${kwPattern[1].padStart(2, '0')}/${kwPattern[2]}`;
    }

    const isoMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(input);
    if (isoMatch) {
      const year = Number(isoMatch[1]);
      const month = Number(isoMatch[2]);
      const day = Number(isoMatch[3]);
      const date = new Date(year, month - 1, day);
      return this.isoWeekFromDate(date);
    }

    const deMatch = /^(\d{2})\.(\d{2})\.(\d{4})$/.exec(input);
    if (deMatch) {
      const day = Number(deMatch[1]);
      const month = Number(deMatch[2]);
      const year = Number(deMatch[3]);
      const date = new Date(year, month - 1, day);
      return this.isoWeekFromDate(date);
    }

    return input;
  }

  private isoWeekFromDate(date: Date): string {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
    return `${String(weekNo).padStart(2, '0')}/${d.getUTCFullYear()}`;
  }

  sichtbarkeitModul(): string {
    let modulSichtbar = "";

    if (!this.formModul.disabled) {
      modulSichtbar = "formModul";
    } else if (this.formModul.disabled && !this.showPruefungTable && !this.showPruefungForm) {
      modulSichtbar = "tableListe";
    } else if (this.showPruefungForm) {
      modulSichtbar = "formPruefung";
    } else if (this.showPruefungTable) {
      modulSichtbar = "tablePruefungen";
    }

    return modulSichtbar;
  }

  private loadCurrentUserRoles(): void {
    this.apiHttpService.get<AtemschutzRolesResponse>('users/self').subscribe({
      next: (erg: AtemschutzRolesResponse) => {
        const roles = this.extractRolesFromResponse(erg);
        if (roles.length > 0) {
          this.applyRoleState(roles);
          return;
        }
        this.loadRolesFromModulKonfiguration();
      },
      error: () => this.loadRolesFromModulKonfiguration()
    });
  }

  private loadRolesFromModulKonfiguration(): void {
    this.apiHttpService.get<AtemschutzRolesResponse>('modul_konfiguration').subscribe({
      next: (erg: AtemschutzRolesResponse) => this.applyRoleState(this.extractRolesFromResponse(erg)),
      error: () => this.applyRoleState([])
    });
  }

  private extractRolesFromResponse(value: AtemschutzRolesResponse): string[] {
    return this.normalizeRoles(value?.roles ?? value?.user?.roles ?? value?.main?.user?.roles);
  }

  private applyRoleState(roles: string[]): void {
    this.userRoles = roles;
    this.canEditProtocol = this.userRoles.includes('ADMIN') || this.userRoles.includes('PROTOKOLL');
    this.canCreateProtocol = this.canEditProtocol || this.userRoles.includes('ATEMSCHUTZ');
    this.rolesResolved = true;

    if (this.showPruefungForm) {
      if (this.canEditProtocol) {
        this.formPruefung.enable();
      } else if (this.getCurrentProtocolId()) {
        this.applyNoteOnlyMode();
      } else {
        this.formPruefung.enable();
      }
    }
  }

  private getCurrentProtocolId(): string {
    return String(this.formPruefung.controls['id'].value ?? '').trim();
  }

  private normalizeRoles(value: unknown): string[] {
    if (Array.isArray(value)) {
      return value
        .flatMap((entry: unknown) =>
          String((typeof entry === 'object' && entry !== null ? (entry as Record<string, unknown>).key ?? (entry as Record<string, unknown>).role ?? (entry as Record<string, unknown>).name : entry) ?? '')
            .split(',')
            .map((part: string) => part.trim().toUpperCase())
        )
        .filter(Boolean);
    }

    return String(value ?? '')
      .split(',')
      .map((entry) => entry.trim().toUpperCase())
      .filter(Boolean);
  }

  private applyNoteOnlyMode(): void {
    Object.values(this.formPruefung.controls).forEach((control) => {
      control.disable();
    });
    this.formPruefung.controls['notiz'].enable();
  }
}
