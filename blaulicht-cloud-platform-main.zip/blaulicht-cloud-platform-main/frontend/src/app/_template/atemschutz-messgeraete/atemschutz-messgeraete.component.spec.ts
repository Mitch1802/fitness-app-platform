﻿import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AtemschutzMessgeraeteComponent } from './atemschutz-messgeraete.component';
import { IMessgeraet } from 'src/app/_interface/messgeraet';

describe('AtemschutzMessgeraeteComponent', () => {
  let component: AtemschutzMessgeraeteComponent;
  let fixture: ComponentFixture<AtemschutzMessgeraeteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AtemschutzMessgeraeteComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AtemschutzMessgeraeteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should reset protocol id when starting a new protocol entry', () => {
    component.formPruefung.setValue({
      id: 'existing-id',
      geraet_id: 123,
      datum: '01.01.2026',
      kalibrierung: true,
      kontrolle_woechentlich: true,
      wartung_jaehrlich: true,
      name_pruefer: 'Tester',
      notiz: 'Altwert',
    });

    component.neuePruefung();

    expect(component.formPruefung.controls['id'].value).toBe('');
    expect(component.formPruefung.controls['geraet_id'].value).toBe(0);
    expect(component.showPruefungForm).toBeTrue();
  });

  it('should clear stale id and set selected geraet in row action', () => {
    component.formPruefung.setValue({
      id: 'old-id',
      geraet_id: 0,
      datum: '',
      kalibrierung: false,
      kontrolle_woechentlich: false,
      wartung_jaehrlich: false,
      name_pruefer: '',
      notiz: '',
    });

    const geraet = { pkid: 77 } as IMessgeraet;

    component.neuePruefungVonMessgeraet(geraet);

    expect(component.formPruefung.controls['id'].value).toBe('');
    expect(component.formPruefung.controls['geraet_id'].value).toBe(77);
    expect(component.formPruefung.controls['geraet_id'].disabled).toBeTrue();
  });
});

