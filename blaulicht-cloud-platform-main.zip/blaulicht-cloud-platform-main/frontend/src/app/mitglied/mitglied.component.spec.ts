﻿import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';

import { ApiHttpService } from 'src/app/_service/api-http.service';
import { AuthSessionService } from 'src/app/_service/auth-session.service';
import { CollectionUtilsService } from 'src/app/_service/collection-utils.service';
import { NavigationService } from 'src/app/_service/navigation.service';
import { UiMessageService } from 'src/app/_service/ui-message.service';
import { IMitglied } from 'src/app/_interface/mitglied';

import { MitgliedComponent } from './mitglied.component';

describe('MitgliedComponent', () => {
  let component: MitgliedComponent;
  let fixture: ComponentFixture<MitgliedComponent>;
  let apiHttpServiceSpy: jasmine.SpyObj<ApiHttpService>;
  let authSessionServiceSpy: jasmine.SpyObj<AuthSessionService>;
  let collectionUtilsServiceSpy: jasmine.SpyObj<CollectionUtilsService>;
  let navigationServiceSpy: jasmine.SpyObj<NavigationService>;
  let uiMessageServiceSpy: jasmine.SpyObj<UiMessageService>;

  beforeEach(async () => {
    apiHttpServiceSpy = jasmine.createSpyObj<ApiHttpService>('ApiHttpService', ['get', 'post', 'patch', 'delete']);
    authSessionServiceSpy = jasmine.createSpyObj<AuthSessionService>('AuthSessionService', ['errorAnzeigen']);
    collectionUtilsServiceSpy = jasmine.createSpyObj<CollectionUtilsService>('CollectionUtilsService', ['arraySortByKey']);
    navigationServiceSpy = jasmine.createSpyObj<NavigationService>('NavigationService', ['ladeBreadcrumb']);
    uiMessageServiceSpy = jasmine.createSpyObj<UiMessageService>('UiMessageService', ['erstelleMessage']);

    navigationServiceSpy.ladeBreadcrumb.and.returnValue([]);
    collectionUtilsServiceSpy.arraySortByKey.and.callFake(<T>(array: T[]) => array);
    apiHttpServiceSpy.get.and.returnValue(of([]));

    await TestBed.configureTestingModule({
      imports: [MitgliedComponent],
      providers: [
        provideRouter([]),
        { provide: ApiHttpService, useValue: apiHttpServiceSpy },
        { provide: AuthSessionService, useValue: authSessionServiceSpy },
        { provide: CollectionUtilsService, useValue: collectionUtilsServiceSpy },
        { provide: NavigationService, useValue: navigationServiceSpy },
        { provide: UiMessageService, useValue: uiMessageServiceSpy },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(MitgliedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should keep reserve and abgemeldet members visible by default', () => {
    const members: IMitglied[] = [
      { id: '1', pkid: 1, stbnr: 1, vorname: 'Aktiv', nachname: 'Mitglied', dienstgrad: '', svnr: '', geburtsdatum: '1990-01-01', hauptberuflich: false, dienststatus: 'AKTIV' },
      { id: '2', pkid: 2, stbnr: 2, vorname: 'Reserve', nachname: 'Mitglied', dienstgrad: '', svnr: '', geburtsdatum: '1990-01-01', hauptberuflich: false, dienststatus: 'RESERVE' },
      { id: '3', pkid: 3, stbnr: 3, vorname: 'Ab', nachname: 'Gemeldet', dienstgrad: '', svnr: '', geburtsdatum: '1990-01-01', hauptberuflich: false, dienststatus: 'ABGEMELDET' }
    ];

    component.dataSource.data = members;
    component.applyFilter('');

    expect(component.dataSource.filteredData.map((member) => member.stbnr)).toEqual([1, 2, 3]);
  });

  it('should filter members by selected statuses', () => {
    const members: IMitglied[] = [
      { id: '1', pkid: 1, stbnr: 1, vorname: 'Aktiv', nachname: 'Mitglied', dienstgrad: '', svnr: '', geburtsdatum: '1990-01-01', hauptberuflich: false, dienststatus: 'AKTIV' },
      { id: '2', pkid: 2, stbnr: 2, vorname: 'Reserve', nachname: 'Mitglied', dienstgrad: '', svnr: '', geburtsdatum: '1990-01-01', hauptberuflich: false, dienststatus: 'RESERVE' },
      { id: '3', pkid: 3, stbnr: 3, vorname: 'Ab', nachname: 'Gemeldet', dienstgrad: '', svnr: '', geburtsdatum: '1990-01-01', hauptberuflich: false, dienststatus: 'ABGEMELDET' }
    ];

    component.dataSource.data = members;

    component.updateStatusFilter('AKTIV', false);
    component.updateStatusFilter('ABGEMELDET', false);

    expect(component.dataSource.filteredData.map((member) => member.stbnr)).toEqual([2]);
  });
});
