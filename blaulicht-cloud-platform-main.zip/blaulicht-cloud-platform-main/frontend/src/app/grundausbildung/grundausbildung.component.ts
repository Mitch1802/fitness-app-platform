import { CommonModule } from '@angular/common';
import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatAutocompleteModule, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxChange, MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { forkJoin } from 'rxjs';
import { IGrundausbildung, IGrundausbildungContext } from '../_interface/grundausbildung';
import { ApiHttpService } from '../_service/api-http.service';
import { AuthSessionService } from '../_service/auth-session.service';
import { NavigationService } from '../_service/navigation.service';
import { UiMessageService } from '../_service/ui-message.service';
import { TABLE_PAGINATION_DEFAULT_PAGE_SIZE, TABLE_PAGINATION_PAGE_SIZE_OPTIONS } from '../_utils/table-pagination-options';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../imr-ui-library';

@Component({
  selector: 'app-grundausbildung',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatAutocompleteModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatTableModule,
  ],
  templateUrl: './grundausbildung.component.html',
  styleUrl: './grundausbildung.component.sass',
})
export class GrundausbildungComponent implements OnInit {
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);

  title = 'Grundausbildung';
  breadcrumb: ImrBreadcrumbItem[] = [];
  suchtext = '';
  mitgliedAutoValue: string | number | null = '';
  selectedMitgliedPkid: number | null = null;
  mitgliedErgaenzenOpen = false;

  eintraege: IGrundausbildung[] = [];
  verfuegbareMitglieder: IGrundausbildungContext['mitglieder'] = [];

  dataSource = new MatTableDataSource<IGrundausbildung>([]);
  sichtbareSpalten: string[] = [
    'stbnr',
    'name',
    'dienstgrad',
    'station_basisausbildung',
    'station_atemschutz',
    'station_grundlagen_fuehren',
    'actions',
  ];

  readonly pageSizeOptions = TABLE_PAGINATION_PAGE_SIZE_OPTIONS.standard;
  readonly pageSize = TABLE_PAGINATION_DEFAULT_PAGE_SIZE.standard;

  @ViewChild(MatPaginator) set matPaginator(p: MatPaginator | undefined) {
    if (p) {
      this.dataSource.paginator = p;
    }
  }

  ngOnInit(): void {
    sessionStorage.setItem('PageNumber', '2');
    sessionStorage.setItem('Page2', 'GRUNDAUSB');

    this.breadcrumb = this.navigationService.ladeBreadcrumb();
    this.dataSource.filterPredicate = (row: IGrundausbildung, filter: string) => {
      const text = `${row.stbnr} ${row.vorname} ${row.nachname} ${row.dienstgrad || ''}`.toLowerCase();
      return text.includes(filter);
    };

    this.loadData();
  }

  getName(row: IGrundausbildung): string {
    return `${row.vorname} ${row.nachname}`;
  }

  getDienstgrad(row: IGrundausbildung): string {
    const value = String(row.dienstgrad || '').trim();
    return value === '' ? '-' : value;
  }

  onFilterChange(): void {
    this.dataSource.filter = String(this.suchtext || '').trim().toLowerCase();
  }

  mitgliedErgaenzenStarten(): void {
    this.mitgliedErgaenzenOpen = true;
    this.mitgliedAutoValue = '';
    this.selectedMitgliedPkid = null;
  }

  mitgliedErgaenzenAbbrechen(): void {
    this.mitgliedErgaenzenOpen = false;
    this.mitgliedAutoValue = '';
    this.selectedMitgliedPkid = null;
  }

  get gefilterteMitglieder(): IGrundausbildungContext['mitglieder'] {
    const query = this.getMitgliedQuery();
    if (!query) {
      return this.verfuegbareMitglieder;
    }

    return this.verfuegbareMitglieder.filter((mitglied) =>
      this.getMitgliedOptionLabel(mitglied).toLowerCase().includes(query)
    );
  }

  onMitgliedAutoValueChange(value: string | number | null): void {
    if (typeof value !== 'number') {
      this.selectedMitgliedPkid = null;
    }
  }

  onMitgliedAutocompleteSelect(event: MatAutocompleteSelectedEvent): void {
    const pkid = Number(event.option.value);
    if (!Number.isFinite(pkid)) {
      this.selectedMitgliedPkid = null;
      return;
    }

    this.selectedMitgliedPkid = pkid;
    this.mitgliedAutoValue = pkid;
  }

  onMitgliedAutocompleteEnter(event: Event): void {
    event.preventDefault();

    if (this.selectedMitgliedPkid) {
      return;
    }

    const ersterTreffer = this.gefilterteMitglieder[0];
    if (!ersterTreffer) {
      return;
    }

    this.selectedMitgliedPkid = ersterTreffer.pkid;
    this.mitgliedAutoValue = ersterTreffer.pkid;
  }

  displayMitgliedOption = (value: string | number | null): string => {
    if (typeof value === 'number') {
      const mitglied = this.verfuegbareMitglieder.find((entry) => entry.pkid === value);
      return mitglied ? this.getMitgliedOptionLabel(mitglied) : '';
    }
    return typeof value === 'string' ? value : '';
  };

  stationToggle(row: IGrundausbildung, field: 'station_basisausbildung' | 'station_atemschutz' | 'station_grundlagen_fuehren', event: MatCheckboxChange): void {
    const previous = row[field];
    row[field] = event.checked;

    this.apiHttpService.patch<IGrundausbildung>('grundausbildung', row.id, { [field]: event.checked }, false).subscribe({
      next: (updated) => {
        row.station_basisausbildung = updated.station_basisausbildung;
        row.station_atemschutz = updated.station_atemschutz;
        row.station_grundlagen_fuehren = updated.station_grundlagen_fuehren;
        this.uiMessageService.erstelleMessage('success', 'Ausbildungsstand aktualisiert.');
      },
      error: (error) => {
        row[field] = previous;
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  mitgliedHinzufuegen(): void {
    if (!this.selectedMitgliedPkid) {
      this.uiMessageService.erstelleMessage('info', 'Bitte zuerst ein Mitglied auswählen.');
      return;
    }

    this.apiHttpService.post<IGrundausbildung>('grundausbildung/add-mitglied', { mitglied: this.selectedMitgliedPkid }, false).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Mitglied zur Grundausbildung hinzugefügt.');
        this.mitgliedErgaenzenAbbrechen();
        this.loadData();
      },
      error: (error) => this.authSessionService.errorAnzeigen(error),
    });
  }

  mitgliedEntfernen(row: IGrundausbildung): void {
    const confirmDelete = window.confirm(`Mitglied ${this.getName(row)} aus der Grundausbildung entfernen?`);
    if (!confirmDelete) {
      return;
    }

    this.apiHttpService.post('grundausbildung/remove-mitglied', { mitglied: row.mitglied_pkid }, false).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Mitglied aus der Grundausbildung entfernt.');
        this.loadData();
      },
      error: (error) => this.authSessionService.errorAnzeigen(error),
    });
  }

  private loadData(): void {
    forkJoin({
      main: this.apiHttpService.get<IGrundausbildung[]>('grundausbildung'),
      context: this.apiHttpService.get<IGrundausbildungContext>('grundausbildung/context'),
    }).subscribe({
      next: ({ main, context }) => {
        this.eintraege = Array.isArray(main) ? main : [];
        this.verfuegbareMitglieder = Array.isArray(context?.mitglieder) ? context.mitglieder : [];
        this.dataSource.data = this.eintraege;
        this.onFilterChange();
      },
      error: (error) => this.authSessionService.errorAnzeigen(error),
    });
  }

  private getMitgliedQuery(): string {
    if (typeof this.mitgliedAutoValue === 'string') {
      return this.mitgliedAutoValue.trim().toLowerCase();
    }

    if (typeof this.mitgliedAutoValue === 'number') {
      const mitglied = this.verfuegbareMitglieder.find((entry) => entry.pkid === this.mitgliedAutoValue);
      return mitglied ? this.getMitgliedOptionLabel(mitglied).toLowerCase() : '';
    }

    return '';
  }

  getMitgliedOptionLabel(mitglied: IGrundausbildungContext['mitglieder'][number]): string {
    const dienstgrad = String(mitglied.dienstgrad || '').trim();
    const dienstgradTeil = dienstgrad ? ` (${dienstgrad})` : '';
    return `${mitglied.stbnr} - ${mitglied.vorname} ${mitglied.nachname}${dienstgradTeil}`;
  }
}
