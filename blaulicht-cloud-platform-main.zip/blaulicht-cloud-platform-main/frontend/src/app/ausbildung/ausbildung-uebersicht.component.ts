import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';

import { IAusbildungThemenbereich } from '../_interface/ausbildung';
import { ApiHttpService } from '../_service/api-http.service';
import { AuthSessionService } from '../_service/auth-session.service';
import { NavigationService } from '../_service/navigation.service';
import { UiMessageService } from '../_service/ui-message.service';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../imr-ui-library';

@Component({
  selector: 'app-ausbildung-uebersicht',
  standalone: true,
  imports: [
    CommonModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
  ],
  templateUrl: './ausbildung-uebersicht.component.html',
  styleUrl: './ausbildung-uebersicht.component.sass',
})
export class AusbildungUebersichtComponent implements OnInit {
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  private router = inject(Router);

  title = 'Ausbildung';
  breadcrumb: ImrBreadcrumbItem[] = [];
  themenbereiche: IAusbildungThemenbereich[] = [];
  loading = true;

  ngOnInit(): void {
    sessionStorage.setItem('PageNumber', '2');
    sessionStorage.setItem('Page2', 'AUSBILDUNG');
    this.breadcrumb = this.navigationService.ladeBreadcrumb();
    this.loadData();
  }

  private loadData(): void {
    this.loading = true;
    this.apiHttpService.get<IAusbildungThemenbereich[]>('ausbildung').subscribe({
      next: (data) => {
        this.themenbereiche = data ?? [];
        this.loading = false;
      },
      error: (error: unknown) => {
        this.loading = false;
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  openThemenbereich(tb: IAusbildungThemenbereich): void {
    this.navigationService.setzeNeueBreadcrumbDaten('AUSBILDUNG_TB', 2);
    this.router.navigate(['/ausbildung', tb.id]);
  }

  neuerThemenbereich(): void {
    this.navigationService.setzeNeueBreadcrumbDaten('AUSBILDUNG_TB', 2);
    this.router.navigate(['/ausbildung', 'neu']);
  }
}
