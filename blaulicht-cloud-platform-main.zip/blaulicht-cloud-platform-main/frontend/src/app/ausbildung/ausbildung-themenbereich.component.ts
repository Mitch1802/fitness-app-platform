import { CommonModule } from '@angular/common';
import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { HttpClient } from '@angular/common/http';

import { IAusbildungDatei, IAusbildungThemenbereich } from '../_interface/ausbildung';
import { ApiHttpService } from '../_service/api-http.service';
import { AuthSessionService } from '../_service/auth-session.service';
import { NavigationService } from '../_service/navigation.service';
import { UiMessageService } from '../_service/ui-message.service';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../imr-ui-library';
import { ImrUploadFieldComponent } from '../imr-ui-library/imr-upload-field/imr-upload-field.component';

@Component({
  selector: 'app-ausbildung-themenbereich',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    ImrUploadFieldComponent,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatProgressBarModule,
    MatTooltipModule,
  ],
  templateUrl: './ausbildung-themenbereich.component.html',
  styleUrl: './ausbildung-themenbereich.component.sass',
})
export class AusbildungThemenbereichComponent implements OnInit {
  @ViewChild('dateiUpload') dateiUploadRef?: ImrUploadFieldComponent;

  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private http = inject(HttpClient);

  breadcrumb: ImrBreadcrumbItem[] = [];
  loading = false;
  uploading = false;
  themenbereichId: string | null = null;
  isNeu = false;

  dateien: IAusbildungDatei[] = [];
  ausgewaehlteFiles: File[] = [];

  form = new FormGroup({
    titel: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    beschreibung: new FormControl('', { nonNullable: true }),
  });

  get titel(): string {
    if (this.isNeu) return 'Neuer Themenbereich';
    return this.form.value.titel || 'Themenbereich';
  }

  ngOnInit(): void {
    sessionStorage.setItem('PageNumber', '3');
    sessionStorage.setItem('Page3', 'AUSBILDUNG_TB');
    this.breadcrumb = this.navigationService.ladeBreadcrumb();

    const id = this.route.snapshot.paramMap.get('id');
    if (id === 'neu') {
      this.isNeu = true;
    } else {
      this.themenbereichId = id;
      this.loadData();
    }
  }

  private loadData(): void {
    if (!this.themenbereichId) return;
    this.loading = true;
    this.apiHttpService.get<IAusbildungThemenbereich>(`ausbildung/${this.themenbereichId}`).subscribe({
      next: (data) => {
        this.form.patchValue({ titel: data.titel, beschreibung: data.beschreibung ?? '' });
        this.dateien = data.dateien ?? [];
        this.loading = false;
      },
      error: (error: unknown) => {
        this.loading = false;
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  speichern(): void {
    if (this.form.invalid) return;
    const payload = { titel: this.form.value.titel, beschreibung: this.form.value.beschreibung ?? '' };

    if (this.isNeu) {
      this.apiHttpService.post<IAusbildungThemenbereich>('ausbildung', payload).subscribe({
        next: (created) => {
          this.uiMessageService.erstelleMessage('success', 'Themenbereich gespeichert.');
          this.isNeu = false;
          this.themenbereichId = created.id ?? null;
          this.dateien = created.dateien ?? [];
          // update URL without re-navigating
          this.router.navigate(['/ausbildung', this.themenbereichId], { replaceUrl: true });
        },
        error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
      });
    } else {
      this.apiHttpService.patch<IAusbildungThemenbereich>('ausbildung', this.themenbereichId!, payload).subscribe({
        next: (updated) => {
          this.uiMessageService.erstelleMessage('success', 'Gespeichert.');
          this.dateien = updated.dateien ?? [];
        },
        error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
      });
    }
  }

  loeschen(): void {
    if (!this.themenbereichId) return;
    if (!window.confirm(`Themenbereich "${this.form.value.titel}" wirklich löschen?`)) return;
    this.apiHttpService.delete('ausbildung', this.themenbereichId).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Themenbereich gelöscht.');
        this.router.navigate(['/ausbildung']);
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  abbrechen(): void {
    this.router.navigate(['/ausbildung']);
  }

  onDateienSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.ausgewaehlteFiles = input.files ? Array.from(input.files) : [];
  }

  dateienHochladen(): void {
    if (!this.themenbereichId || this.ausgewaehlteFiles.length === 0) return;
    const fd = new FormData();
    for (const f of this.ausgewaehlteFiles) {
      fd.append('dateien_upload', f, f.name);
    }
    this.uploading = true;
    this.apiHttpService.post<IAusbildungDatei[]>(`ausbildung/${this.themenbereichId}/dateien`, fd).subscribe({
      next: (neu) => {
        this.dateien = [...this.dateien, ...neu];
        this.ausgewaehlteFiles = [];
        this.dateiUploadRef?.clear();
        this.uploading = false;
        this.uiMessageService.erstelleMessage('success', 'Datei(en) hochgeladen.');
      },
      error: (error: unknown) => {
        this.uploading = false;
        this.authSessionService.errorAnzeigen(error);
      },
    });
  }

  dateiLoeschen(datei: IAusbildungDatei): void {
    if (!this.themenbereichId || !datei.id) return;
    if (!window.confirm(`Datei "${datei.dateiname}" wirklich löschen?`)) return;
    this.apiHttpService.delete(`ausbildung/${this.themenbereichId}/dateien`, datei.id).subscribe({
      next: () => {
        this.dateien = this.dateien.filter((d) => d.id !== datei.id);
        this.uiMessageService.erstelleMessage('success', 'Datei gelöscht.');
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  dateiHerunterladen(datei: IAusbildungDatei): void {
    if (!datei.datei_url) return;
    // Use HttpClient so the auth interceptor adds credentials automatically
    this.http.get(datei.datei_url, { responseType: 'blob' }).subscribe({
      next: (blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = datei.dateiname;
        a.click();
        URL.revokeObjectURL(url);
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  getSelectedFileNames(): string {
    return this.ausgewaehlteFiles.map((f) => f.name).join(', ');
  }
}
