﻿import { Routes } from '@angular/router';
import { authGuard } from './_guards/auth.guard';
import { guestGuard } from './_guards/guest.guard';

export const routes: Routes = [
  {
    path: '', redirectTo: 'login', pathMatch: 'full'
  },
  {
    path: 'login',
    canActivate: [guestGuard],
    loadComponent: () => import("./login/login.component").then(m => m.LoginComponent),
  },
  {
    path: 'einladung',
    canActivate: [guestGuard],
    loadComponent: () => import("./invite/invite.component").then(m => m.InviteComponent),
  },
  {
    path: 'start',
    canActivate: [authGuard],
    loadComponent: () => import("./start/start.component").then(m => m.StartComponent),
  },
  {
    path: 'fmd',
    canActivate: [authGuard],
    loadComponent: () => import("./fmd/fmd.component").then(m => m.FmdComponent),
  },
  {
    path: 'mitglied',
    canActivate: [authGuard],
    loadComponent: () => import("./mitglied/mitglied.component").then(m => m.MitgliedComponent),
  },
  {
    path: 'jugend',
    canActivate: [authGuard],
    loadComponent: () => import("./jugend/jugend.component").then(m => m.JugendComponent),
  },
  {
    path: 'grundausbildung',
    canActivate: [authGuard],
    loadComponent: () => import("./grundausbildung/grundausbildung.component").then(m => m.GrundausbildungComponent),
  },
  {
    path: 'atemschutz',
    canActivate: [authGuard],
    loadComponent: () => import("./atemschutz/atemschutz.component").then(m => m.AtemschutzComponent),
  },
  {
    path: 'atemschutz/masken',
    canActivate: [authGuard],
    loadComponent: () => import("./_template/atemschutz-masken/atemschutz-masken.component").then(m => m.AtemschutzMaskenComponent),
  },
  {
    path: 'atemschutz/geraete',
    canActivate: [authGuard],
    loadComponent: () => import("./_template/atemschutz-geraete/atemschutz-geraete.component").then(m => m.AtemschutzGeraeteComponent),
  },
  {
    path: 'atemschutz/messgeraete',
    canActivate: [authGuard],
    loadComponent: () => import("./_template/atemschutz-messgeraete/atemschutz-messgeraete.component").then(m => m.AtemschutzMessgeraeteComponent),
  },
  {
    path: 'atemschutz/dienstbuch',
    canActivate: [authGuard],
    loadComponent: () => import("./_template/atemschutz-dienstbuch/atemschutz-dienstbuch.component").then(m => m.AtemschutzDienstbuchComponent),
  },
  {
    path: 'news',
    canActivate: [authGuard],
    loadComponent: () => import("./news/news.component").then(m => m.NewsComponent),
  },
  {
    path: 'homepage',
    canActivate: [authGuard],
    loadComponent: () => import("./homepage/homepage.component").then(m => m.HomepageComponent),
  },
  {
    path: 'newsfeed',
    loadComponent: () => import("./news-extern/news-extern.component").then(m => m.NewsExternComponent),
  },
  {
    path: 'inventar',
    canActivate: [authGuard],
    loadComponent: () => import("./inventar/inventar.component").then(m => m.InventarComponent),
  },
  {
    path: 'wartung-service',
    canActivate: [authGuard],
    loadComponent: () => import("./wartung-service/wartung-service.component").then(m => m.WartungServiceComponent),
  },
  {
    path: 'einsatzbericht',
    canActivate: [authGuard],
    loadComponent: () => import("./einsatzbericht/einsatzbericht.component").then(m => m.EinsatzberichtComponent),
  },
  {
    path: 'anwesenheitsliste',
    canActivate: [authGuard],
    loadComponent: () => import("./anwesenheitsliste/anwesenheitsliste.component").then(m => m.AnwesenheitslisteComponent),
  },
  {
    path: 'aufgaben',
    canActivate: [authGuard],
    loadComponent: () => import("./aufgaben/aufgaben.component").then(m => m.AufgabenComponent),
  },
  {
    path: 'ausbildung',
    canActivate: [authGuard],
    loadComponent: () => import("./ausbildung/ausbildung-uebersicht.component").then(m => m.AusbildungUebersichtComponent),
  },
  {
    path: 'ausbildung/:id',
    canActivate: [authGuard],
    loadComponent: () => import("./ausbildung/ausbildung-themenbereich.component").then(m => m.AusbildungThemenbereichComponent),
  },
  {
    path: "fahrzeug-check",
    canActivate: [authGuard],
    loadComponent: () => import("./fahrzeug-check/fahrzeug-check-uebersicht.component").then(m => m.FahrzeugCheckUebersichtComponent),
  },
  {
    path: "fahrzeuge",
    canActivate: [authGuard],
    loadComponent: () => import("./fahrzeug/fahrzeug.component").then(m => m.FahrzeugComponent),
  },
  {
    path: "fahrzeug-inventar",
    canActivate: [authGuard],
    loadComponent: () => import("./fahrzeuginventar/fahrzeuginventar.component").then(m => m.FahrzeuginventarComponent),
  },
  {
    path: "fahrzeuge/:id/check",
    canActivate: [authGuard],
    loadComponent: () => import("./fahrzeug-check/fahrzeug-check.component").then(m => m.FahrzeugCheckComponent),
  },
  {
    path: "fahrzeuge/:id/check/history",
    canActivate: [authGuard],
    loadComponent: () => import("./fahrzeug-check/fahrzeug-check-history.component").then(m => m.FahrzeugCheckHistoryComponent),
  },
  {
    path: "public/fahrzeuge",
    loadComponent: () => import("./fahrzeug/public-fahrzeug.component").then(m => m.PublicFahrzeugComponent),
  },
  {
    path: "public/fahrzeuge/:publicId",
    loadComponent: () => import("./fahrzeug/public-fahrzeug.component").then(m => m.PublicFahrzeugComponent),
  },
  {
    path: 'verwaltung',
    canActivate: [authGuard],
    loadComponent: () => import("./verwaltung/verwaltung.component").then(m => m.VerwaltungComponent),
  },
  {
    path: 'export',
    canActivate: [authGuard],
    loadComponent: () => import("./export/export.component").then(m => m.ExportComponent),
  },
  {
    path: 'pdf_template',
    canActivate: [authGuard],
    loadComponent: () => import("./pdf-templates/pdf-templates.component").then(m => m.PdfTemplatesComponent),
  },
  {
    path: 'benutzer',
    canActivate: [authGuard],
    loadComponent: () => import("./user/user.component").then(m => m.UserComponent),
  },
  {
    path: 'konfiguration',
    canActivate: [authGuard],
    loadComponent: () => import("./konfiguration/konfiguration.component").then(m => m.KonfigurationComponent),
  },
  {
    path: 'eigene_daten',
    canActivate: [authGuard],
    loadComponent: () => import("./eigene-daten/eigene-daten.component").then(m => m.EigeneDatenComponent),
  },
  {
    path: 'fotoupload',
    canActivate: [authGuard],
    loadComponent: () => import("./fotoupload/fotoupload.component").then(m => m.FotouploadComponent),
  },
  {
    path: 'public/fotoupload',
    loadComponent: () => import("./fotoupload-extern/fotoupload-extern.component").then(m => m.FotouploadExternComponent),
  },
  {
    path: '**', redirectTo: 'login'
  }
];
