﻿import { Injectable } from '@angular/core';
import { formatDateOutput } from '../_utils/date-normalization.util';

@Injectable({
  providedIn: 'root'
})
export class FormatService {
  formatBetrag(betrag: number): string {
    return new Intl.NumberFormat('de-DE', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(betrag);
  }

  formatDatum(dateString: string): string {
    return formatDateOutput(dateString);
  }
}
