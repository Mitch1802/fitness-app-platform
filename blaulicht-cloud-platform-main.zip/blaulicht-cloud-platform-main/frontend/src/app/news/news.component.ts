﻿import { Component, OnInit, inject, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { INews } from 'src/app/_interface/news';
import { INewsTemplate } from 'src/app/_interface/news-template';
import { ApiHttpService } from 'src/app/_service/api-http.service';
import { AuthSessionService } from 'src/app/_service/auth-session.service';
import { CollectionUtilsService } from 'src/app/_service/collection-utils.service';
import { NavigationService } from 'src/app/_service/navigation.service';
import { UiMessageService } from 'src/app/_service/ui-message.service';
import { A11yModule } from '@angular/cdk/a11y';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../imr-ui-library';
import { ImrUploadFieldComponent } from '../imr-ui-library/imr-upload-field/imr-upload-field.component';
import { forkJoin } from 'rxjs';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { DateInputMaskDirective } from '../_directive/date-input-mask.directive';
import { normalizeDateInput } from '../_utils/date-normalization.util';
import { TABLE_PAGINATION_DEFAULT_PAGE_SIZE, TABLE_PAGINATION_PAGE_SIZE_OPTIONS } from '../_utils/table-pagination-options';

@Component({
  selector: 'app-news',
  imports: [
    FormsModule,
    ReactiveFormsModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    ImrUploadFieldComponent,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    A11yModule,
    MatTableModule,
    MatSortModule,
    DateInputMaskDirective,
  ],
  templateUrl: './news.component.html',
  styleUrl: './news.component.sass'
})
export class NewsComponent implements OnInit {
  @ViewChild('fotoUpload', { static: false }) fotoRef?: ImrUploadFieldComponent;

  @ViewChild(MatPaginator) set matPaginator(p: MatPaginator | undefined) {
    if (p) {
      this.newsDataSource.paginator = p;
    }
  }

  @ViewChild(MatSort) set matSort(s: MatSort | undefined) {
    if (s) {
      this.newsDataSource.sortingDataAccessor = (item: INews, property: string): string | number => {
        if (property === 'created_at') {
          return this.toCreatedAtTimestamp(item.created_at);
        }

        return String((item as any)[property] || '').toLowerCase();
      };

      s.active = 'created_at';
      s.direction = 'desc';

      this.newsDataSource.sort = s;
    }
  }
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private collectionUtilsService = inject(CollectionUtilsService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);

  title = 'News Verwaltung';
  modul = 'news/intern';
  modulTemplates = 'news/templates';
  breadcrumb: ImrBreadcrumbItem[] = [];

  newsArray: INews[] = [];
  newsDataSource = new MatTableDataSource<INews>([]);
  readonly pageSizeOptions = TABLE_PAGINATION_PAGE_SIZE_OPTIONS.standard;
  readonly pageSize = TABLE_PAGINATION_DEFAULT_PAGE_SIZE.standard;
  sichtbareSpaltenNews: string[] = ['created_at', 'title', 'typ', 'actions'];
  templateArray: INewsTemplate[] = [];
  btnText = 'Bild auswählen';
  fileName = '';
  filePfad = '';
  fileFound = false;
  btnUploadStatus = false;
  imageModalOpen = false;
  isEditMode = false;
  private selectedPreviewUrl = '';
  private focusBeforePhotoModal: HTMLElement | null = null;

  get uploadLimitMb(): number {
    return Math.round((this.apiHttpService.MaxUploadSize / 1024) * 10) / 10;
  }

  private normalizeFilterValue(value: string): string {
    return String(value || '').trim().toLowerCase();
  }

  formAuswahl = new FormGroup({
    news: new FormControl<number | ''>('')
  });

  formModul = new FormGroup({
    id: new FormControl<string | ''>(''),
    template_id: new FormControl<string | ''>(''),
    template_name: new FormControl<string>('', { nonNullable: true }),
    title: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    text: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    typ: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    infoscreen_anzeige_ab: new FormControl<string>(''),
    infoscreen_anzeige_bis: new FormControl<string>(''),
    // nur für Anzeige/Modal – NICHT ans Backend senden
    foto_url: new FormControl<string>(''),
  });

  ngOnInit(): void {
    sessionStorage.setItem('PageNumber', '2');
    sessionStorage.setItem('Page2', 'NEWS');
    this.breadcrumb = this.navigationService.ladeBreadcrumb();

    this.formModul.disable();
    this.isEditMode = false;

    forkJoin({
      newsResponse: this.apiHttpService.get<INews[]>(this.modul),
      templateResponse: this.apiHttpService.get<INewsTemplate[]>(this.modulTemplates),
    }).subscribe({
      next: ({ newsResponse, templateResponse }) => {
        try {
          this.newsArray = this.convertNewsDate(
            this.sortNewsByCreatedDesc(newsResponse)
          );

          this.newsDataSource.data = this.newsArray;
          this.newsDataSource.paginator?.firstPage();
          this.templateArray = this.sortTemplates(templateResponse);

          console.table(
            this.newsArray.map(n => ({
              created_at: n.created_at,
              timestamp: this.toCreatedAtTimestamp(n.created_at)
            }))
          );
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => {
        this.authSessionService.errorAnzeigen(error);
      }
    });
  }

  private sortTemplates(data: INewsTemplate[] = []): INewsTemplate[] {
    return [...(data || [])].sort((a, b) =>
      String(a?.name || '').localeCompare(String(b?.name || ''), 'de')
    );
  }

  vorlageAnwenden(): void {
    const templateId = this.formModul.controls['template_id'].value;
    if (!templateId) {
      this.uiMessageService.erstelleMessage('info', 'Bitte zuerst eine Vorlage auswählen.');
      return;
    }

    const selected = this.templateArray.find((tpl) => String(tpl.id) === String(templateId));
    if (!selected) {
      this.uiMessageService.erstelleMessage('error', 'Vorlage konnte nicht geladen werden.');
      return;
    }

    this.formModul.patchValue({
      template_name: selected.name || '',
      title: selected.title || '',
      text: selected.text || '',
      typ: selected.typ || 'intern',
    });
    this.uiMessageService.erstelleMessage('success', 'Vorlage zum Bearbeiten geladen.');
  }

  vorlageLoeschen(): void {
    const templateId = this.formModul.controls['template_id'].value;
    if (!templateId) {
      this.uiMessageService.erstelleMessage('info', 'Bitte zuerst eine Vorlage auswählen.');
      return;
    }

    const selected = this.templateArray.find((tpl) => String(tpl.id) === String(templateId));
    const templateName = selected?.name || 'Vorlage';
    const confirmDelete = window.confirm(`Vorlage "${templateName}" wirklich löschen?`);
    if (!confirmDelete) {
      return;
    }

    this.apiHttpService.delete(this.modulTemplates, templateId).subscribe({
      next: () => {
        this.templateArray = this.templateArray.filter((tpl) => String(tpl.id) !== String(templateId));
        this.formModul.patchValue({ template_id: '', template_name: '' });
        this.uiMessageService.erstelleMessage('success', 'Vorlage gelöscht.');
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  vorlageSpeichern(): void {
    const templateId = this.formModul.controls['template_id'].value;
    const name = (this.formModul.controls['template_name'].value || '').trim();
    const title = this.formModul.controls['title'].value || '';
    const text = this.formModul.controls['text'].value || '';
    const typ = this.formModul.controls['typ'].value || 'intern';

    if (!name || !title || !text) {
      this.uiMessageService.erstelleMessage('error', 'Vorlagenname, Titel und Text sind erforderlich.');
      return;
    }

    const payload = {
      name,
      title,
      text,
      typ,
      active: true,
    };

    const request$ = templateId
      ? this.apiHttpService.patch<INewsTemplate>(this.modulTemplates, templateId, payload, false)
      : this.apiHttpService.post<INewsTemplate>(this.modulTemplates, payload, false);

    request$.subscribe({
      next: (erg) => {
        const savedId = String(erg?.id || templateId || '');
        this.apiHttpService.get<INewsTemplate[]>(this.modulTemplates).subscribe({
          next: (templates) => {
            this.templateArray = this.sortTemplates(templates);
            this.formModul.patchValue({
              template_id: savedId,
              template_name: String(erg?.name || name),
            });
            this.uiMessageService.erstelleMessage('success', templateId ? 'Vorlage aktualisiert.' : 'Vorlage gespeichert.');
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
        });
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  private getSelectedFile(): File | null {
    return this.fotoRef?.selectedFile ?? null;
  }

  convertNewsDate(data: INews[]): INews[] {
    return data.map((item) => {
      const createdAt = String(item.created_at).split('T');
      const createdDate = createdAt[0];
      const createdTime = createdAt[1]?.split(':') ?? [];

      return {
        ...item,
        created_at: `${createdDate}`,
      };
    });
  }

  private normalizeNewsItem(item: INews): INews {
    return this.convertNewsDate([item])[0] as INews;
  }

  private normalizeInfoscreenDate(value: string | null | undefined): string | null {
    const normalized = normalizeDateInput(value);
    return normalized || null;
  }

  getNewsExcerpt(text: string | undefined): string {
    const normalized = String(text || '').replace(/\s+/g, ' ').trim();
    if (normalized.length <= 110) {
      return normalized;
    }
    return `${normalized.slice(0, 107)}...`;
  }

  setzeSelectZurueck(): void {
    this.formAuswahl.controls['news'].setValue('', { onlySelf: true });
  }

  datenLoeschen(): void {
    const id = this.formModul.controls['id'].value!;
    this.auswahlLoeschen(id);
  }

  auswahlLoeschen(id: string | number): void {
    if (!id || id === '0' || id === 0) {
      return;
    }
    this.apiHttpService.delete(this.modul, id).subscribe({
      next: () => {
        try {
          this.newsArray = this.sortNewsByCreatedDesc(
            this.newsArray.filter(n => n.id !== String(id))
          );
          this.newsDataSource.data = this.newsArray;
          this.resetFormNachAktion();
          this.uiMessageService.erstelleMessage('success', 'News erfolgreich gelöscht!');
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error)
    });
  }

  auswahlBearbeiten(element: INews): void {
    if (!element.id || element.id === '0') {
      return;
    }
    const abfrageUrl = `${this.modul}/${element.id}`;
    this.apiHttpService.get<INews>(abfrageUrl).subscribe({
      next: (erg) => {
        try {
          const details: INews = erg;
          this.formModul.enable();
          this.isEditMode = true;
          this.btnUploadStatus = true;

          if (details.foto_url) {
            this.btnText = 'Bild ersetzen';
            const parts = details.foto_url.split('/');
            this.fileName = parts[parts.length - 1] ?? '';
            this.fileFound = true;
            this.filePfad = details.foto_url;
          } else {
            this.btnText = 'Bild auswählen';
            this.fileName = '';
            this.fileFound = false;
            this.filePfad = '';
          }

          this.formModul.setValue({
            id: details.id,
            template_id: '',
            template_name: '',
            title: details.title,
            text: details.text,
            typ: details.typ,
            infoscreen_anzeige_ab: details.infoscreen_anzeige_ab || '',
            infoscreen_anzeige_bis: details.infoscreen_anzeige_bis || '',
            foto_url: ''
          });
          this.setzeSelectZurueck();
        } catch (e: unknown) {
          this.uiMessageService.erstelleMessage('error', String(e));
        }
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error)
    });
  }

  abbrechen(): void {
    this.uiMessageService.erstelleMessage('info', 'News nicht gespeichert!');
    this.resetFormNachAktion();
  }

  neueDetails(): void {
    this.formModul.enable();
    this.isEditMode = true;
    this.btnUploadStatus = true;
    this.btnText = 'Bild auswählen';
    this.fileName = '';
    this.filePfad = '';
    this.fileFound = false;
    this.formModul.patchValue({
      id: '',
      template_id: '',
      template_name: '',
      title: '',
      text: '',
      typ: 'intern',
      infoscreen_anzeige_ab: '',
      infoscreen_anzeige_bis: '',
      foto_url: ''
    });
    this.setzeSelectZurueck();

    // Datei-Auswahl im Input zurücksetzen
    this.fotoRef?.clear();
  }

  datenSpeichern(): void {
    const idValue = this.formModul.controls['id'].value || '';
    const title = this.formModul.controls['title'].value!;
    const text = this.formModul.controls['text'].value!;
    const typ = this.formModul.controls['typ'].value!;
    const infoscreen_anzeige_ab = this.normalizeInfoscreenDate(this.formModul.controls['infoscreen_anzeige_ab'].value);
    const infoscreen_anzeige_bis = this.normalizeInfoscreenDate(this.formModul.controls['infoscreen_anzeige_bis'].value);
    const file = this.getSelectedFile();

    if (!idValue) {
      // CREATE
      if (file) {
        const fd = new FormData();
        fd.append('title', title);
        fd.append('text', text);
        fd.append('typ', typ);
        fd.append('infoscreen_anzeige_ab', infoscreen_anzeige_ab ?? '');
        fd.append('infoscreen_anzeige_bis', infoscreen_anzeige_bis ?? '');
        fd.append('foto', file, file.name || 'upload.png');

        this.apiHttpService.post<INews>(this.modul, fd, true).subscribe({
          next: (erg) => {
            try {
              const normalized = this.normalizeNewsItem(erg);
              this.newsArray = this.sortNewsByCreatedDesc([...this.newsArray, normalized]);
              this.newsDataSource.data = this.newsArray;
              this.newsDataSource.paginator?.firstPage();
              this.resetFormNachAktion();
              this.uiMessageService.erstelleMessage('success', 'News erfolgreich gespeichert!');
            } catch (e: unknown) {
              this.uiMessageService.erstelleMessage('error', String(e));
            }
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error)
        });
      } else {
        // JSON ohne Bild
        this.apiHttpService.post<INews>(this.modul, {
          title,
          text,
          typ,
          infoscreen_anzeige_ab,
          infoscreen_anzeige_bis
        }, false).subscribe({
          next: (erg) => {
            try {
              const normalized = this.normalizeNewsItem(erg);
              this.newsArray = this.sortNewsByCreatedDesc([...this.newsArray, normalized]);
              this.newsDataSource.data = this.newsArray;
              this.newsDataSource.paginator?.firstPage();
              this.resetFormNachAktion();
              this.uiMessageService.erstelleMessage('success', 'News erfolgreich gespeichert!');
            } catch (e: unknown) {
              this.uiMessageService.erstelleMessage('error', String(e));
            }
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error)
        });
      }
    } else {
      // UPDATE
      if (file) {
        const fd = new FormData();
        fd.append('title', title);
        fd.append('text', text);
        fd.append('typ', typ);
        fd.append('infoscreen_anzeige_ab', infoscreen_anzeige_ab ?? '');
        fd.append('infoscreen_anzeige_bis', infoscreen_anzeige_bis ?? '');
        fd.append('foto', file, file.name || 'upload.png');

        this.apiHttpService.patch<INews>(this.modul, idValue, fd, true).subscribe({
          next: (erg) => {
            try {
              const normalized = this.normalizeNewsItem(erg);
              this.newsArray = this.sortNewsByCreatedDesc(
                this.newsArray.map(n => (n.id === normalized.id ? normalized : n))
              );
              this.newsDataSource.data = this.newsArray;
              this.newsDataSource.paginator?.firstPage();
              this.resetFormNachAktion();
              this.uiMessageService.erstelleMessage('success', 'News erfolgreich geändert!');
            } catch (e: unknown) {
              this.uiMessageService.erstelleMessage('error', String(e));
            }
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error)
        });
      } else {
        // Nur Text/Titel ändern (JSON)
        this.apiHttpService.patch<INews>(this.modul, idValue, {
          title,
          text,
          typ,
          infoscreen_anzeige_ab,
          infoscreen_anzeige_bis
        }, false).subscribe({
          next: (erg) => {
            try {
              const normalized = this.normalizeNewsItem(erg);
              this.newsArray = this.sortNewsByCreatedDesc(
                this.newsArray.map(n => (n.id === normalized.id ? normalized : n))
              );
              this.newsDataSource.data = this.newsArray;
              this.newsDataSource.paginator?.firstPage();
              this.resetFormNachAktion();
              this.uiMessageService.erstelleMessage('success', 'News erfolgreich geändert!');
            } catch (e: unknown) {
              this.uiMessageService.erstelleMessage('error', String(e));
            }
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error)
        });
      }
    }
  }

  onFotoSelected(_event: Event): void {
    const file = this.getSelectedFile();
    if (this.selectedPreviewUrl) {
      URL.revokeObjectURL(this.selectedPreviewUrl);
      this.selectedPreviewUrl = '';
    }

    if (!file) {
      this.fileFound = false;
      this.fileName = '';
      this.filePfad = '';
      this.imageModalOpen = false;
      return;
    }
    const sizeKB = Math.round(file.size / 1024);
    if (sizeKB >= this.apiHttpService.MaxUploadSize) {
      this.fileFound = false;
      this.fileName = '';
      const maxMB = this.apiHttpService.MaxUploadSize / 1024;
      this.uiMessageService.erstelleMessage('error', `Foto darf nicht größer als ${maxMB}MB sein!`);
      // Input leeren
      this.fotoRef?.clear();
    } else {
      this.fileFound = true;
      this.fileName = file.name;
      this.selectedPreviewUrl = URL.createObjectURL(file);
      this.filePfad = this.selectedPreviewUrl;
    }
  }

  openModal(): void {
    if (!this.fileFound) {
      return;
    }
    this.focusBeforePhotoModal = document.activeElement instanceof HTMLElement
      ? document.activeElement
      : null;
    this.imageModalOpen = true;
  }

  closeModal(): void {
    if (!this.imageModalOpen) {
      return;
    }
    this.imageModalOpen = false;
    setTimeout(() => {
      this.focusBeforePhotoModal?.focus();
      this.focusBeforePhotoModal = null;
    }, 0);
  }

  closeModalIfBackdrop(event: MouseEvent): void {
    if (event.target === event.currentTarget) {
      this.closeModal();
    }
  }

  newsfeedOeffnen(): void {
    window.open('/newsfeed', '_blank');
  }

  applyFilter(value: string): void {
    this.newsDataSource.filter = this.normalizeFilterValue(value);
    this.newsDataSource.paginator?.firstPage();
  }

  private resetFormNachAktion(): void {
    this.formModul.reset({
      id: '',
      template_id: '',
      template_name: '',
      title: '',
      text: '',
      typ: '',
      infoscreen_anzeige_ab: '',
      infoscreen_anzeige_bis: '',
      foto_url: ''
    });
    this.formModul.disable();
    this.isEditMode = false;
    this.btnUploadStatus = false;
    this.btnText = 'Bild auswählen';
    this.fileName = '';
    this.filePfad = '';
    this.fileFound = false;
    this.imageModalOpen = false;
    if (this.selectedPreviewUrl) {
      URL.revokeObjectURL(this.selectedPreviewUrl);
      this.selectedPreviewUrl = '';
    }
    this.setzeSelectZurueck();
    // Datei im Input löschen
    this.fotoRef?.clear();
  }

  private toCreatedAtTimestamp(value: unknown): number {
    const raw = String(value || '').trim();

    if (!raw) {
      return 0;
    }

    // Unterstützt:
    // 2026-05-18T14:30:00
    // 2026-05-18 14:30:00
    // 2026-05-18_14:30
    const isoMatch = raw.match(
      /^(\d{4})-(\d{2})-(\d{2})[T _](\d{2}):(\d{2})(?::(\d{2}))?/
    );

    if (isoMatch) {
      const [, year, month, day, hour, minute, second = '0'] = isoMatch;

      return new Date(
        Number(year),
        Number(month) - 1,
        Number(day),
        Number(hour),
        Number(minute),
        Number(second)
      ).getTime();
    }

    // Unterstützt optional:
    // 18.05.2026 14:30
    // 18.05.2026_14:30
    const deMatch = raw.match(
      /^(\d{2})\.(\d{2})\.(\d{4})[T _](\d{2}):(\d{2})(?::(\d{2}))?/
    );

    if (deMatch) {
      const [, day, month, year, hour, minute, second = '0'] = deMatch;

      return new Date(
        Number(year),
        Number(month) - 1,
        Number(day),
        Number(hour),
        Number(minute),
        Number(second)
      ).getTime();
    }

    return 0;
  }

  private sortNewsByCreatedDesc(data: INews[] = []): INews[] {
    return [...data].sort((a, b) =>
      this.toCreatedAtTimestamp(b.created_at) - this.toCreatedAtTimestamp(a.created_at)
    );
  }
}
