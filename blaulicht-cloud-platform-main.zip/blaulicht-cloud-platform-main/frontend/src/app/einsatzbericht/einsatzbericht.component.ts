﻿import { Component, DestroyRef, OnInit, ViewChild, inject } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  FormGroupDirective,
  NgForm,
  ReactiveFormsModule,
  ValidationErrors,
  Validators
} from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { switchMap } from 'rxjs';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../imr-ui-library';
import { ImrUploadFieldComponent } from '../imr-ui-library/imr-upload-field/imr-upload-field.component';
import { ApiHttpService } from 'src/app/_service/api-http.service';
import { AuthSessionService } from 'src/app/_service/auth-session.service';
import { CollectionUtilsService } from 'src/app/_service/collection-utils.service';
import { NavigationService } from 'src/app/_service/navigation.service';
import { UiMessageService } from 'src/app/_service/ui-message.service';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatAutocompleteModule, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { ErrorStateMatcher } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDialog } from '@angular/material/dialog';
import { DateInputMaskDirective } from '../_directive/date-input-mask.directive';
import { normalizeDateInput } from '../_utils/date-normalization.util';
import { TABLE_PAGINATION_DEFAULT_PAGE_SIZE, TABLE_PAGINATION_PAGE_SIZE_OPTIONS } from '../_utils/table-pagination-options';
import { IPdfTemplate } from '../_interface/pdf_template';
import { EinsatzberichtSendPreviewDialogComponent, EinsatzberichtSendPreviewDialogData } from './einsatzbericht-send-preview-dialog.component';

type FahrzeugOption = {
  id: number;
  label: string;
};

type MitgliedOption = {
  id: number;
  label: string;
};

type UserOption = {
  id: string;
  username: string;
  display: string;
  email: string;
};

type MitalarmiertStelleOption = {
  id: number;
  label: string;
};

type EinsatzberichtFotoDto = {
  id: string | number;
  foto_url?: string;
  dokument_typ?: string;
};

type EinsatzberichtDto = {
  id: string;
  status: string;
  alarmstichwort: string;
  einsatzleiter: string;
  einsatzart: string;
  einsatzadresse: string;
  alarmierende_stelle: string;
  einsatz_datum: string;
  ausgerueckt: string;
  eingerueckt: string;
  lage_beim_eintreffen: string;
  gesetzte_massnahmen: string;
  brand_kategorie: string;
  brand_aus: string;
  technisch_kategorie: string;
  bma_meldergruppe: string;
  bma_melder: string;
  bma_fehl_tauschungsalarm: string;
  mitalarmiert: number[];
  fahrzeuge: number[];
  mitglieder: number[];
  blaulichtsms_einsatz_id: string;
  fotos?: EinsatzberichtFotoDto[];
  created_at?: string;
};

type EinsatzberichteContextItem = {
  pkid?: number | string;
  name?: string;
  bezeichnung?: string;
  stbnr?: string;
  vorname?: string;
  nachname?: string;
};

type EinsatzberichteContextResponse = {
  fahrzeuge?: EinsatzberichteContextItem[];
  mitglieder?: EinsatzberichteContextItem[];
  mitalarmiert_stellen?: EinsatzberichteContextItem[];
  modul_konfig?: Array<{ modul?: string; konfiguration?: Record<string, unknown> }>;
  konfig?: Array<Record<string, unknown>>;
  users?: Array<{ id: string; username: string; display: string; email: string }>;
};

type UserSelfResponse = {
  roles?: string[];
  is_superuser?: boolean;
};

type EinsatzberichteListResponse = EinsatzberichtDto[] | { data?: EinsatzberichtDto[]; results?: EinsatzberichtDto[] };

type BlaulichtsmsResponse = {
  mapped?: {
    alarmstichwort?: string;
    einsatzart?: string;
    einsatzadresse?: string;
    alarmierende_stelle?: unknown;
    mitglieder_ids?: number[];
    einsatz_datum?: string;
    ausgerueckt?: string;
  };
  raw?: {
    geolocation?: {
      address?: string;
    };
  };
};

type SaveEinsatzberichtResponse = {
  id?: string;
  status?: string;
};

type EinsatzberichtePdfKonfig = {
  idEinsatzberichtPdf?: string;
  einsatzberichtEmpfaengerUserId?: string | null;
  [key: string]: unknown;
};
type EinsatzberichteModulKonfigItem = { id?: string | number; modul: string; konfiguration?: Record<string, unknown>; updated_at?: string };
type EinsatzberichteModulKonfigResponse = { user?: { roles?: unknown }; main?: EinsatzberichteModulKonfigItem[] } | EinsatzberichteModulKonfigItem[];
type EinsatzberichtePdfTemplatesResponse = { main?: IPdfTemplate[] } | IPdfTemplate[];
type SendReadinessState = 'ready' | 'warning' | 'neutral';

@Component({
  standalone: true,
  selector: 'app-einsatzbericht',
  imports: [
    ReactiveFormsModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    ImrUploadFieldComponent,
    MatButtonModule,
    MatChipsModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatTableModule,
    MatSortModule,
    MatExpansionModule,
    DateInputMaskDirective,
  ],
  templateUrl: './einsatzbericht.component.html',
  styleUrl: './einsatzbericht.component.sass'
})
export class EinsatzberichtComponent implements OnInit {
  private readonly BMA_FEHL_TAEUSCHUNGSALARM_NONE = '__NONE__';
  private readonly STATISTIK_STATUS = 'STATISTIK';
  private readonly statistikFallbackValues = {
    einsatzleiter: 'Statistik',
    einsatzart: 'Statistik',
    alarmstichwort: 'Statistik',
    einsatzadresse: 'Statistik',
    alarmierendeStelle: 'Statistik',
    eingerueckt: '00:00',
    lageBeimEintreffen: 'Automatisch ergänzt (Statistik)',
    gesetzteMassnahmen: 'Automatisch ergänzt (Statistik)',
  };
  private readonly einsatzDatumFormatValidator = (control: AbstractControl<string>): ValidationErrors | null => {
    const value = String(control.value ?? '').trim();
    if (!value) {
      return null;
    }
    return this.normalizeDateInput(value) ? null : { invalidDate: true };
  };

  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private collectionUtilsService = inject(CollectionUtilsService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  private dialog = inject(MatDialog);
  private destroyRef = inject(DestroyRef);
  @ViewChild(MatPaginator) set matPaginator(p: MatPaginator | undefined) {
    if (p) this.dataSource.paginator = p;
  }

  @ViewChild(MatSort) set matSort(s: MatSort | undefined) {
    if (s) {
      this.dataSource.sort = s;
      this.applyInitialDateSort();
    }
  }

  title = 'Einsatzbericht';
  breadcrumb: ImrBreadcrumbItem[] = [];
  readonly pageSizeOptions = TABLE_PAGINATION_PAGE_SIZE_OPTIONS.standard;
  readonly pageSize = TABLE_PAGINATION_DEFAULT_PAGE_SIZE.standard;

  bestehendeFotos: EinsatzberichtFotoDto[] = [];
  private filePreviewUrlMap = new Map<File, string>();

  fotoDokuDateien: string[] = [];
  fotoDokuFiles: File[] = [];

  zulassungDateien: string[] = [];
  zulassungFiles: File[] = [];

  versicherungDateien: string[] = [];
  versicherungFiles: File[] = [];

  einsatzarten = [
    'Brandeinsatz',
    'Technischer Einsatz',
    'Schadstoffeinsatz',
    'Brandsicherheitswache',
    'Sonstiges'
  ];

  brandOptionen = [
    'Kleinbrand',
    'Mittelbrand',
    'Großbrand',
    'Brand vor Eintreffen gelöscht oder erloschen'
  ];

  brandOptionBeschreibungen: Record<string, string> = {
    'Kleinbrand': 'Kleinlöschgerät, HD/Schnellangriff, 1 STrahlrohr, Kaminbrand',
    'Mittelbrand': '2-3 Strahlrohre im Einsatz',
    'Großbrand': '> 3 Strahrohre im Einsatz',
    'Brand vor Eintreffen gelöscht oder erloschen': '',
  };

  technischOptionen = [
    'Tiere oder Menschen gerettet/befreit',
    'Unfall mit Schadstoffen',
    'Unfall mit Personenschaden',
    'VU - LKW',
    'VU - mehr als 2 beteiligte PKW',
    'VU - mehr als 5 Verletzte oder min. ein Todesopfer'
  ];

  fahrzeugOptionen: FahrzeugOption[] = [];
  mitgliedOptionen: MitgliedOption[] = [];
  userOptionen: UserOption[] = [];
  einsatzleiterSuche = new FormControl<string>('', { nonNullable: true, validators: [Validators.required] });

  einsatzleiterErrorMatcher: ErrorStateMatcher = {
    isErrorState: (_control: AbstractControl | null, _form: FormGroupDirective | NgForm | null) =>
      this.formBericht.controls.einsatzleiter.touched && this.formBericht.controls.einsatzleiter.invalid,
  };
  fahrzeugSuche = new FormControl<string>('', { nonNullable: true });
  mitgliedSuche = new FormControl<string>('', { nonNullable: true });
  mitalarmiertSuche = new FormControl<string>('', { nonNullable: true });
  berichte: EinsatzberichtDto[] = [];
  dataSource = new MatTableDataSource<EinsatzberichtDto>([]);
  viewMode: 'list' | 'form' = 'list';
  sichtbareSpalten: string[] = ['einsatz_datum', 'alarmstichwort', 'einsatzadresse', 'status', 'actions'];
  canEditBerichte = false;
  canDeleteBerichte = false;
  canManageStatus = false;
  canPrintBericht = false;
  isAdmin = false;
  private hasInitializedDateSort = false;

  private stammdaten: Record<string, unknown> = {};
  private pdf_konfig: EinsatzberichtePdfKonfig = {};

  private readonly modulKonfigurationEndpoint = 'modul_konfiguration';
  pdfTemplates: IPdfTemplate[] = [];
  pdfKonfigId: string | null = null;
  private pdfTemplatesLoaded = false;
  settingsPanelOpen = false;

  formSettings = new FormGroup({
    idEinsatzberichtPdf: new FormControl<string | null>(null),
    einsatzberichtEmpfaengerUserId: new FormControl<string | null>(null),
  });

  statusOptionen = [
    { key: 'ENTWURF', label: 'Entwurf' },
    { key: 'GESENDET', label: 'Gesendet' },
    { key: 'FDISK_EINGETRAGEN', label: 'FDISK eingetragen' },
    { key: 'STATISTIK', label: 'Statistik' },
  ];

  alarmierendeStelleOptionenBasis: string[] = [
    'AAZ / BAZ / LWZ',
    'Eigenalarmiert',
    'Keine Alarmiert',
  ];

  mitalarmiertOptionen: MitalarmiertStelleOption[] = [];

  formBericht = new FormGroup({
    id: new FormControl<string>('', { nonNullable: true }),
    status: new FormControl<string>('ENTWURF', { nonNullable: true, validators: [Validators.required] }),
    einsatzleiter: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    einsatzart: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    alarmstichwort: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    einsatzadresse: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    alarmierendeStelle: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    einsatzDatum: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required, this.einsatzDatumFormatValidator]
    }),
    ausgerueckt: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    eingerueckt: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    lageBeimEintreffen: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    gesetzteMassnahmen: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    brandKategorie: new FormControl<string>('', { nonNullable: true }),
    brandAus: new FormControl<string>('', { nonNullable: true }),
    technischKategorie: new FormControl<string>('', { nonNullable: true }),
    bmaMeldergruppe: new FormControl<string>('', { nonNullable: true }),
    bmaMelder: new FormControl<string>('', { nonNullable: true }),
    bmaFehlTauschungsalarm: new FormControl<string>(this.BMA_FEHL_TAEUSCHUNGSALARM_NONE, { nonNullable: true }),
    mitalarmiert: new FormControl<number[]>([], { nonNullable: true }),
    fahrzeuge: new FormControl<number[]>([], { nonNullable: true }),
    mitglieder: new FormControl<number[]>([], { nonNullable: true }),
  });

  get isBrand(): boolean {
    return this.formBericht.controls.einsatzart.value === 'Brandeinsatz';
  }

  get isTechnisch(): boolean {
    return this.formBericht.controls.einsatzart.value === 'Technischer Einsatz';
  }

  get isStatistikStatus(): boolean {
    return this.formBericht.controls.status.value === this.STATISTIK_STATUS;
  }

  get isReportReadOnly(): boolean {
    return !this.canManageStatus && this.formBericht.controls.status.value !== 'ENTWURF';
  }

  get hasPdfTemplateConfiguredForSend(): boolean {
    return !!this.stringOrNull(this.pdf_konfig.idEinsatzberichtPdf);
  }

  get hasRecipientConfiguredForSend(): boolean {
    // Fallback ist immer fw_email aus Stammdaten – gilt daher immer als bereit
    return true;
  }

  get canSendWorkflowReady(): boolean {
    return this.hasPdfTemplateConfiguredForSend && this.hasRecipientConfiguredForSend;
  }

  getSendReadinessLabel(bericht: EinsatzberichtDto): string {
    if (bericht.status !== 'ENTWURF') {
      return 'Nicht relevant';
    }

    if (!this.canEditBerichte) {
      return 'Keine Berechtigung';
    }

    if (!this.canSendWorkflowReady) {
      return 'Konfiguration fehlt';
    }

    return 'Senden bereit';
  }

  getSendReadinessState(bericht: EinsatzberichtDto): SendReadinessState {
    if (bericht.status !== 'ENTWURF') {
      return 'neutral';
    }

    if (!this.canEditBerichte || !this.canSendWorkflowReady) {
      return 'warning';
    }

    return 'ready';
  }

  get section1HasError(): boolean {
    if (this.isStatistikStatus) {
      return false;
    }
    const c = this.formBericht.controls;
    return [c.einsatzleiter, c.einsatzart, c.alarmstichwort, c.einsatzadresse, c.alarmierendeStelle, c.einsatzDatum, c.ausgerueckt, c.eingerueckt]
      .some((ctrl) => ctrl.invalid && ctrl.touched);
  }

  get section2HasError(): boolean {
    if (this.isStatistikStatus) {
      return false;
    }
    const c = this.formBericht.controls;
    return [c.lageBeimEintreffen, c.gesetzteMassnahmen]
      .some((ctrl) => ctrl.invalid && ctrl.touched);
  }

  get isBMA(): boolean {
    return /\bgefahrenmeldeanlage\b/i.test(this.formBericht.controls.alarmstichwort.value);
  }

  bmaFehlTauschungsalarmOptionen = [
    { value: this.BMA_FEHL_TAEUSCHUNGSALARM_NONE, label: 'Kein Fehl-/Täuschungsalarm' },
    { value: 'Fehlalarm', label: 'Fehlalarm' },
    { value: 'Täuschungsalarm', label: 'Täuschungsalarm' },
  ];

  get sortedFahrzeugOptionen(): FahrzeugOption[] {
    const selectedIds = this.formBericht.controls.fahrzeuge.value;
    const idToFahrzeug = new Map(this.fahrzeugOptionen.map((f) => [f.id, f]));

    // Ausgewählte Fahrzeuge in der Reihenfolge des selectedIds arrays
    const selectedVehicles = selectedIds
      .map((id) => idToFahrzeug.get(id))
      .filter((f): f is FahrzeugOption => f !== undefined);

    // Nicht ausgewählte Fahrzeuge
    const selectedSet = new Set(selectedIds);
    const unselectedVehicles = this.fahrzeugOptionen.filter((f) => !selectedSet.has(f.id));

    return [...selectedVehicles, ...unselectedVehicles];
  }

  get filteredFahrzeugOptionen(): FahrzeugOption[] {
    const search = this.fahrzeugSuche.value.trim().toLowerCase();
    const selectedIds = this.formBericht.controls.fahrzeuge.value;
    const selectedSet = new Set(selectedIds);
    return this.fahrzeugOptionen
      .filter((fahrzeug) => !selectedSet.has(fahrzeug.id))
      .filter((fahrzeug) => {
        if (!search) {
          return true;
        }
        return fahrzeug.label.toLowerCase().includes(search);
      });
  }

  get einsatzleiterOptionen(): string[] {
    const options = this.mitgliedOptionen.map((mitglied) => mitglied.label);
    const current = this.formBericht.controls.einsatzleiter.value?.trim();
    if (current && !options.includes(current)) {
      options.unshift(current);
    }
    return options;
  }

  get filteredEinsatzleiterOptionen(): string[] {
    const search = this.einsatzleiterSuche.value.trim().toLowerCase();
    if (!search) {
      return this.einsatzleiterOptionen;
    }

    return this.einsatzleiterOptionen.filter((einsatzleiter) => einsatzleiter.toLowerCase().includes(search));
  }

  get alarmierendeStelleOptionen(): string[] {
    const current = this.formBericht.controls.alarmierendeStelle.value?.trim();
    if (current && !this.alarmierendeStelleOptionenBasis.includes(current)) {
      return [current, ...this.alarmierendeStelleOptionenBasis];
    }
    return this.alarmierendeStelleOptionenBasis;
  }

  get sortedMitalarmiertOptionen(): MitalarmiertStelleOption[] {
    const selectedIds = this.formBericht.controls.mitalarmiert.value;
    const idToOption = new Map(this.mitalarmiertOptionen.map((o) => [o.id, o]));

    // Ausgewählte Stellen in der Reihenfolge des selectedIds arrays
    const selectedOptions = selectedIds
      .map((id) => idToOption.get(id))
      .filter((o): o is MitalarmiertStelleOption => o !== undefined);

    // Nicht ausgewählte Stellen
    const selectedSet = new Set(selectedIds);
    const unselectedOptions = this.mitalarmiertOptionen.filter((o) => !selectedSet.has(o.id));

    return [...selectedOptions, ...unselectedOptions];
  }

  get filteredMitalarmiertOptionen(): MitalarmiertStelleOption[] {
    const search = this.mitalarmiertSuche.value.trim().toLowerCase();
    const selectedIds = this.formBericht.controls.mitalarmiert.value;
    const idToOption = new Map(this.mitalarmiertOptionen.map((o) => [o.id, o]));

    // Ausgewählte Stellen in der Reihenfolge des selectedIds arrays
    const selectedOptions = selectedIds
      .map((id) => idToOption.get(id))
      .filter((o): o is MitalarmiertStelleOption => o !== undefined)
      .filter((option) => {
        if (!search) {
          return true;
        }
        return option.label.toLowerCase().includes(search);
      });

    // Nicht ausgewählte Stellen
    const selectedSet = new Set(selectedIds);
    const unselectedOptions = this.mitalarmiertOptionen
      .filter((option) => !selectedSet.has(option.id))
      .filter((option) => {
        if (!search) {
          return true;
        }
        return option.label.toLowerCase().includes(search);
      });

    return [...selectedOptions, ...unselectedOptions];
  }

  get selectedMitalarmiertOptionen(): MitalarmiertStelleOption[] {
    const selected = this.formBericht.controls.mitalarmiert.value;
    return this.mitalarmiertOptionen.filter((option) => selected.includes(option.id));
  }

  get brandOptionenMitBeschreibung(): Array<{ titel: string; beschreibung: string }> {
    return this.brandOptionen.map((titel) => ({
      titel,
      beschreibung: this.brandOptionBeschreibungen[titel] || ''
    }));
  }

  get selectedFahrzeugOptionen(): FahrzeugOption[] {
    const selected = this.formBericht.controls.fahrzeuge.value;
    return this.fahrzeugOptionen.filter((fahrzeug) => selected.includes(fahrzeug.id));
  }

  get selectedMitgliedOptionen(): MitgliedOption[] {
    const selected = this.formBericht.controls.mitglieder.value;
    return this.mitgliedOptionen.filter((mitglied) => selected.includes(mitglied.id));
  }

  get mitgliederAuswahlCounter(): number {
    return this.formBericht.controls.mitglieder.value.length;
  }

  get mitgliederAuswahlTriggerText(): string {
    const first = this.selectedMitgliedOptionen[0];
    if (!first) {
      return 'Keine Mitglieder ausgewählt';
    }
    return first.label;
  }

  get sortedMitgliedOptionen(): MitgliedOption[] {
    const selectedIds = this.formBericht.controls.mitglieder.value;
    const idToMitglied = new Map(this.mitgliedOptionen.map((m) => [m.id, m]));

    // Ausgewählte Mitglieder in der Reihenfolge des selectedIds arrays
    const selectedMembers = selectedIds
      .map((id) => idToMitglied.get(id))
      .filter((m): m is MitgliedOption => m !== undefined);

    // Nicht ausgewählte Mitglieder
    const selectedSet = new Set(selectedIds);
    const unselectedMembers = this.mitgliedOptionen.filter((m) => !selectedSet.has(m.id));

    return [...selectedMembers, ...unselectedMembers];
  }

  get filteredMitgliedOptionen(): MitgliedOption[] {
    const search = this.mitgliedSuche.value.trim().toLowerCase();
    const selectedIds = this.formBericht.controls.mitglieder.value;
    const selectedSet = new Set(selectedIds);

    if (!search) {
      return this.sortedMitgliedOptionen;
    }

    // Bereits ausgewählte immer anzeigen (damit abwählen möglich bleibt),
    // nicht ausgewählte nur wenn sie zum Suchbegriff passen
    return this.mitgliedOptionen.filter(
      (mitglied) => selectedSet.has(mitglied.id) || mitglied.label.toLowerCase().includes(search),
    );
  }

  get bestehendeDokuFotos(): EinsatzberichtFotoDto[] {
    return this.bestehendeFotos.filter((foto) => (foto.dokument_typ || 'ALLGEMEIN') === 'DOKU');
  }

  get bestehendeZulassungFotos(): EinsatzberichtFotoDto[] {
    return this.bestehendeFotos.filter((foto) => foto.dokument_typ === 'ZULASSUNG');
  }

  get bestehendeVersicherungFotos(): EinsatzberichtFotoDto[] {
    return this.bestehendeFotos.filter((foto) => foto.dokument_typ === 'VERSICHERUNG');
  }

  isImagePath(path: string | undefined): boolean {
    if (!path) {
      return false;
    }
    return /\.(jpg|jpeg|png|gif|webp|bmp|svg)(\?.*)?$/i.test(path);
  }

  getFileNameFromPath(path: string | undefined): string {
    if (!path) {
      return 'Datei';
    }
    const clean = path.split('?')[0];
    return clean.split('/').pop() || clean;
  }

  getFilePreviewUrl(file: File): string {
    const existing = this.filePreviewUrlMap.get(file);
    if (existing) {
      return existing;
    }
    const created = URL.createObjectURL(file);
    this.filePreviewUrlMap.set(file, created);
    return created;
  }

  openFoto(url: string | undefined): void {
    if (this.isReportReadOnly) {
      return;
    }
    if (!url) {
      return;
    }
    window.open(url, '_blank');
  }

  removeSelectedDokument(index: number, dokumentTyp: 'fotoDoku' | 'zulassungsschein' | 'versicherungsschein'): void {
    if (this.isReportReadOnly) {
      return;
    }
    const confirmDelete = window.confirm('Datei wirklich entfernen?');
    if (!confirmDelete) {
      return;
    }

    if (dokumentTyp === 'fotoDoku') {
      const removed = this.fotoDokuFiles[index];
      if (removed) {
        const url = this.filePreviewUrlMap.get(removed);
        if (url) {
          URL.revokeObjectURL(url);
          this.filePreviewUrlMap.delete(removed);
        }
      }
      this.fotoDokuFiles = this.fotoDokuFiles.filter((_, i) => i !== index);
      this.fotoDokuDateien = this.fotoDokuFiles.map((file) => file.name);
      return;
    }

    if (dokumentTyp === 'zulassungsschein') {
      const removed = this.zulassungFiles[index];
      if (removed) {
        const url = this.filePreviewUrlMap.get(removed);
        if (url) {
          URL.revokeObjectURL(url);
          this.filePreviewUrlMap.delete(removed);
        }
      }
      this.zulassungFiles = this.zulassungFiles.filter((_, i) => i !== index);
      this.zulassungDateien = this.zulassungFiles.map((file) => file.name);
      return;
    }

    const removed = this.versicherungFiles[index];
    if (removed) {
      const url = this.filePreviewUrlMap.get(removed);
      if (url) {
        URL.revokeObjectURL(url);
        this.filePreviewUrlMap.delete(removed);
      }
    }
    this.versicherungFiles = this.versicherungFiles.filter((_, i) => i !== index);
    this.versicherungDateien = this.versicherungFiles.map((file) => file.name);
  }

  loescheBestehendesFoto(foto: EinsatzberichtFotoDto): void {
    if (this.isReportReadOnly) {
      return;
    }
    const berichtId = this.formBericht.controls.id.value;
    if (!berichtId || !foto?.id) {
      return;
    }

    const fileName = this.getFileNameFromPath(foto.foto_url);
    const confirmDelete = window.confirm(`Foto "${fileName}" wirklich löschen?`);
    if (!confirmDelete) {
      return;
    }

    this.apiHttpService.delete(`einsatzberichte/${berichtId}/fotos`, foto.id).subscribe({
      next: () => {
        this.bestehendeFotos = this.bestehendeFotos.filter((entry) => String(entry.id) !== String(foto.id));
        this.uiMessageService.erstelleMessage('success', 'Foto gelöscht.');
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  formatListDateTime(value: string | null | undefined): string {
    if (!value) {
      return '';
    }

    // Plain date string (YYYY-MM-DD): avoid UTC midnight parsing and show date only
    const dateOnlyMatch = String(value).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (dateOnlyMatch) {
      return `${dateOnlyMatch[3]}.${dateOnlyMatch[2]}.${dateOnlyMatch[1]}`;
    }

    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) {
      return String(value);
    }

    const day = String(parsed.getDate()).padStart(2, '0');
    const month = String(parsed.getMonth() + 1).padStart(2, '0');
    const year = parsed.getFullYear();
    const hour = String(parsed.getHours()).padStart(2, '0');
    const minute = String(parsed.getMinutes()).padStart(2, '0');

    return `${day}.${month}.${year} ${hour}:${minute}`;
  }

  private normalizeDateInput(value: string | null | undefined): string {
    const normalized = normalizeDateInput(value);
    if (!normalized) {
      return '';
    }
    return this.isValidIsoDate(normalized) ? normalized : '';
  }

  private formatDateForApi(value: string | null | undefined): string {
    return this.normalizeDateInput(value);
  }

  private isValidIsoDate(value: string): boolean {
    const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) {
      return false;
    }

    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);

    const parsed = new Date(year, month - 1, day);
    return parsed.getFullYear() === year && parsed.getMonth() === month - 1 && parsed.getDate() === day;
  }

  private configureBerichteTableSort(): void {
    this.dataSource.sortingDataAccessor = (row: EinsatzberichtDto, columnId: string): string | number => {
      if (columnId === 'einsatz_datum') {
        const dateValue = this.parseSortableDateValue(row.einsatz_datum);
        return dateValue ?? 0;
      }

      const rawValue = (row as unknown as Record<string, unknown>)[columnId];
      if (typeof rawValue === 'number') {
        return rawValue;
      }

      return String(rawValue || '').toLowerCase();
    };

    this.dataSource.sortData = (data: EinsatzberichtDto[], sort: MatSort): EinsatzberichtDto[] => {
      const active = sort.active;
      const direction = sort.direction;

      if (!active || direction === '') {
        return data;
      }

      const isAsc = direction === 'asc';

      return data.slice().sort((a, b) => {
        if (active === 'einsatz_datum') {
          const aDateValue = this.parseSortableDateValue(a.einsatz_datum);
          const bDateValue = this.parseSortableDateValue(b.einsatz_datum);
          const aHasDate = aDateValue !== null;
          const bHasDate = bDateValue !== null;

          // Leere/ungueltige Datumswerte immer ans Tabellenende schieben.
          if (!aHasDate && !bHasDate) {
            return 0;
          }
          if (!aHasDate) {
            return 1;
          }
          if (!bHasDate) {
            return -1;
          }
        }

        const valueA = this.dataSource.sortingDataAccessor(a, active);
        const valueB = this.dataSource.sortingDataAccessor(b, active);
        return this.compareSortValues(valueA, valueB, isAsc);
      });
    };
  }

  private applyInitialDateSort(): void {
    if (this.hasInitializedDateSort) {
      return;
    }

    const sort = this.dataSource.sort;
    if (!sort) {
      return;
    }

    sort.active = 'einsatz_datum';
    sort.direction = 'desc';
    sort.sortChange.emit({ active: sort.active, direction: sort.direction });
    this.hasInitializedDateSort = true;
  }

  private compareSortValues(valueA: string | number, valueB: string | number, isAsc: boolean): number {
    if (valueA < valueB) {
      return isAsc ? -1 : 1;
    }
    if (valueA > valueB) {
      return isAsc ? 1 : -1;
    }
    return 0;
  }

  private parseSortableDateValue(rawDate: string | null | undefined): number | null {
    if (!rawDate) {
      return null;
    }

    const trimmed = String(rawDate).trim();
    if (!trimmed) {
      return null;
    }

    // Zuerst deutsches Datumsformat parsen, um Browser-Locale-Missinterpretationen zu vermeiden.
    const match = trimmed.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s+(\d{1,2}):(\d{2}))?$/);
    if (match) {
      const day = Number(match[1]);
      const month = Number(match[2]);
      const year = Number(match[3]);
      const hour = Number(match[4] ?? 0);
      const minute = Number(match[5] ?? 0);

      const parsed = new Date(year, month - 1, day, hour, minute);
      if (
        parsed.getFullYear() === year
        && parsed.getMonth() === month - 1
        && parsed.getDate() === day
        && parsed.getHours() === hour
        && parsed.getMinutes() === minute
      ) {
        return parsed.getTime();
      }
    }

    // ISO-Daten (z.B. 2026-06-11 oder 2026-06-11T08:30:00Z) als Fallback.
    const isoLike = trimmed.match(/^\d{4}-\d{2}-\d{2}(?:[T\s].*)?$/);
    if (isoLike) {
      const isoParsed = Date.parse(trimmed);
      if (!Number.isNaN(isoParsed)) {
        return isoParsed;
      }
    }

    return null;
  }

  ngOnInit(): void {
    sessionStorage.setItem('PageNumber', '2');
    sessionStorage.setItem('Page2', 'BER');
    this.breadcrumb = this.navigationService.ladeBreadcrumb();
    this.configureBerichteTableSort();

    this.formBericht.controls.einsatzart.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.updateConditionalValidation();
      });

    this.formBericht.controls.alarmstichwort.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.updateConditionalValidation();
      });

    this.formBericht.controls.technischKategorie.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.updateConditionalValidation();
      });

    this.formBericht.controls.mitalarmiert.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.updateConditionalValidation();
      });

    this.formBericht.controls.status.valueChanges
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.updateConditionalValidation();
        this.applyFormAccessState();
      });

    this.updateConditionalValidation();
    this.applyFormAccessState();

    this.apiHttpService.get<EinsatzberichteContextResponse>('einsatzberichte/context').subscribe({
      next: (context) => {
        this.fahrzeugOptionen = (context?.fahrzeuge ?? []).map((item) => ({
          id: Number(item.pkid),
          label: item.name ?? item.bezeichnung ?? `Fahrzeug ${item.pkid}`,
        }));

        this.mitgliedOptionen = (context?.mitglieder ?? []).map((item) => ({
          id: Number(item.pkid),
          label: `${item.stbnr ?? ''} ${item.vorname ?? ''} ${item.nachname ?? ''}`.trim(),
        }));

        this.userOptionen = (context?.users ?? [])
          .filter((u) => !!(u?.email ?? '').toString().trim())
          .map((u) => ({
            id: String(u.id),
            username: u.username,
            display: u.display,
            email: u.email,
          }));

        this.mitalarmiertOptionen = (context?.mitalarmiert_stellen ?? []).map((item) => ({
          id: Number(item.pkid),
          label: item.name ?? `Stelle ${item.pkid}`,
        }));

        const pdfKonfig = (context?.modul_konfig ?? [])
          .filter((m) => String(m.modul ?? '').trim().toLowerCase() === 'pdf')
          .sort((a, b) => Number((b as { id?: unknown }).id ?? 0) - Number((a as { id?: unknown }).id ?? 0))[0];
        this.pdf_konfig = pdfKonfig?.konfiguration ?? {};
        this.stammdaten = context?.konfig?.[0] ?? {};
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });

    this.apiHttpService.get<UserSelfResponse>('users/self').subscribe({
      next: (user) => {
        const roles: string[] = Array.isArray(user?.roles) ? user.roles : [];
        const isSuperuser = !!user?.is_superuser;
        this.canEditBerichte = isSuperuser || roles.includes('ADMIN') || roles.includes('BERICHT') || roles.includes('VERWALTUNG');
        this.canDeleteBerichte = isSuperuser || roles.includes('ADMIN') || roles.includes('VERWALTUNG');
        this.canManageStatus = isSuperuser || roles.includes('ADMIN') || roles.includes('VERWALTUNG');
        this.canPrintBericht = isSuperuser || roles.includes('ADMIN') || roles.includes('VERWALTUNG');
        this.isAdmin = isSuperuser || roles.includes('ADMIN');
        if (this.canManageStatus) {
          this.formBericht.controls.status.enable({ emitEvent: false });
        } else {
          this.formBericht.controls.status.disable({ emitEvent: false });
        }
        this.applyFormAccessState();
        if (this.isAdmin) {
          this.loadSettingsContext();
        }
      },
      error: () => {
        this.canEditBerichte = false;
        this.canDeleteBerichte = false;
        this.canManageStatus = false;
        this.canPrintBericht = false;
        this.isAdmin = false;
        this.formBericht.controls.status.disable({ emitEvent: false });
        this.applyFormAccessState();
      },
    });

    this.ladeBerichte();
  }

  ladeBerichte(): void {
    this.apiHttpService.get<EinsatzberichteListResponse>('einsatzberichte').subscribe({
      next: (response) => {
        const data = Array.isArray(response) ? response : (response?.data ?? response?.results ?? []);
        this.berichte = data as EinsatzberichtDto[];
        this.dataSource.data = this.berichte;
        this.applyInitialDateSort();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  applyFilter(value: string): void {
    this.dataSource.filter = (value || '').trim().toLowerCase();
    this.matPaginator?.firstPage();
  }

  get visibleBerichte(): EinsatzberichtDto[] {
    return this.dataSource.filteredData;
  }

  neuerEntwurf(): void {
    this.viewMode = 'form';
    this.formBericht.reset({
      id: '',
      status: 'ENTWURF',
      einsatzleiter: '',
      einsatzart: '',
      alarmstichwort: '',
      einsatzadresse: '',
      alarmierendeStelle: '',
      einsatzDatum: '',
      ausgerueckt: '',
      eingerueckt: '',
      lageBeimEintreffen: '',
      gesetzteMassnahmen: '',
      brandKategorie: '',
      brandAus: '',
      technischKategorie: '',
      bmaMeldergruppe: '',
      bmaMelder: '',
      bmaFehlTauschungsalarm: this.BMA_FEHL_TAEUSCHUNGSALARM_NONE,
      mitalarmiert: [],
      fahrzeuge: [],
      mitglieder: [],
    });
    this.bestehendeFotos = [];
    this.resetSuchfilter();
    this.resetDokumentUploads();
    this.updateConditionalValidation();
    this.applyFormAccessState();
  }

  uebernehmeLetztenEinsatz(): void {
    this.neuerEntwurf();
    this.apiHttpService.get<BlaulichtsmsResponse>('einsatzberichte/blaulichtsms/letzter').subscribe({
      next: (response) => {
        const mapped = response?.mapped ?? {};

        const alarmtext = String(mapped.alarmstichwort ?? '').trim();
        const parsedAlarm = this.parseBlaulichtAlarmtext(alarmtext);

        const uebernommeneEinsatzart = parsedAlarm.einsatzart || String(mapped.einsatzart ?? '').trim();
        const uebernommenesStichwort = this.sanitizeAlarmstichwort(parsedAlarm.alarmstichwort || alarmtext);
        const uebernommeneAdresse = parsedAlarm.einsatzadresse
          || String(mapped.einsatzadresse ?? '').trim()
          || String(response?.raw?.geolocation?.address ?? '').trim();
        const uebernommeneAlarmierendeStelle = this.resolveAlarmierendeStelle(mapped.alarmierende_stelle);

        // Zusagende Mitglieder extrahieren
        const confirmedMemberIds = Array.isArray(mapped.mitglieder_ids) ? mapped.mitglieder_ids : [];

        this.formBericht.patchValue({
          einsatzart: uebernommeneEinsatzart || 'Sonstiges',
          alarmstichwort: uebernommenesStichwort,
          einsatzadresse: uebernommeneAdresse,
          alarmierendeStelle: uebernommeneAlarmierendeStelle,
          einsatzDatum: this.normalizeDateInput(mapped.einsatz_datum),
          ausgerueckt: mapped.ausgerueckt ?? '',
          mitglieder: confirmedMemberIds,
          lageBeimEintreffen: parsedAlarm.lageBeimEintreffen,
        });

        this.einsatzleiterSuche.setValue(this.formBericht.controls.einsatzleiter.value);

        this.updateConditionalValidation();
        if (confirmedMemberIds.length > 0) {
          this.uiMessageService.erstelleMessage('success', `Alarm übernommen. ${confirmedMemberIds.length} Mitglied(er) haben zugesagt.`);
        } else {
          this.uiMessageService.erstelleMessage('success', 'Letzter Alarm von BlaulichtSMS übernommen.');
        }
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  private parseBlaulichtAlarmtext(alarmtext: string): {
    einsatzart: string;
    alarmstichwort: string;
    einsatzadresse: string;
    lageBeimEintreffen: string;
  } {
    let text = this.normalizeAlarmText(alarmtext);
    if (!text) {
      return {
        einsatzart: '',
        alarmstichwort: '',
        einsatzadresse: '',
        lageBeimEintreffen: '',
      };
    }

    // 1. Zeitklammer entfernen: (HH:MM) oder (HH:MM:SS)
    text = text.replace(/\(\d{1,2}:\d{2}(?::\d{2})?\)\s*/g, '').trim();

    // 2. Stichwort: alles bis zum ersten Punkt
    const firstDotIndex = text.indexOf('.');
    let alarmstichwort = '';
    if (firstDotIndex > -1) {
      alarmstichwort = text.substring(0, firstDotIndex).trim();
    } else {
      alarmstichwort = text.trim();
    }

    // 4. Adresse: vom ersten Punkt bis zum ersten Doppelpunkt (falls vorhanden)
    let einsatzadresse = '';
    let lageBeimEintreffen = '';
    if (firstDotIndex > -1) {
      const afterDot = text.substring(firstDotIndex + 1).trim();
      const hasBMA = /\[BMA:/i.test(afterDot);
      const firstColonIndex = afterDot.indexOf(':');

      if (firstColonIndex > -1) {
        // Adresse bis zum Doppelpunkt
        einsatzadresse = afterDot.substring(0, firstColonIndex).trim();
        // Text nach dem Doppelpunkt → Lage beim Eintreffen (außer bei BMA-Meldungen)
        if (!hasBMA) {
          lageBeimEintreffen = afterDot.substring(firstColonIndex + 1).trim();
        }
      } else {
        // Kein Doppelpunkt: nimm alles nach dem Punkt, entferne Klammern + Koordinaten
        einsatzadresse = afterDot.replace(/\([^)]*\)/g, '').trim();
      }
    }

    // 5. Cleanup
    alarmstichwort = this.sanitizeAlarmstichwort(alarmstichwort).trim();
    einsatzadresse = this.removeCoordinates(einsatzadresse).trim();
    lageBeimEintreffen = this.removeCoordinates(lageBeimEintreffen).replace(/\(\s*\)/g, '').replace(/\s+/g, ' ').trim();

    // 6. Einsatzart nur aus dem finalen Alarmstichwort bestimmen
    const einsatzart = this.mapAlarmTextToEinsatzart(alarmstichwort);

    return {
      einsatzart,
      alarmstichwort,
      einsatzadresse,
      lageBeimEintreffen
    };
  }

  private normalizeAlarmText(value: string): string {
    return String(value ?? '')
      .replace(/\\r\\n|\\n|\\r/g, '\n')
      .replace(/\r\n?/g, '\n')
      .split('\n')
      .map((line) => line.replace(/\s+/g, ' ').trim())
      .filter((line) => line !== '')
      .join('\n')
      .trim();
  }

  private resolveAlarmierendeStelle(value: unknown): string {
    const normalized = String(value ?? '').replace(/\s+/g, ' ').trim();
    if (!normalized) {
      return 'AAZ / BAZ / LWZ';
    }

    if (/^IP_AG_[A-Z0-9_]+$/i.test(normalized)) {
      return 'AAZ / BAZ / LWZ';
    }

    if (/^(AAZ\s*\/\s*BAZ\s*\/\s*LWZ|AAZ|BAZ|LWZ|LEITSTELLE)$/i.test(normalized)) {
      return 'AAZ / BAZ / LWZ';
    }

    if (/^eigenalarmiert$/i.test(normalized)) {
      return 'Eigenalarmiert';
    }

    if (/^keine\s*alarmiert$/i.test(normalized)) {
      return 'Keine Alarmiert';
    }

    return normalized;
  }

  private sanitizeAlarmstichwort(value: string): string {
    const withoutDateAndTime = String(value ?? '')
      .replace(/\b\d{1,2}[./-]\d{1,2}[./-]\d{2,4}\b/g, ' ')
      .replace(/\b\d{1,2}:\d{2}(?::\d{2})?\s*(?:uhr)?\b/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    return this.cleanupAlarmSegment(withoutDateAndTime);
  }

  private toAlarmSegments(value: string): string[] {
    const segments: string[] = [];
    String(value ?? '')
      .split('\n')
      .map((line) => line.trim())
      .filter((line) => line !== '')
      .forEach((line) => {
        // Split nach ,;|. und ". " (Punkt + Leerzeichen), aber nicht bei Dezimalzahlen wie "km 1.4"
        line
          .split(/[,;|]|\.\s+/)
          .map((part) => part.trim())
          .filter((part) => part !== '')
          .forEach((part) => segments.push(part));
      });

    return segments;
  }

  private extractStichwortAndAdresse(
    segments: string[],
    fallbackText: string,
  ): { alarmstichwort: string; einsatzadresse: string } {
    let alarmstichwort = '';
    const adressSegmente: string[] = [];

    for (const rawSegment of segments) {
      const segment = this.cleanupAlarmSegment(rawSegment);
      if (!segment) {
        continue;
      }

      const labeledAddress = this.extractLabeledAddress(segment);
      if (labeledAddress) {
        if (!alarmstichwort && labeledAddress.alarmstichwort) {
          alarmstichwort = labeledAddress.alarmstichwort;
        }
        if (labeledAddress.einsatzadresse) {
          adressSegmente.push(labeledAddress.einsatzadresse);
        }
        continue;
      }

      const splitResult = this.trySplitSegment(segment);
      if (!alarmstichwort && splitResult.alarmstichwort) {
        alarmstichwort = splitResult.alarmstichwort;
      }
      if (splitResult.einsatzadresse) {
        adressSegmente.push(splitResult.einsatzadresse);
        continue;
      }

      const cleaned = this.cleanupAlarmSegment(this.removeLeadingAlarmToken(segment));
      if (!cleaned) {
        continue;
      }

      // Zuerst checken: ist es eine gültige Adresse (auch wenn Meta-Segment)?
      if (this.looksLikeAddress(cleaned)) {
        adressSegmente.push(cleaned);
        continue;
      }

      // Jetzt Meta-Segment checken (nur NACH Adresse-Check)
      if (this.isAlarmMetaSegment(cleaned)) {
        continue;
      }

      if (!alarmstichwort) {
        alarmstichwort = cleaned;
        continue;
      }

      if (adressSegmente.length > 0) {
        adressSegmente.push(cleaned);
      }
    }

    if (!alarmstichwort) {
      alarmstichwort = this.cleanupAlarmSegment(this.removeLeadingAlarmToken(fallbackText));
    }

    const einsatzadresse = this.uniqueAndJoinSegments(adressSegmente) || this.tryExtractAddressFromText(fallbackText);
    return {
      alarmstichwort,
      einsatzadresse,
    };
  }

  private uniqueAndJoinSegments(segments: string[]): string {
    const uniqueSegments = Array.from(
      new Set(
        segments
          .map((segment) => this.cleanupAlarmSegment(segment))
          .filter((segment) => segment !== ''),
      ),
    );
    return uniqueSegments.join(', ').trim();
  }

  private extractLabeledAddress(segment: string): { alarmstichwort: string; einsatzadresse: string } | null {
    const match = segment.match(/^(.*?)(?:\b(einsatzort|einsatzadresse|adresse|ort|objekt)\b)\s*[:-]\s*(.+)$/i);
    if (!match) {
      return null;
    }

    return {
      alarmstichwort: this.cleanupAlarmSegment(this.removeLeadingAlarmToken(match[1] ?? '')),
      einsatzadresse: this.cleanupAlarmSegment(match[3] ?? ''),
    };
  }

  private trySplitSegment(segment: string): { alarmstichwort: string; einsatzadresse: string } {
    const cleaned = this.cleanupAlarmSegment(segment);
    if (!cleaned) {
      return {
        alarmstichwort: '',
        einsatzadresse: '',
      };
    }

    const separators = [' - ', ':'];
    for (const separator of separators) {
      const splitIndex = cleaned.indexOf(separator);
      if (splitIndex <= 0 || splitIndex >= cleaned.length - separator.length) {
        continue;
      }

      const left = this.cleanupAlarmSegment(this.removeLeadingAlarmToken(cleaned.slice(0, splitIndex)));
      const right = this.cleanupAlarmSegment(cleaned.slice(splitIndex + separator.length));
      
      const leftIsAddress = left && this.looksLikeAddress(left);
      const rightIsAddress = right && this.looksLikeAddress(right);
      
      // Wenn beide aussehen wie Adresse: nimm left als stichwort + adresse
      if (leftIsAddress && rightIsAddress) {
        return {
          alarmstichwort: left,
          einsatzadresse: left,
        };
      }
      
      // Wenn rechts wie Adresse: right = Adresse, left = Stichwort
      if (rightIsAddress) {
        return {
          alarmstichwort: left || cleaned,
          einsatzadresse: right,
        };
      }
      
      // Wenn links wie Adresse: left = Adresse, right ignorieren (es ist beschreibung der adresse)
      if (leftIsAddress) {
        return {
          alarmstichwort: '',
          einsatzadresse: left,
        };
      }
    }

    return {
      alarmstichwort: this.cleanupAlarmSegment(this.removeLeadingAlarmToken(cleaned)),
      einsatzadresse: '',
    };
  }

  private tryExtractAddressFromText(value: string): string {
    const normalized = this.cleanupAlarmSegment(value);
    if (!normalized) {
      return '';
    }

    const postalCodeMatch = normalized.match(/\b\d{4}\s+[^,;|]{2,}\b/);
    if (postalCodeMatch) {
      return this.cleanupAlarmSegment(postalCodeMatch[0]);
    }

    const streetMatch = normalized.match(/\b[^,;|]{3,}\s(?:strasse|str\.|gasse|weg|platz|allee|ring|kai|hof|zeile)\s+\d+[A-Za-z0-9/-]*/i);
    if (streetMatch) {
      return this.cleanupAlarmSegment(streetMatch[0]);
    }

    const kilometerMatch = normalized.match(/\b[A-Z]?\d{1,3}\s+km\s*\d+(?:[.,]\d+)?\b/i);
    if (kilometerMatch) {
      return this.cleanupAlarmSegment(kilometerMatch[0]);
    }

    return '';
  }

  private extractAlarmToken(value: string): string {
    const match = String(value ?? '').match(/\b(BSW|[BTS])\s?(\d{1,2})([A-Z]?)\b/i);
    if (!match) {
      return '';
    }

    return `${(match[1] ?? '').toUpperCase()}${match[2] ?? ''}${(match[3] ?? '').toUpperCase()}`;
  }

  private removeLeadingTimeAndToken(value: string, alarmToken: string): string {
    let normalized = String(value ?? '').trim();

    // Zeit in voller Form: YYYY-MM-DD HH:MM(:SS)
    normalized = normalized.replace(/^\d{1,2}[./-]\d{1,2}[./-]\d{2,4}\s+\d{1,2}:\d{2}(?::\d{2})?\s*(?:uhr)?\s*[-|,:]?\s*/i, '');
    
    // Zeit nur: HH:MM(:SS), auch in Klammern
    normalized = normalized.replace(/^\(\d{1,2}:\d{2}(?::\d{2})?\)\s*[-|,:]?\s*/i, '');
    normalized = normalized.replace(/^\d{1,2}:\d{2}(?::\d{2})?\s*(?:uhr)?\s*[-|,:]?\s*/i, '');

    if (alarmToken) {
      const escapedToken = this.escapeRegex(alarmToken).replace(/([A-Za-z]+)(\d+)/, '$1\\s*$2');
      normalized = normalized.replace(new RegExp(`^${escapedToken}\\b\\s*[-|,:]?\\s*`, 'i'), '');
    }

    normalized = normalized.replace(/^(alarmierung|alarm|meldung)\s*[:-]\s*/i, '');
    return normalized.trim();
  }

  private escapeRegex(value: string): string {
    return String(value ?? '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  private cleanupAlarmSegment(value: string): string {
    const withoutUrls = String(value ?? '').replace(/https?:\/\/\S+/gi, ' ');
    const withoutCoords = this.removeCoordinates(withoutUrls);
    return withoutCoords
      .replace(/\s+/g, ' ')
      .replace(/^[,;|:-]+/, '')
      .replace(/[,;|:-]+$/, '')
      .replace(/\(\s*\)/g, '') // leere Klammern entfernen
      .trim();
  }

  private removeCoordinates(value: string): string {
    return String(value ?? '')
      .replace(/\b(?:koordinaten?|coords?)\b\s*[:=]?\s*\d{1,2}[.,]\d{3,}\s*[,/ ]\s*\d{1,3}[.,]\d{3,}\b/gi, ' ')
      .replace(/\b\d{1,2}[.,]\d{3,}\s*[,/ ]\s*\d{1,3}[.,]\d{3,}\b/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  private isAlarmMetaSegment(value: string): boolean {
    const normalized = String(value ?? '').trim();
    if (!normalized) {
      return true;
    }

    if (this.isCoordinateOnlySegment(normalized)) {
      return true;
    }

    if (/^https?:\/\//i.test(normalized)) {
      return true;
    }

    if (/^(alarmzeit|zeit|datum|einsatznr|einsatznummer|objektid|objektnummer|id|alarmierung|blaulichtsms)\b/i.test(normalized)) {
      return true;
    }

    if (/^(?:IP_AG_[A-Z0-9_]+|AAZ\s*\/\s*BAZ\s*\/\s*LWZ|AAZ|BAZ|LWZ|LEITSTELLE)\b/i.test(normalized)) {
      return true;
    }

    if (/^\d{1,2}:\d{2}(?::\d{2})?$/.test(normalized)) {
      return true;
    }

    if (/^(?:BSW|[BTS])\s?\d{1,2}[A-Z]?$/i.test(normalized)) {
      return true;
    }

    return false;
  }

  private isCoordinateOnlySegment(value: string): boolean {
    return /^\d{1,2}[.,]\d{3,}\s*[,/ ]\s*\d{1,3}[.,]\d{3,}$/.test(String(value ?? '').trim());
  }

  private removeLeadingAlarmToken(value: string): string {
    const normalized = String(value ?? '').replace(/\s+/g, ' ').trim();
    if (!normalized) {
      return '';
    }

    const withoutTime = normalized.replace(/^\d{1,2}:\d{2}(?::\d{2})?\s*(?:uhr)?\s*[-|,:]?\s*/i, '').trim();
    const tokenMatch = withoutTime.match(/^(BSW|[BTS])\s?(\d{1,2})([A-Z]?)\b\s*[-|,:]?\s*/i);
    if (tokenMatch) {
      return withoutTime.slice(tokenMatch[0].length).trim();
    }

    return withoutTime;
  }

  private looksLikeAddress(value: string): boolean {
    const normalized = this.cleanupAlarmSegment(value);
    if (!normalized || this.isCoordinateOnlySegment(normalized)) {
      return false;
    }

    // Keine Beschreibungswoerter (Aktionswoerter am Anfang)
    if (/^(?:auf|an|in|zu|bei|von|durch|unter|ueber|aus|hat|ist|wird|befindet|liegt|gegen)\b/i.test(normalized)) {
      return false;
    }

    // PLZ-Pattern (4 Ziffern)
    if (/\b\d{4}\b/.test(normalized)) {
      return true;
    }

    // Kilometer/L-Strasse (L2004 km 1.4) - hohe Konfidenz
    if (/\b(?:L\d+|km\s*\d)/i.test(normalized)) {
      return true;
    }

    // Strasse mit Hausnummer Pattern ("Weinbergstrasse 21") - hohe Konfidenz
    if (/\b[A-Za-z][A-Za-z.'\- ]+\s+\d{1,4}[A-Za-z0-9/-]*\b/i.test(normalized)) {
      return true;
    }

    // Strasse-Name allein nur akzeptieren, wenn kombiniert mit Hausnummer oder km
    if (/\b(?:strasse|str\.|gasse|weg|platz|allee|ring|kai|hof|siedlung|zeile)\b/i.test(normalized)) {
      if (/\d{1,4}|km|L\d+/i.test(normalized)) {
        return true;
      }
    }

    return false;
  }

  private mapAlarmTokenToEinsatzart(token: string): string {
    if (!token) {
      return '';
    }

    const normalizedToken = token.replace(/\s+/g, '').toUpperCase();

    if (/^BSW\d*[A-Z]*$/.test(normalizedToken)) {
      return 'Brandsicherheitswache';
    }
    if (/^B\d*[A-Z]*$/.test(normalizedToken)) {
      return 'Brandeinsatz';
    }
    if (/^T\d*[A-Z]*$/.test(normalizedToken)) {
      return 'Technischer Einsatz';
    }
    if (/^S\d*[A-Z]*$/.test(normalizedToken)) {
      return 'Schadstoffeinsatz';
    }

    return '';
  }

  private mapAlarmTextToEinsatzart(alarmtext: string): string {
    const value = String(alarmtext ?? '');
    if (!value) {
      return '';
    }

    if (/\b(?:BSW\s?\d*|brandsicherheitswache)\b/i.test(value)) {
      return 'Brandsicherheitswache';
    }

    if (/\b(?:S\s?\d+|schadstoff|gefahrgut|chemikal|gasaustritt|oelaustritt)\b/i.test(value)) {
      return 'Schadstoffeinsatz';
    }

    if (/\b(?:B\s?\d+|brand|rauch|feuer|bma|brandmeldeanlage)\b/i.test(value)) {
      return 'Brandeinsatz';
    }

    if (/\b(?:T\s?\d+|verkehrsunfall|vku|bergung|sturmschaden|tueroeffnung|tierrettung|anforderung|hilfeleistung|wasserschaden)\b/i.test(value)) {
      return 'Technischer Einsatz';
    }

    return '';
  }

  berichtBearbeiten(bericht: EinsatzberichtDto): void {
    this.viewMode = 'form';
    this.formBericht.patchValue({
      id: bericht.id,
      status: bericht.status || 'ENTWURF',
      einsatzleiter: bericht.einsatzleiter || '',
      einsatzart: bericht.einsatzart || '',
      alarmstichwort: bericht.alarmstichwort || '',
      einsatzadresse: bericht.einsatzadresse || '',
      alarmierendeStelle: bericht.alarmierende_stelle || '',
      einsatzDatum: this.normalizeDateInput(bericht.einsatz_datum),
      ausgerueckt: bericht.ausgerueckt || '',
      eingerueckt: bericht.eingerueckt || '',
      lageBeimEintreffen: bericht.lage_beim_eintreffen || '',
      gesetzteMassnahmen: bericht.gesetzte_massnahmen || '',
      brandKategorie: bericht.brand_kategorie || '',
      brandAus: bericht.brand_aus || '',
      technischKategorie: bericht.technisch_kategorie || '',
      bmaMeldergruppe: bericht.bma_meldergruppe || '',
      bmaMelder: bericht.bma_melder || '',
      bmaFehlTauschungsalarm: this.toBmaFehlTaeuschungsalarmSelectValue(bericht.bma_fehl_tauschungsalarm),
      mitalarmiert: this.resolveMitalarmiertSelectValue(bericht.mitalarmiert),
      fahrzeuge: bericht.fahrzeuge || [],
      mitglieder: bericht.mitglieder || [],
    });

    this.bestehendeFotos = (bericht.fotos || []);
    this.einsatzleiterSuche.setValue(this.formBericht.controls.einsatzleiter.value);
    this.resetSuchfilter();
    this.resetDokumentUploads();

    this.updateConditionalValidation();
    this.applyFormAccessState();
  }

  zurueckZurListe(): void {
    this.viewMode = 'list';
    this.ladeBerichte();
  }

  statusUmschalten(bericht: EinsatzberichtDto): void {
    if (!this.canManageStatus) {
      this.uiMessageService.erstelleMessage('error', 'Nur Admin oder Verwaltung duerfen den FDISK-Status setzen.');
      return;
    }

    if (bericht.status !== 'GESENDET') {
      this.uiMessageService.erstelleMessage('error', 'FDISK kann nur fuer gesendete Berichte gesetzt werden.');
      return;
    }

    this.apiHttpService.post<EinsatzberichtDto>(`einsatzberichte/${bericht.id}/fdisk-eingetragen`, {}, false).subscribe({
      next: () => {
        if (this.formBericht.controls.id.value === bericht.id) {
          this.formBericht.controls.status.setValue('FDISK_EINGETRAGEN');
        }
        this.uiMessageService.erstelleMessage('success', 'Status auf FDISK eingetragen gesetzt.');
        this.ladeBerichte();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  berichtLoeschen(bericht: EinsatzberichtDto): void {
    if (!this.canDeleteBerichte) {
      this.uiMessageService.erstelleMessage('error', 'Keine Berechtigung zum Löschen.');
      return;
    }

    const confirmDelete = window.confirm(`Einsatzbericht "${bericht.alarmstichwort || bericht.id}" wirklich löschen?`);
    if (!confirmDelete) {
      return;
    }

    this.apiHttpService.delete('einsatzberichte', bericht.id).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Einsatzbericht gelöscht.');
        this.ladeBerichte();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  onDokumentSelected(event: Event, dokumentTyp: 'fotoDoku' | 'zulassungsschein' | 'versicherungsschein'): void {
    if (this.isReportReadOnly) {
      return;
    }
    const input = event.target as HTMLInputElement;
    const files = input.files ? Array.from(input.files) : [];
    const fileNames = files.map((file) => file.name);

    if (dokumentTyp === 'fotoDoku') {
      this.fotoDokuFiles = files;
      this.fotoDokuDateien = fileNames;
      return;
    }

    if (dokumentTyp === 'zulassungsschein') {
      this.zulassungFiles = files;
      this.zulassungDateien = fileNames;
      return;
    }

    this.versicherungFiles = files;
    this.versicherungDateien = fileNames;
  }

  onEinsatzleiterSelected(event: MatAutocompleteSelectedEvent): void {
    if (this.isReportReadOnly) {
      return;
    }
    const value = String(event.option.value || '').trim();
    this.formBericht.controls.einsatzleiter.setValue(value);
    this.einsatzleiterSuche.setValue(value);
  }

  onFahrzeugSelected(event: MatAutocompleteSelectedEvent): void {
    if (this.isReportReadOnly) {
      return;
    }
    const id = Number(event.option.value);
    const current = this.formBericht.controls.fahrzeuge.value;
    if (!current.includes(id)) {
      this.formBericht.controls.fahrzeuge.setValue([...current, id]);
    }
    this.fahrzeugSuche.setValue('');
  }

  removeFahrzeug(id: number): void {
    if (this.isReportReadOnly) {
      return;
    }
    const next = this.formBericht.controls.fahrzeuge.value.filter((x) => x !== id);
    this.formBericht.controls.fahrzeuge.setValue(next);
  }

  onMitalarmiertSelected(event: MatAutocompleteSelectedEvent): void {
    if (this.isReportReadOnly) {
      return;
    }
    const optionId = Number(event.option.value);
    if (!optionId) {
      return;
    }

    const current = this.formBericht.controls.mitalarmiert.value;
    if (!current.includes(optionId)) {
      this.formBericht.controls.mitalarmiert.setValue([...current, optionId]);
    }

    this.mitalarmiertSuche.setValue('');
  }

  removeMitalarmiert(optionId: number): void {
    if (this.isReportReadOnly) {
      return;
    }
    const next = this.formBericht.controls.mitalarmiert.value.filter((entry) => entry !== optionId);
    this.formBericht.controls.mitalarmiert.setValue(next);
  }

  private resetDokumentUploads(): void {
    this.filePreviewUrlMap.forEach((url) => URL.revokeObjectURL(url));
    this.filePreviewUrlMap.clear();

    this.fotoDokuDateien = [];
    this.fotoDokuFiles = [];
    this.zulassungDateien = [];
    this.zulassungFiles = [];
    this.versicherungDateien = [];
    this.versicherungFiles = [];
  }

  private resetSuchfilter(): void {
    if (!this.formBericht.controls.einsatzleiter.value) {
      this.einsatzleiterSuche.setValue('');
    }
    this.fahrzeugSuche.setValue('');
    this.mitalarmiertSuche.setValue('');
  }

  speichereBericht(): void {
    this.speichereEntwurf();
  }

  speichereEntwurf(onSuccess?: () => void): void {
    if (!this.canEditBerichte) {
      this.uiMessageService.erstelleMessage('error', 'Nur Bericht, Admin oder Verwaltung duerfen Inhalte speichern.');
      return;
    }

    if (this.isReportReadOnly) {
      this.uiMessageService.erstelleMessage('error', 'Dieser Einsatzbericht ist gesendet und nur für Admin/Verwaltung bearbeitbar.');
      return;
    }

    if (this.formBericht.invalid) {
      this.formBericht.markAllAsTouched();
      this.uiMessageService.erstelleMessage('error', 'Bitte alle Pflichtfelder korrekt ausfüllen.');
      return;
    }

    const form = this.formBericht.getRawValue();
    const payloadForm = this.withStatistikFallbackValues(form);
    const berichtId = form.id;
    const nextStatus = this.canManageStatus ? payloadForm.status : 'ENTWURF';

    const fd = new FormData();
    fd.append('status', nextStatus);
    fd.append('einsatzleiter', payloadForm.einsatzleiter);
    fd.append('einsatzart', payloadForm.einsatzart);
    fd.append('alarmstichwort', payloadForm.alarmstichwort);
    fd.append('einsatzadresse', payloadForm.einsatzadresse);
    fd.append('alarmierende_stelle', payloadForm.alarmierendeStelle);
    fd.append('einsatz_datum', this.formatDateForApi(payloadForm.einsatzDatum));
    fd.append('ausgerueckt', payloadForm.ausgerueckt || '');
    fd.append('eingerueckt', payloadForm.eingerueckt || '');
    fd.append('lage_beim_eintreffen', payloadForm.lageBeimEintreffen);
    fd.append('gesetzte_massnahmen', payloadForm.gesetzteMassnahmen);
    fd.append('brand_kategorie', this.isBrand ? (payloadForm.brandKategorie || '') : '');
    fd.append('brand_aus', this.isBrand ? (payloadForm.brandAus || '') : '');
    fd.append('technisch_kategorie', payloadForm.technischKategorie || '');
    fd.append('bma_meldergruppe', this.isBMA ? (payloadForm.bmaMeldergruppe || '') : '');
    fd.append('bma_melder', this.isBMA ? (payloadForm.bmaMelder || '') : '');
    fd.append('bma_fehl_tauschungsalarm', this.isBMA ? this.toBmaFehlTaeuschungsalarmApiValue(payloadForm.bmaFehlTauschungsalarm) : '');
    payloadForm.mitalarmiert.forEach((stelleId) => fd.append('mitalarmiert', String(stelleId)));

    payloadForm.fahrzeuge.forEach((fahrzeugId) => fd.append('fahrzeuge', String(fahrzeugId)));
    payloadForm.mitglieder.forEach((mitgliedId) => fd.append('mitglieder', String(mitgliedId)));
    this.fotoDokuFiles.forEach((foto) => fd.append('fotos_doku', foto));
    this.zulassungFiles.forEach((foto) => fd.append('fotos_zulassung', foto));
    this.versicherungFiles.forEach((foto) => fd.append('fotos_versicherung', foto));

    const request$ = berichtId
      ? this.apiHttpService.patch<SaveEinsatzberichtResponse>('einsatzberichte', berichtId, fd, true)
      : this.apiHttpService.post<SaveEinsatzberichtResponse>('einsatzberichte', fd, true);

    request$.subscribe({
      next: (saved) => {
        this.formBericht.controls.id.setValue(saved?.id ?? berichtId ?? '');
        this.formBericht.controls.status.setValue(saved?.status ?? nextStatus);
        this.applyFormAccessState();
        if (onSuccess) {
          onSuccess();
          return;
        }
        this.uiMessageService.erstelleMessage('success', 'Einsatzbericht gespeichert.');
        this.ladeBerichte();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  sendeBerichtMitVorschau(): void {
    if (!this.canEditBerichte) {
      this.uiMessageService.erstelleMessage('error', 'Nur Bericht oder Admin dürfen senden.');
      return;
    }

    if (!this.canSendWorkflowReady) {
      this.uiMessageService.erstelleMessage('error', 'PDF-Vorlage oder Empf#nger in den Einstellungen fehlt.');
      return;
    }

    if (this.formBericht.invalid) {
      this.formBericht.markAllAsTouched();
      this.uiMessageService.erstelleMessage('error', 'Bitte alle Pflichtfelder korrekt ausfüllen.');
      return;
    }

    const previewData = this.buildSendPreviewData();
    this.dialog.open(EinsatzberichtSendPreviewDialogComponent, {
      width: '760px',
      maxWidth: '95vw',
      maxHeight: '90vh',
      panelClass: 'imr-dialog-sharp',
      data: previewData,
    }).afterClosed().subscribe((confirmed: boolean | undefined) => {
      if (!confirmed) {
        return;
      }

      this.speichereEntwurf(() => {
        const berichtId = this.formBericht.controls.id.value;
        if (!berichtId) {
          this.uiMessageService.erstelleMessage('error', 'Entwurf konnte nicht gespeichert werden.');
          return;
        }

        this.apiHttpService.post<EinsatzberichtDto>(`einsatzberichte/${berichtId}/senden`, {}, false).subscribe({
          next: () => {
            this.formBericht.controls.status.setValue('GESENDET');
            this.applyFormAccessState();
            this.uiMessageService.erstelleMessage('success', 'Einsatzbericht wurde gesendet und als PDF per E-Mail verschickt.');
            this.ladeBerichte();
            this.viewMode = 'list';
          },
          error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
        });
      });
    });
  }

  private buildSendPreviewData(): EinsatzberichtSendPreviewDialogData {
    const form = this.formBericht.getRawValue();
    const fahrzeuge = this.selectedFahrzeugOptionen.map((item) => item.label).join(', ');
    const mitgliederListe = this.selectedMitgliedOptionen.map((item) => item.label);
    const mitalarmiert = this.selectedMitalarmiertOptionen.map((item) => item.label).join(', ');
    const einsatzDatumFormatted = this.formatDateForPreview(form.einsatzDatum);

    const previewCandidates: Array<{ label: string; value: string | null | undefined }> = [
      { label: 'Einsatzleiter', value: form.einsatzleiter },
      { label: 'Einsatzart', value: form.einsatzart },
      { label: 'Alarmstichwort', value: form.alarmstichwort },
      { label: 'Einsatzadresse', value: form.einsatzadresse },
      { label: 'Alarmierende Stelle', value: form.alarmierendeStelle },
      { label: 'Einsatzdatum', value: einsatzDatumFormatted },
      { label: 'Ausgerückt', value: form.ausgerueckt },
      { label: 'Eingerückt', value: form.eingerueckt },
      { label: 'Lage beim Eintreffen', value: form.lageBeimEintreffen },
      { label: 'Gesetzte Maßnahmen', value: form.gesetzteMassnahmen },
      { label: 'Brand Kategorie', value: form.brandKategorie },
      { label: 'Brand aus', value: form.brandAus },
      { label: 'Technische Kategorie', value: form.technischKategorie },
      { label: 'Meldergruppe', value: form.bmaMeldergruppe },
      { label: 'Melder', value: form.bmaMelder },
      { label: 'Fehl- oder Täuschungsalarm', value: form.bmaFehlTauschungsalarm },
      { label: 'Mitalarmiert', value: mitalarmiert },
      { label: 'Fahrzeuge', value: fahrzeuge },
    ];

    const items = previewCandidates
      .map((item) => {
        const normalizedValue = this.toPreviewValue(item.value);
        if (!normalizedValue) {
          return null;
        }
        return { label: item.label, value: normalizedValue };
      })
      .filter((item): item is { label: string; value: string } => item !== null);

    return {
      recipientLabel: this.resolveConfiguredRecipientLabel(),
      mitgliederListe,
      items,
    };
  }

  private toPreviewValue(value: string | null | undefined): string | null {
    const normalized = String(value ?? '').trim();
    if (!normalized || normalized === this.BMA_FEHL_TAEUSCHUNGSALARM_NONE) {
      return null;
    }
    return normalized;
  }

  private formatDateForPreview(date: string | null | undefined): string | null {
    if (!date || typeof date !== 'string') {
      return null;
    }
    // Convert ISO format (YYYY-MM-DD) to German format (DD.MM.YYYY)
    const match = date.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) {
      return date; // Return as-is if format doesn't match
    }
    const [, year, month, day] = match;
    return `${day}.${month}.${year}`;
  }

  private resolveConfiguredRecipientLabel(): string {
    const userId = this.stringOrNull(this.pdf_konfig.einsatzberichtEmpfaengerUserId);
    if (userId !== null) {
      const user = this.userOptionen.find((u) => u.id === userId);
      if (user) return `${user.display} <${user.email}>`;
    }
    return 'E-Mail aus Stammdaten (Fallback)';
  }

  private updateConditionalValidation(): void {
    const einsatzleiter = this.formBericht.controls.einsatzleiter;
    const einsatzart = this.formBericht.controls.einsatzart;
    const alarmstichwort = this.formBericht.controls.alarmstichwort;
    const einsatzadresse = this.formBericht.controls.einsatzadresse;
    const alarmierendeStelle = this.formBericht.controls.alarmierendeStelle;
    const einsatzDatum = this.formBericht.controls.einsatzDatum;
    const ausgerueckt = this.formBericht.controls.ausgerueckt;
    const eingerueckt = this.formBericht.controls.eingerueckt;
    const lageBeimEintreffen = this.formBericht.controls.lageBeimEintreffen;
    const gesetzteMassnahmen = this.formBericht.controls.gesetzteMassnahmen;
    const mitglieder = this.formBericht.controls.mitglieder;
    const brandKategorie = this.formBericht.controls.brandKategorie;
    const brandAus = this.formBericht.controls.brandAus;
    const technischKategorie = this.formBericht.controls.technischKategorie;
    const bmaMeldergruppe = this.formBericht.controls.bmaMeldergruppe;
    const bmaMelder = this.formBericht.controls.bmaMelder;
    const bmaFehlTauschungsalarm = this.formBericht.controls.bmaFehlTauschungsalarm;

    const requiredForNormalMode = [
      einsatzleiter,
      einsatzart,
      alarmstichwort,
      einsatzadresse,
      alarmierendeStelle,
      einsatzDatum,
      ausgerueckt,
      eingerueckt,
      lageBeimEintreffen,
      gesetzteMassnahmen,
    ];

    requiredForNormalMode.forEach((control) => control.clearValidators());
    mitglieder.clearValidators();

    if (this.isStatistikStatus) {
      einsatzDatum.setValidators([Validators.required, this.einsatzDatumFormatValidator]);
      ausgerueckt.setValidators([Validators.required]);
      mitglieder.setValidators([Validators.required]);
    } else {
      requiredForNormalMode.forEach((control) => {
        if (control === einsatzDatum) {
          control.setValidators([Validators.required, this.einsatzDatumFormatValidator]);
          return;
        }
        control.setValidators([Validators.required]);
      });
    }

    brandKategorie.clearValidators();
    brandAus.clearValidators();
    technischKategorie.clearValidators();

    if (this.isBrand) {
      if (technischKategorie.value) {
        technischKategorie.setValue('', { emitEvent: false });
      }
    } else {
      if (brandKategorie.value) {
        brandKategorie.setValue('', { emitEvent: false });
      }
      if (brandAus.value) {
        brandAus.setValue('', { emitEvent: false });
      }
    }

    if (this.isTechnisch) {
      if (brandKategorie.value) {
        brandKategorie.setValue('', { emitEvent: false });
      }
    } else {
      if (technischKategorie.value) {
        technischKategorie.setValue('', { emitEvent: false });
      }
    }

    if (!this.isBMA) {
      if (bmaMeldergruppe.value) {
        bmaMeldergruppe.setValue('', { emitEvent: false });
      }
      if (bmaMelder.value) {
        bmaMelder.setValue('', { emitEvent: false });
      }
      if (bmaFehlTauschungsalarm.value !== this.BMA_FEHL_TAEUSCHUNGSALARM_NONE) {
        bmaFehlTauschungsalarm.setValue(this.BMA_FEHL_TAEUSCHUNGSALARM_NONE, { emitEvent: false });
      }
    } else if (!bmaFehlTauschungsalarm.value) {
      bmaFehlTauschungsalarm.setValue(this.BMA_FEHL_TAEUSCHUNGSALARM_NONE, { emitEvent: false });
    }

    brandKategorie.updateValueAndValidity({ emitEvent: false });
    brandAus.updateValueAndValidity({ emitEvent: false });
    technischKategorie.updateValueAndValidity({ emitEvent: false });
    requiredForNormalMode.forEach((control) => control.updateValueAndValidity({ emitEvent: false }));
    mitglieder.updateValueAndValidity({ emitEvent: false });
  }

  private applyFormAccessState(): void {
    if (this.isReportReadOnly) {
      this.formBericht.disable({ emitEvent: false });
      this.einsatzleiterSuche.disable({ emitEvent: false });
      this.fahrzeugSuche.disable({ emitEvent: false });
      this.mitgliedSuche.disable({ emitEvent: false });
      this.mitalarmiertSuche.disable({ emitEvent: false });
      return;
    }

    this.formBericht.enable({ emitEvent: false });
    this.einsatzleiterSuche.enable({ emitEvent: false });
    this.fahrzeugSuche.enable({ emitEvent: false });
    this.mitgliedSuche.enable({ emitEvent: false });
    this.mitalarmiertSuche.enable({ emitEvent: false });

    if (!this.canManageStatus) {
      this.formBericht.controls.status.disable({ emitEvent: false });
    }
  }

  private withStatistikFallbackValues(
    form: ReturnType<typeof this.formBericht.getRawValue>,
  ): ReturnType<typeof this.formBericht.getRawValue> {
    if (form.status !== this.STATISTIK_STATUS) {
      return form;
    }

    return {
      ...form,
      einsatzleiter: form.einsatzleiter || this.statistikFallbackValues.einsatzleiter,
      einsatzart: form.einsatzart || this.statistikFallbackValues.einsatzart,
      alarmstichwort: form.alarmstichwort || this.statistikFallbackValues.alarmstichwort,
      einsatzadresse: form.einsatzadresse || this.statistikFallbackValues.einsatzadresse,
      alarmierendeStelle: form.alarmierendeStelle || this.statistikFallbackValues.alarmierendeStelle,
      eingerueckt: form.eingerueckt || this.statistikFallbackValues.eingerueckt,
      lageBeimEintreffen: form.lageBeimEintreffen || this.statistikFallbackValues.lageBeimEintreffen,
      gesetzteMassnahmen: form.gesetzteMassnahmen || this.statistikFallbackValues.gesetzteMassnahmen,
    };
  }

  private normalizeMitalarmiertValues(value: unknown): number[] {
    if (Array.isArray(value)) {
      return value
        .map((entry) => Number(entry))
        .filter((entry) => Number.isFinite(entry) && entry > 0);
    }
    return [];
  }

  private toBmaFehlTaeuschungsalarmSelectValue(value: string | null | undefined): string {
    const normalized = String(value ?? '').trim();
    return normalized || this.BMA_FEHL_TAEUSCHUNGSALARM_NONE;
  }

  private toBmaFehlTaeuschungsalarmApiValue(value: string | null | undefined): string {
    const normalized = String(value ?? '').trim();
    if (!normalized || normalized === this.BMA_FEHL_TAEUSCHUNGSALARM_NONE) {
      return '';
    }
    return normalized;
  }

  private resolveMitalarmiertSelectValue(value: unknown): number[] {
    return Array.from(new Set(this.normalizeMitalarmiertValues(value)));
  }

  toggleSettings(): void {
    this.settingsPanelOpen = !this.settingsPanelOpen;
  }

  saveSettings(): void {
    if (!this.isAdmin) {
      return;
    }

    const payload = {
      modul: 'pdf',
      konfiguration: {
        ...this.pdf_konfig,
        idEinsatzberichtPdf: this.stringOrNull(this.formSettings.controls.idEinsatzberichtPdf.value),
        einsatzberichtEmpfaengerUserId: this.stringOrNull(this.formSettings.controls.einsatzberichtEmpfaengerUserId.value),
      },
    };

    if (this.pdfKonfigId) {
      this.apiHttpService.patch<EinsatzberichteModulKonfigItem>(this.modulKonfigurationEndpoint, this.pdfKonfigId, payload, false).subscribe({
        next: (saved) => {
          this.applySavedPdfKonfig(saved);
          this.uiMessageService.erstelleMessage('success', 'PDF-Zuweisung gespeichert.');
        },
        error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
      });
      return;
    }

    this.apiHttpService.post<EinsatzberichteModulKonfigItem>(this.modulKonfigurationEndpoint, payload, false).subscribe({
      next: (saved) => {
        this.applySavedPdfKonfig(saved);
        this.uiMessageService.erstelleMessage('success', 'PDF-Zuweisung gespeichert.');
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  resetSettings(): void {
    this.syncSettingsForm();
  }

  private loadSettingsContext(): void {
    this.apiHttpService.get<EinsatzberichteModulKonfigResponse>(this.modulKonfigurationEndpoint).subscribe({
      next: (erg) => {
        const eintraege = this.normalizeModulKonfigEntries(erg);
        const pdfEntry = eintraege
          .filter((item) => String(item.modul ?? '').trim().toLowerCase() === 'pdf')
          .sort((a, b) => String(b.updated_at ?? '').localeCompare(String(a.updated_at ?? '')))[0];
        this.pdfKonfigId = this.stringOrNull(pdfEntry?.id);
        this.pdf_konfig = (pdfEntry?.konfiguration ?? this.pdf_konfig ?? {}) as EinsatzberichtePdfKonfig;
        this.syncSettingsForm();
        this.loadPdfTemplatesOnce();
      },
      error: () => {
        this.pdfKonfigId = null;
        this.syncSettingsForm();
      },
    });
  }

  private loadPdfTemplatesOnce(): void {
    if (this.pdfTemplatesLoaded) {
      return;
    }

    this.apiHttpService.get<EinsatzberichtePdfTemplatesResponse>('pdf/templates').subscribe({
      next: (erg) => {
        this.pdfTemplates = Array.isArray(erg) ? erg : (erg.main ?? []);
        this.pdfTemplatesLoaded = true;
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  private syncSettingsForm(): void {
    this.formSettings.patchValue({
      idEinsatzberichtPdf: this.stringOrNull(this.pdf_konfig.idEinsatzberichtPdf),
      einsatzberichtEmpfaengerUserId: this.stringOrNull(this.pdf_konfig.einsatzberichtEmpfaengerUserId),
    }, { emitEvent: false });
    this.formSettings.markAsPristine();
    this.formSettings.markAsUntouched();
  }

  private applySavedPdfKonfig(saved: EinsatzberichteModulKonfigItem): void {
    this.pdfKonfigId = this.stringOrNull(saved.id);
    this.pdf_konfig = (saved.konfiguration ?? {}) as EinsatzberichtePdfKonfig;
    this.syncSettingsForm();
  }

  private normalizeModulKonfigEntries(payload: unknown): EinsatzberichteModulKonfigItem[] {
    if (Array.isArray(payload)) {
      return payload as EinsatzberichteModulKonfigItem[];
    }

    if (payload && typeof payload === 'object') {
      const main = (payload as { main?: unknown }).main;
      if (Array.isArray(main)) {
        return main as EinsatzberichteModulKonfigItem[];
      }
    }

    return [];
  }

  private stringOrNull(value: unknown): string | null {
    if (value === null || value === undefined || value === '') {
      return null;
    }

    return String(value);
  }

  private numberOrNull(value: unknown): number | null {
    if (value === null || value === undefined || value === '') {
      return null;
    }

    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed <= 0) {
      return null;
    }

    return parsed;
  }

  druckeBericht(element: EinsatzberichtDto): void {
    if (!this.canPrintBericht) {
      this.uiMessageService.erstelleMessage('error', 'Druck ist nur für Rollen ADMIN und VERWALTUNG verfügbar.');
      return;
    }

    const templateId = this.stringOrNull(this.pdf_konfig.idEinsatzberichtPdf);
    if (!templateId) {
      this.uiMessageService.erstelleMessage('error', 'Kein PDF-Template für Einsatzbericht in den Einstellungen hinterlegt.');
      return;
    }

    this.apiHttpService.post<Record<string, unknown>>(`einsatzberichte/${element.id}/pdf-payload`, {}).pipe(
      switchMap((payload) => this.apiHttpService.postBlob(`pdf/templates/${templateId}/render`, payload)),
    ).subscribe({
      next: (blob: Blob) => {
        if (blob.size === 0) {
          this.uiMessageService.erstelleMessage('error', 'PDF ist leer (0 Bytes).');
          return;
        }
        const url = URL.createObjectURL(blob);
        window.open(url, '_blank');
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }
}
