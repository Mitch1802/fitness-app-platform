import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ImrSectionComponent } from '../imr-ui-library';

export type EinsatzberichtSendPreviewItem = {
  label: string;
  value: string;
};

export type EinsatzberichtSendPreviewDialogData = {
  recipientLabel: string;
  items: EinsatzberichtSendPreviewItem[];
  mitgliederListe?: string[];
};

@Component({
  selector: 'app-einsatzbericht-send-preview-dialog',
  standalone: true,
  imports: [MatDialogModule, MatButtonModule, MatIconModule, ImrSectionComponent],
  templateUrl: './einsatzbericht-send-preview-dialog.component.html',
  styleUrl: './einsatzbericht-send-preview-dialog.component.sass',
})
export class EinsatzberichtSendPreviewDialogComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: EinsatzberichtSendPreviewDialogData) {}
}
