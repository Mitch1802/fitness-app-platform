export const TABLE_PAGINATION_PAGE_SIZE_OPTIONS = {
  standard: [10, 50, 100],
  compact: [5, 10, 20, 50],
} as const;

export const TABLE_PAGINATION_DEFAULT_PAGE_SIZE = {
  standard: 10,
  compact: 5,
} as const;
