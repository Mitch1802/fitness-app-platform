﻿export const normalizeDateInput = (value: string | null | undefined): string => {
  if (!value) {
    return '';
  }

  const stringValue = String(value).trim();
  if (stringValue === '') {
    return '';
  }

  if (/^\d{4}-\d{2}-\d{2}$/.test(stringValue)) {
    return stringValue;
  }

  if (/^\d{2}\.\d{2}\.\d{4}$/.test(stringValue)) {
    const [day, month, year] = stringValue.split('.');
    return `${year}-${month}-${day}`;
  }

  const dayFirstMatch = stringValue.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
  if (dayFirstMatch) {
    const day = Number(dayFirstMatch[1]);
    const month = Number(dayFirstMatch[2]);
    const year = Number(dayFirstMatch[3]);
    const parsed = new Date(year, month - 1, day);

    if (
      parsed.getFullYear() === year &&
      parsed.getMonth() === month - 1 &&
      parsed.getDate() === day
    ) {
      return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }
    return '';
  }

  const yearFirstMatch = stringValue.match(/^(\d{4})[./-](\d{1,2})[./-](\d{1,2})$/);
  if (yearFirstMatch) {
    const year = Number(yearFirstMatch[1]);
    const month = Number(yearFirstMatch[2]);
    const day = Number(yearFirstMatch[3]);
    const parsed = new Date(year, month - 1, day);

    if (
      parsed.getFullYear() === year &&
      parsed.getMonth() === month - 1 &&
      parsed.getDate() === day
    ) {
      return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }
    return '';
  }

  if (stringValue.includes('T')) {
    const isoDate = stringValue.split('T')[0];
    if (/^\d{4}-\d{2}-\d{2}$/.test(isoDate)) {
      return isoDate;
    }
  }

  return '';
};

export const formatDateOutput = (value: string | Date | null | undefined): string => {
  if (value === null || value === undefined) {
    return '';
  }

  if (value instanceof Date) {
    if (Number.isNaN(value.getTime())) {
      return '';
    }
    const day = String(value.getDate()).padStart(2, '0');
    const month = String(value.getMonth() + 1).padStart(2, '0');
    return `${day}.${month}.${value.getFullYear()}`;
  }

  const raw = String(value).trim();
  if (raw === '') {
    return '';
  }

  const normalizedIso = normalizeDateInput(raw);
  if (!normalizedIso) {
    return '';
  }

  const [year, month, day] = normalizedIso.split('-');
  return `${day}.${month}.${year}`;
};
