import { formatDateOutput, normalizeDateInput } from './date-normalization.util';

describe('normalizeDateInput', () => {
  it('returns empty string for null-like values', () => {
    expect(normalizeDateInput(undefined)).toBe('');
    expect(normalizeDateInput(null)).toBe('');
    expect(normalizeDateInput('')).toBe('');
    expect(normalizeDateInput('   ')).toBe('');
  });

  it('keeps YYYY-MM-DD values unchanged', () => {
    expect(normalizeDateInput('2026-03-19')).toBe('2026-03-19');
  });

  it('converts DD.MM.YYYY to YYYY-MM-DD', () => {
    expect(normalizeDateInput('19.03.2026')).toBe('2026-03-19');
  });

  it('parses ambiguous slash dates as day-first', () => {
    expect(normalizeDateInput('03/04/2026')).toBe('2026-04-03');
    expect(normalizeDateInput('12/11/2026')).toBe('2026-11-12');
  });

  it('returns empty string for invalid day-first dates', () => {
    expect(normalizeDateInput('31/02/2026')).toBe('');
  });

  it('extracts date from ISO datetime values', () => {
    expect(normalizeDateInput('2026-03-19T18:45:00.000Z')).toBe('2026-03-19');
  });

  it('parses year-first slash dates safely', () => {
    expect(normalizeDateInput('2026/03/19')).toBe('2026-03-19');
  });

  it('returns empty string for invalid date inputs', () => {
    expect(normalizeDateInput('kein-datum')).toBe('');
  });
});

describe('formatDateOutput', () => {
  it('formats ISO dates as TT.MM.JJJJ', () => {
    expect(formatDateOutput('2026-03-09')).toBe('09.03.2026');
  });

  it('formats day-first input as TT.MM.JJJJ', () => {
    expect(formatDateOutput('9.3.2026')).toBe('09.03.2026');
  });

  it('returns empty string for invalid values', () => {
    expect(formatDateOutput('foo')).toBe('');
  });
});
