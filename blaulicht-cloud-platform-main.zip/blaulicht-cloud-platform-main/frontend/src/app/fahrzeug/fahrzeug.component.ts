import { CommonModule } from "@angular/common";
import { Component, HostListener, OnInit, ViewChild, inject } from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from "@angular/forms";
import { Router, RouterModule } from "@angular/router";

import { MatButtonModule } from "@angular/material/button";
import { MatCardModule } from "@angular/material/card";
import { MatExpansionModule } from "@angular/material/expansion";
import { MatInputModule } from "@angular/material/input";
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from "@angular/material/sort";
import { MatTableDataSource, MatTableModule } from "@angular/material/table";
import { MatSelectModule } from "@angular/material/select";
import { MatAutocompleteModule } from "@angular/material/autocomplete";

import {
  IFahrzeugDetail,
  IFahrzeugList,
  IFahrzeugRaum,
  IFahrzeugUnterinventarItem,
  IRaumItem,
} from "../_interface/fahrzeug";
import { ApiHttpService } from 'src/app/_service/api-http.service';
import { AuthSessionService } from 'src/app/_service/auth-session.service';
import { CollectionUtilsService } from 'src/app/_service/collection-utils.service';
import { NavigationService } from 'src/app/_service/navigation.service';
import { UiMessageService } from 'src/app/_service/ui-message.service';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from "../imr-ui-library";
import { ImrUploadFieldComponent } from '../imr-ui-library/imr-upload-field/imr-upload-field.component';
import { DateInputMaskDirective } from '../_directive/date-input-mask.directive';
import { TABLE_PAGINATION_DEFAULT_PAGE_SIZE, TABLE_PAGINATION_PAGE_SIZE_OPTIONS } from '../_utils/table-pagination-options';

type RaumEditFG = FormGroup<{
  name: FormControl<string>;
  reihenfolge: FormControl<number>;
}>;

type ItemDraftFG = FormGroup<{
  name: FormControl<string>;
  bereich: FormControl<string>;
  menge: FormControl<number>;
  einheit: FormControl<string>;
  unterinventar_name: FormControl<string>;
  unterinventar_menge: FormControl<number>;
  unterinventar_liste: FormControl<IFahrzeugUnterinventarItem[]>;
  reihenfolge: FormControl<number>;
  wartung_zuletzt_am: FormControl<string>;
  wartung_naechstes_am: FormControl<string>;
}>;

@Component({
  standalone: true,
  selector: "app-fahrzeug",
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    ImrUploadFieldComponent,
    MatButtonModule,
    MatCardModule,
    MatExpansionModule,
    MatIconModule,
    MatTableModule,
    MatSortModule,
    MatFormFieldModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatInputModule,
    MatPaginatorModule,
    DateInputMaskDirective,
  ],
  templateUrl: "./fahrzeug.component.html",
  styleUrl: "./fahrzeug.component.sass",
})
export class FahrzeugComponent implements OnInit {
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private collectionUtilsService = inject(CollectionUtilsService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  private fb = inject(FormBuilder);
  private router = inject(Router);

  breadcrumb: ImrBreadcrumbItem[] = [];
  modul = "fahrzeuge";

  fahrzeuge: IFahrzeugList[] = [];
  dataSource = new MatTableDataSource<IFahrzeugList>([]);
  readonly pageSizeOptions = TABLE_PAGINATION_PAGE_SIZE_OPTIONS.standard;
  readonly pageSize = TABLE_PAGINATION_DEFAULT_PAGE_SIZE.standard;
  sichtbareSpalten: string[] = ["name", "actions"];
  fahrzeugFilter = '';
  editorOpen = false;
  inventarEditorOpen = false;
  inventarAnsicht: "detail" | "kompakt" = "detail";
  einheitOptionen: string[] = ["Stk", "L", "Pkg"];
  raumNameOptionen: string[] = [];
  itemNameOptionen: string[] = [];
  bereichOptionen: string[] = [];
  unterinventarNameOptionen: string[] = [];
  gefilterteRaumNamen: string[] = [];
  gefilterteItemNamen: string[] = [];
  gefilterteBereiche: string[] = [];
  gefilterteUnterinventarNamen: string[] = [];

  selectedId: string | null = null;
  selected: IFahrzeugDetail | null = null;

  fahrzeugForm = this.fb.group({
    id: this.fb.control<string | null>(null),
    name: this.fb.control<string>("", {
      nonNullable: true,
      validators: [Validators.required],
    }),
    bezeichnung: this.fb.control<string>("", { nonNullable: true }),
    reihenfolge: this.fb.control<number>(0, { nonNullable: true }),
    beschreibung: this.fb.control<string>("", { nonNullable: true }),
    service_zuletzt_am: this.fb.control<string>("", { nonNullable: true }),
    service_naechstes_am: this.fb.control<string>("", { nonNullable: true }),
    pickerl_zuletzt_am: this.fb.control<string>("", { nonNullable: true }),
    pickerl_naechstes_am: this.fb.control<string>("", { nonNullable: true }),
  });

  raumForm = this.fb.group({
    name: this.fb.control<string>("", {
      nonNullable: true,
      validators: [Validators.required],
    }),
    reihenfolge: this.fb.control<number>(0, { nonNullable: true }),
  });

  private itemCreateForms = new Map<string, ItemDraftFG>();
  private raumEditForms = new Map<string, RaumEditFG>();
  private itemEditForms = new Map<string, ItemDraftFG>();
  private raumFotoFiles = new Map<string, File>();
  private raumFotoNames = new Map<string, string>();
  private raeumeByFahrzeug = new Map<string, IFahrzeugRaum[]>();

  fahrzeugFotoDatei: File | null = null;
  fahrzeugFotoName = "";

  neuerRaumFotoDatei: File | null = null;
  neuerRaumFotoName = "";

  @ViewChild(MatPaginator) paginator?: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild("fahrzeugFotoUpload") fahrzeugFotoRef?: ImrUploadFieldComponent;
  @ViewChild("newRaumFotoUpload") neuerRaumFotoRef?: ImrUploadFieldComponent;

  photoModalOpen = false;
  photoModalUrl: string | null = null;
  private pendingPhotoRemovals = new Set<string>();
  private pendingPhotoPreviewUrls = new Map<string, string>();
  private focusBeforePhotoModal: HTMLElement | null = null;

  ngOnInit(): void {
    sessionStorage.setItem("PageNumber", "2");
    sessionStorage.setItem("Page2", "FZ");
    this.breadcrumb = this.navigationService.ladeBreadcrumb();
    this.configureFahrzeugFilter();
    this.updateVisibleColumns();
    this.loadList();
  }

  private configureFahrzeugFilter(): void {
    this.dataSource.filterPredicate = (row: IFahrzeugList, filter: string) => {
      const haystack = `${row.name ?? ''}`.toLowerCase();
      return haystack.includes(filter);
    };
  }

  private normalizeFilterValue(value: string): string {
    return String(value ?? '').trim().toLowerCase();
  }

  applyFahrzeugFilter(value: string): void {
    this.fahrzeugFilter = value;
    this.dataSource.filter = this.normalizeFilterValue(value);
    this.paginator?.firstPage();
  }

  get filteredFahrzeugCount(): number {
    return this.dataSource.filteredData.length;
  }

  @HostListener("window:resize")
  onWindowResize(): void {
    this.updateVisibleColumns();
  }

  private updateVisibleColumns(): void {
    this.sichtbareSpalten = ["name", "actions"];
  }

  private loadList(): void {
    this.apiHttpService.get(this.modul).subscribe({
      next: (res: unknown) => {
        this.fahrzeuge = ((res as IFahrzeugList[]) ?? []).map((row) => ({
          ...row,
          foto_url: this.normalizePhotoUrl(row.foto_url),
        }));
        this.dataSource.data = this.fahrzeuge;
        this.dataSource.filter = this.normalizeFilterValue(this.fahrzeugFilter);
        this.preloadRaeumeVonAllenFahrzeugen();

        queueMicrotask(() => {
          if (this.paginator) this.dataSource.paginator = this.paginator;
          if (this.sort) this.dataSource.sort = this.sort;
        });
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  private resetNestedForms(): void {
    this.itemCreateForms.clear();
    this.raumEditForms.clear();
    this.itemEditForms.clear();
    this.raumFotoFiles.clear();
    this.raumFotoNames.clear();
  }

  private resetEditorData(): void {
    this.selectedId = null;
    this.selected = null;
    this.resetNestedForms();

    this.fahrzeugForm.reset({
      id: null,
      name: "",
      bezeichnung: "",
      reihenfolge: 0,
      beschreibung: "",
      service_zuletzt_am: "",
      service_naechstes_am: "",
      pickerl_zuletzt_am: "",
      pickerl_naechstes_am: "",
    });

    this.raumForm.reset({
      name: "",
      reihenfolge: 0,
    });

    this.resetFahrzeugFotoAuswahl();
    this.resetNeuerRaumFotoAuswahl();
  }

  editFahrzeug(row: IFahrzeugList): void {
    this.editorOpen = true;
    this.inventarEditorOpen = false;
    this.selectedId = row.id;
    this.loadDetail(row.id);
  }

  closeEditor(): void {
    this.editorOpen = false;
    this.inventarEditorOpen = false;
    this.resetEditorData();
  }

  private loadDetail(id: string): void {
    this.apiHttpService.get(`${this.modul}/${id}`).subscribe({
      next: (res: unknown) => {
        this.selected = this.normalizeFahrzeugDetailPhotoUrls(res as IFahrzeugDetail);
        this.raeumeByFahrzeug.set(this.selected.id, this.selected.raeume ?? []);

        this.fahrzeugForm.setValue({
          id: this.selected.id,
          name: this.selected.name ?? "",
          bezeichnung: this.selected.bezeichnung ?? "",
          reihenfolge: Number(this.selected.reihenfolge ?? 0),
          beschreibung: this.selected.beschreibung ?? "",
          service_zuletzt_am: this.toDateInput(this.selected.service_zuletzt_am),
          service_naechstes_am: this.toDateInput(this.selected.service_naechstes_am),
          pickerl_zuletzt_am: this.toDateInput(this.selected.pickerl_zuletzt_am),
          pickerl_naechstes_am: this.toDateInput(this.selected.pickerl_naechstes_am),
        });

        this.resetNestedForms();
        for (const raum of this.selected.raeume ?? []) {
          this.itemCreateForms.set(raum.id, this.createItemDraftForm());
          // UI-Status für Item-Bearbeitung/Neuanlage initialisieren
          raum.editItemId = null;
          raum.showNewItem = false;
          raum.selectedItemId = null;
        }
        this.refreshInventarAutocompleteOptionen();

        this.resetFahrzeugFotoAuswahl();
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  private preloadRaeumeVonAllenFahrzeugen(): void {
    for (const fahrzeug of this.fahrzeuge) {
      this.apiHttpService.get<IFahrzeugDetail>(`${this.modul}/${fahrzeug.id}`).subscribe({
        next: (detail) => {
          this.raeumeByFahrzeug.set(fahrzeug.id, detail?.raeume ?? []);
          this.refreshInventarAutocompleteOptionen();
        },
        error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
      });
    }
  }

  newFahrzeug(): void {
    this.editorOpen = true;
    this.inventarEditorOpen = false;
    this.resetEditorData();
  }

  openInventarFromList(row: IFahrzeugList): void {
    this.openInventarEditor(row.id);
  }

  openCheckFromList(row: IFahrzeugList): void {
    this.router.navigate(["/fahrzeuge", row.id, "check"]);
  }

  openInventarFromEditor(): void {
    if (!this.selectedId) {
      this.uiMessageService.erstelleMessage("error", "Bitte Fahrzeug zuerst speichern.");
      return;
    }

    this.openInventarEditor(this.selectedId);
  }

  backToFahrzeugEditor(): void {
    if (!this.selectedId) {
      this.uiMessageService.erstelleMessage("error", "Bitte Fahrzeug zuerst auswählen.");
      return;
    }

    this.inventarEditorOpen = false;
    this.editorOpen = true;

    if (!this.selected || this.selected.id !== this.selectedId) {
      this.loadDetail(this.selectedId);
    }
  }

  private openInventarEditor(fahrzeugId: string): void {
    this.selectedId = fahrzeugId;
    this.editorOpen = false;
    this.inventarEditorOpen = true;
    this.loadDetail(fahrzeugId);
  }

  countItems(raeume: IFahrzeugRaum[] | null | undefined): number {
    return (raeume ?? []).reduce((sum, raum) => sum + (raum.items?.length ?? 0), 0);
  }

  private normalizeDate(dateValue: string | null | undefined): string | null {
    const clean = String(dateValue ?? "").trim();
    return clean === "" ? null : clean;
  }

  private toDateInput(dateValue: string | null | undefined): string {
    const raw = String(dateValue ?? '').trim();
    if (!raw) return '';

    const isoMatch = raw.match(/^(\d{4})[-./](\d{2})[-./](\d{2})/);
    if (isoMatch) {
      return `${isoMatch[1]}-${isoMatch[2]}-${isoMatch[3]}`;
    }

    const dmyOrMdyMatch = raw.match(/^(\d{2})[./-](\d{2})[./-](\d{4})$/);
    if (dmyOrMdyMatch) {
      const first = Number(dmyOrMdyMatch[1]);
      const second = Number(dmyOrMdyMatch[2]);
      const year = dmyOrMdyMatch[3];

      let day = first;
      let month = second;

      // Klarer US-Fall: MM.TT.JJJJ -> in ISO drehen.
      if (second > 12 && first <= 12) {
        day = second;
        month = first;
      }

      if (day < 1 || day > 31 || month < 1 || month > 12) {
        return '';
      }

      return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }

    return '';
  }

  formatItemDate(dateValue: string | null | undefined): string {
    const iso = this.toDateInput(dateValue);
    if (!iso) return '-';

    const [year, month, day] = iso.split('-');
    return `${day}.${month}.${year}`;
  }

  private isDateWindowInvalid(zuletzt: string | null, naechstes: string | null): boolean {
    return Boolean(zuletzt && naechstes && naechstes < zuletzt);
  }

  private buildFahrzeugPayload(): {
    name: string;
    bezeichnung: string;
    reihenfolge: number;
    beschreibung: string;
    service_zuletzt_am: string | null;
    service_naechstes_am: string | null;
    pickerl_zuletzt_am: string | null;
    pickerl_naechstes_am: string | null;
  } | null {
    const serviceZuletzt = this.normalizeDate(this.fahrzeugForm.controls.service_zuletzt_am.value);
    const serviceNaechstes = this.normalizeDate(this.fahrzeugForm.controls.service_naechstes_am.value);
    const pickerlZuletzt = this.normalizeDate(this.fahrzeugForm.controls.pickerl_zuletzt_am.value);
    const pickerlNaechstes = this.normalizeDate(this.fahrzeugForm.controls.pickerl_naechstes_am.value);

    if (this.isDateWindowInvalid(serviceZuletzt, serviceNaechstes)) {
      this.uiMessageService.erstelleMessage(
        "error",
        "Service: Das nächste Datum darf nicht vor dem zuletzt erledigten Datum liegen."
      );
      return null;
    }

    if (this.isDateWindowInvalid(pickerlZuletzt, pickerlNaechstes)) {
      this.uiMessageService.erstelleMessage(
        "error",
        "Pickerl: Das nächste Datum darf nicht vor dem zuletzt erledigten Datum liegen."
      );
      return null;
    }

    return {
      name: this.fahrzeugForm.controls.name.value.trim(),
      bezeichnung: this.fahrzeugForm.controls.bezeichnung.value.trim(),
      reihenfolge: Number(this.fahrzeugForm.controls.reihenfolge.value ?? 0),
      beschreibung: this.fahrzeugForm.controls.beschreibung.value.trim(),
      service_zuletzt_am: serviceZuletzt,
      service_naechstes_am: serviceNaechstes,
      pickerl_zuletzt_am: pickerlZuletzt,
      pickerl_naechstes_am: pickerlNaechstes,
    };
  }

  private toFahrzeugFormData(payload: {
    name: string;
    bezeichnung: string;
    reihenfolge: number;
    beschreibung: string;
    service_zuletzt_am: string | null;
    service_naechstes_am: string | null;
    pickerl_zuletzt_am: string | null;
    pickerl_naechstes_am: string | null;
  }, file: File): FormData {
    const fd = new FormData();
    fd.append("name", payload.name);
    fd.append("bezeichnung", payload.bezeichnung);
    fd.append("reihenfolge", String(payload.reihenfolge));
    fd.append("beschreibung", payload.beschreibung);
    fd.append("service_zuletzt_am", payload.service_zuletzt_am ?? "");
    fd.append("service_naechstes_am", payload.service_naechstes_am ?? "");
    fd.append("pickerl_zuletzt_am", payload.pickerl_zuletzt_am ?? "");
    fd.append("pickerl_naechstes_am", payload.pickerl_naechstes_am ?? "");
    fd.append("foto", file, file.name || "upload.png");
    return fd;
  }

  private isUploadTooLarge(file: File): boolean {
    const sizeKB = Math.round(file.size / 1024);
    return sizeKB >= this.apiHttpService.MaxUploadSize;
  }

  private showUploadTooLargeError(): void {
    const maxMB = this.apiHttpService.MaxUploadSize / 1024;
    this.uiMessageService.erstelleMessage("error", `Foto darf nicht größer als ${maxMB}MB sein!`);
  }

  private resetFahrzeugFotoAuswahl(): void {
    this.fahrzeugFotoDatei = null;
    this.fahrzeugFotoName = "";
    this.fahrzeugFotoRef?.clear();
  }

  private resetNeuerRaumFotoAuswahl(): void {
    this.neuerRaumFotoDatei = null;
    this.neuerRaumFotoName = "";
    this.neuerRaumFotoRef?.clear();
  }

  onFahrzeugFotoSelected(event: Event): void {
    const input = event.target as HTMLInputElement | null;
    const file = input?.files?.[0] ?? null;

    if (!file) {
      this.resetFahrzeugFotoAuswahl();
      return;
    }

    if (this.isUploadTooLarge(file)) {
      this.resetFahrzeugFotoAuswahl();
      this.showUploadTooLargeError();
      return;
    }

    this.fahrzeugFotoDatei = file;
    this.fahrzeugFotoName = file.name;
  }

  removeFahrzeugFoto(): void {
    if (!this.selectedId) return;

    this.apiHttpService.patch(this.modul, this.selectedId, { remove_foto: true }, false).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage("success", "Fahrzeugfoto entfernt.");
        this.resetFahrzeugFotoAuswahl();
        this.loadList();
        this.loadDetail(this.selectedId!);
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  saveFahrzeug(): void {
    if (this.fahrzeugForm.invalid) {
      this.uiMessageService.erstelleMessage("error", "Bitte Name ausfüllen.");
      return;
    }

    const payload = this.buildFahrzeugPayload();
    if (!payload) return;

    const id = this.fahrzeugForm.controls.id.value;

    if (!id) {
      if (this.fahrzeugFotoDatei) {
        const fd = this.toFahrzeugFormData(payload, this.fahrzeugFotoDatei);
        this.apiHttpService.post(this.modul, fd, true).subscribe({
          next: () => {
            this.uiMessageService.erstelleMessage("success", "Fahrzeug erstellt.");
            this.closeEditor();
            this.loadList();
          },
          error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
        });
      } else {
        this.apiHttpService.post(this.modul, payload, false).subscribe({
          next: () => {
            this.uiMessageService.erstelleMessage("success", "Fahrzeug erstellt.");
            this.closeEditor();
            this.loadList();
          },
          error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
        });
      }
      return;
    }

    if (this.fahrzeugFotoDatei) {
      const fd = this.toFahrzeugFormData(payload, this.fahrzeugFotoDatei);
      this.apiHttpService.patch(this.modul, id, fd, true).subscribe({
        next: () => {
          this.uiMessageService.erstelleMessage("success", "Fahrzeug gespeichert.");
          this.closeEditor();
          this.loadList();
        },
        error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
      });
    } else {
      this.apiHttpService.patch(this.modul, id, payload, false).subscribe({
        next: () => {
          this.uiMessageService.erstelleMessage("success", "Fahrzeug gespeichert.");
          this.closeEditor();
          this.loadList();
        },
        error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
      });
    }
  }

  deleteSelectedFahrzeug(): void {
    if (!this.selectedId) return;

    const name = this.selected?.name || this.fahrzeugForm.controls.name.value || "Unbenannt";
    if (!confirm(`Fahrzeug "${name}" wirklich löschen?`)) return;

    this.apiHttpService.delete(this.modul, this.selectedId).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage("success", "Fahrzeug gelöscht.");
        this.closeEditor();
        this.loadList();
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  // =========================
  // Räume (nested)
  // =========================
  onNewRaumFotoSelected(event: Event): void {
    const input = event.target as HTMLInputElement | null;
    const file = input?.files?.[0] ?? null;

    if (!file) {
      this.resetNeuerRaumFotoAuswahl();
      return;
    }

    if (this.isUploadTooLarge(file)) {
      this.resetNeuerRaumFotoAuswahl();
      this.showUploadTooLargeError();
      return;
    }

    this.neuerRaumFotoDatei = file;
    this.neuerRaumFotoName = file.name;
  }

  addRaum(): void {
    if (!this.selectedId) {
      this.uiMessageService.erstelleMessage("error", "Bitte zuerst ein Fahrzeug auswählen.");
      return;
    }
    if (this.raumForm.invalid) {
      this.uiMessageService.erstelleMessage("error", "Raumname fehlt.");
      return;
    }

    const payload = {
      name: this.raumForm.controls.name.value.trim(),
      reihenfolge: this.raumForm.controls.reihenfolge.value,
    };

    if (this.neuerRaumFotoDatei) {
      const fd = new FormData();
      fd.append("name", payload.name);
      fd.append("reihenfolge", String(payload.reihenfolge));
      fd.append("foto", this.neuerRaumFotoDatei, this.neuerRaumFotoDatei.name || "upload.png");

      this.apiHttpService.post(`fahrzeuge/${this.selectedId}/raeume`, fd, true).subscribe({
        next: () => {
          this.uiMessageService.erstelleMessage("success", "Raum angelegt.");
          this.raumForm.reset({ name: "", reihenfolge: 0 });
          this.resetNeuerRaumFotoAuswahl();
          this.loadDetail(this.selectedId!);
        },
        error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
      });
      return;
    }

    this.apiHttpService.post(`fahrzeuge/${this.selectedId}/raeume`, payload, false).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage("success", "Raum angelegt.");
        this.raumForm.reset({ name: "", reihenfolge: 0 });
        this.resetNeuerRaumFotoAuswahl();
        this.loadDetail(this.selectedId!);
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  private createRaumEditForm(raum: IFahrzeugRaum): RaumEditFG {
    return this.fb.group({
      name: this.fb.control<string>(raum.name ?? "", {
        nonNullable: true,
        validators: [Validators.required],
      }),
      reihenfolge: this.fb.control<number>(raum.reihenfolge ?? 0, { nonNullable: true }),
    });
  }

  raumEditFormFor(raum: IFahrzeugRaum): RaumEditFG {
    const existing = this.raumEditForms.get(raum.id);
    if (existing) return existing;

    const created = this.createRaumEditForm(raum);
    this.raumEditForms.set(raum.id, created);
    return created;
  }

  onRaumFotoSelected(raumId: string, event: Event): void {
    const input = event.target as HTMLInputElement | null;
    const file = input?.files?.[0] ?? null;

    if (!file) {
      this.raumFotoFiles.delete(raumId);
      this.raumFotoNames.delete(raumId);
      return;
    }

    if (this.isUploadTooLarge(file)) {
      this.raumFotoFiles.delete(raumId);
      this.raumFotoNames.delete(raumId);
      this.showUploadTooLargeError();
      if (input) input.value = "";
      return;
    }

    this.raumFotoFiles.set(raumId, file);
    this.raumFotoNames.set(raumId, file.name);
  }

  raumFotoNameFor(raumId: string): string {
    return this.raumFotoNames.get(raumId) ?? "";
  }

  saveRaum(raum: IFahrzeugRaum): void {
    if (!this.selectedId) return;

    const form = this.raumEditFormFor(raum);
    form.markAllAsTouched();
    if (form.invalid) {
      this.uiMessageService.erstelleMessage("error", "Bitte Raumname ausfüllen.");
      return;
    }

    const payload = {
      name: form.controls.name.value.trim(),
      reihenfolge: form.controls.reihenfolge.value,
    };

    const file = this.raumFotoFiles.get(raum.id) ?? null;

    if (file) {
      const fd = new FormData();
      fd.append("name", payload.name);
      fd.append("reihenfolge", String(payload.reihenfolge));
      fd.append("foto", file, file.name || "upload.png");

      this.apiHttpService.patch(`fahrzeuge/${this.selectedId}/raeume`, raum.id, fd, true).subscribe({
        next: () => {
          this.uiMessageService.erstelleMessage("success", `Raum "${raum.name}" gespeichert.`);
          this.raumFotoFiles.delete(raum.id);
          this.raumFotoNames.delete(raum.id);
          this.loadDetail(this.selectedId!);
        },
        error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
      });
      return;
    }

    this.apiHttpService.patch(`fahrzeuge/${this.selectedId}/raeume`, raum.id, payload, false).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage("success", `Raum "${raum.name}" gespeichert.`);
        this.loadDetail(this.selectedId!);
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  removeRaumFoto(raum: IFahrzeugRaum): void {
    if (!this.selectedId) return;

    this.apiHttpService.patch(`fahrzeuge/${this.selectedId}/raeume`, raum.id, { remove_foto: true }, false).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage("success", `Raumfoto von "${raum.name}" entfernt.`);
        this.raumFotoFiles.delete(raum.id);
        this.raumFotoNames.delete(raum.id);
        this.loadDetail(this.selectedId!);
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  deleteRaum(raum: IFahrzeugRaum): void {
    if (!this.selectedId) return;
    if (!confirm(`Raum "${raum.name}" wirklich löschen? (Items werden mitgelöscht)`)) return;

    this.apiHttpService.delete(`fahrzeuge/${this.selectedId}/raeume`, raum.id).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage("success", "Raum gelöscht.");
        this.loadDetail(this.selectedId!);
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  // =========================
  // Items (nested)
  // =========================
  private createItemDraftForm(seed?: Partial<IRaumItem>): ItemDraftFG {
    const mengeRaw = Number(seed?.menge ?? 1);
    const menge = Number.isFinite(mengeRaw) && mengeRaw >= 0 ? mengeRaw : 1;

    return this.fb.group({
      name: this.fb.control<string>(seed?.name ?? "", {
        nonNullable: true,
        validators: [Validators.required],
      }),
      bereich: this.fb.control<string>(seed?.bereich ?? "", { nonNullable: true }),
      menge: this.fb.control<number>(menge, {
        nonNullable: true,
        validators: [Validators.required, Validators.min(0)],
      }),
      einheit: this.fb.control<string>(seed?.einheit ?? "", { nonNullable: true }),
      unterinventar_name: this.fb.control<string>("", { nonNullable: true }),
      unterinventar_menge: this.fb.control<number>(1, {
        nonNullable: true,
        validators: [Validators.required, Validators.min(1)],
      }),
      unterinventar_liste: this.fb.control<IFahrzeugUnterinventarItem[]>(
        this.normalizeUnterinventar(seed?.unterinventar),
        { nonNullable: true }
      ),
      reihenfolge: this.fb.control<number>(seed?.reihenfolge ?? 0, { nonNullable: true }),
      wartung_zuletzt_am: this.fb.control<string>(this.toDateInput(seed?.wartung_zuletzt_am), {
        nonNullable: true,
      }),
      wartung_naechstes_am: this.fb.control<string>(this.toDateInput(seed?.wartung_naechstes_am), {
        nonNullable: true,
      }),
    });
  }

  private normalizeUnterinventar(value: unknown): IFahrzeugUnterinventarItem[] {
    if (!Array.isArray(value)) {
      return [];
    }

    return value
      .map((entry) => {
        if (entry && typeof entry === "object" && !Array.isArray(entry)) {
          const name = String((entry as { name?: unknown }).name ?? "").trim();
          const mengeRaw = Number((entry as { menge?: unknown }).menge ?? 1);
          const menge = Number.isFinite(mengeRaw) && mengeRaw > 0 ? mengeRaw : 1;
          if (!name) {
            return null;
          }
          return { name, menge };
        }

        const fallbackName = String(entry ?? "").trim();
        if (!fallbackName) {
          return null;
        }
        return { name: fallbackName, menge: 1 };
      })
      .filter((entry): entry is IFahrzeugUnterinventarItem => entry !== null);
  }

  private refreshInventarAutocompleteOptionen(): void {
    const raumNamen = new Set<string>();
    const itemNamen = new Set<string>();
    const bereiche = new Set<string>();
    const unterinventarNamen = new Set<string>();

    for (const raeume of this.raeumeByFahrzeug.values()) {
      for (const raum of raeume) {
        const raumName = String(raum.name ?? "").trim();
        if (raumName) {
          raumNamen.add(raumName);
        }
      }
    }

    for (const raum of this.selected?.raeume ?? []) {
      const raumName = String(raum.name ?? "").trim();
      if (raumName) {
        raumNamen.add(raumName);
      }
      for (const item of raum.items ?? []) {
        const itemName = String(item.name ?? "").trim();
        const bereich = String(item.bereich ?? "").trim();
        if (itemName) {
          itemNamen.add(itemName);
        }
        if (bereich) {
          bereiche.add(bereich);
        }
        for (const unterinventar of this.normalizeUnterinventar(item.unterinventar)) {
          const unterinventarName = String(unterinventar.name ?? "").trim();
          if (unterinventarName) {
            unterinventarNamen.add(unterinventarName);
          }
        }
      }
    }

    this.raumNameOptionen = Array.from(raumNamen).sort((a, b) => a.localeCompare(b, "de"));
    this.itemNameOptionen = Array.from(itemNamen).sort((a, b) => a.localeCompare(b, "de"));
    this.bereichOptionen = Array.from(bereiche).sort((a, b) => a.localeCompare(b, "de"));
    this.unterinventarNameOptionen = Array.from(unterinventarNamen).sort((a, b) => a.localeCompare(b, "de"));
    this.filterRaumNamen(this.raumForm.controls.name.value);
  }

  private filterRaumNamen(value: string): void {
    const search = String(value ?? "").trim().toLowerCase();
    this.gefilterteRaumNamen = this.raumNameOptionen.filter((name) => name.toLowerCase().includes(search));
  }

  onRaumNameInput(value: string): void {
    this.filterRaumNamen(value);
    this.raumForm.controls.name.setValue(value ?? "");
  }

  onRaumEditNameInput(form: RaumEditFG, value: string): void {
    this.filterRaumNamen(value);
    form.controls.name.setValue(value ?? "");
  }

  onItemNameInput(form: ItemDraftFG, value: string): void {
    const search = String(value ?? "").trim().toLowerCase();
    this.gefilterteItemNamen = this.itemNameOptionen.filter((name) => name.toLowerCase().includes(search));
    form.controls.name.setValue(value ?? "");
  }

  onBereichInput(form: ItemDraftFG, value: string): void {
    const search = String(value ?? "").trim().toLowerCase();
    this.gefilterteBereiche = this.bereichOptionen.filter((name) => name.toLowerCase().includes(search));
    form.controls.bereich.setValue(value ?? "");
  }

  onUnterinventarNameInput(form: ItemDraftFG, value: string): void {
    const search = String(value ?? "").trim().toLowerCase();
    this.gefilterteUnterinventarNamen = this.unterinventarNameOptionen.filter((name) =>
      name.toLowerCase().includes(search)
    );
    form.controls.unterinventar_name.setValue(value ?? "");
  }

  addUnterinventarPosition(form: ItemDraftFG): void {
    const name = String(form.controls.unterinventar_name.value ?? "").trim();
    const mengeRaw = Number(form.controls.unterinventar_menge.value ?? 1);
    const menge = Number.isFinite(mengeRaw) && mengeRaw > 0 ? mengeRaw : 1;

    if (!name) {
      this.uiMessageService.erstelleMessage("error", "Bitte eine Unterinventar-Bezeichnung eingeben.");
      return;
    }

    const current = this.normalizeUnterinventar(form.controls.unterinventar_liste.value);
    form.controls.unterinventar_liste.setValue([...current, { name, menge }]);
    form.controls.unterinventar_name.setValue("");
    form.controls.unterinventar_menge.setValue(1);
    this.gefilterteUnterinventarNamen = [];
  }

  removeUnterinventarPosition(form: ItemDraftFG, index: number): void {
    const current = this.normalizeUnterinventar(form.controls.unterinventar_liste.value);
    form.controls.unterinventar_liste.setValue(current.filter((_, idx) => idx !== index));
  }

  itemCreateFormFor(raumId: string): ItemDraftFG {
    const f = this.itemCreateForms.get(raumId);
    if (f) return f;

    const created = this.createItemDraftForm();
    this.itemCreateForms.set(raumId, created);
    return created;
  }

  itemEditFormFor(item: IRaumItem): ItemDraftFG {
    const f = this.itemEditForms.get(item.id);
    if (f) return f;

    const created = this.createItemDraftForm(item);
    this.itemEditForms.set(item.id, created);
    return created;
  }

  private buildItemPayload(form: ItemDraftFG): {
    name: string;
    bereich: string;
    menge: number;
    einheit: string;
    unterinventar: IFahrzeugUnterinventarItem[];
    reihenfolge: number;
    wartung_zuletzt_am: string | null;
    wartung_naechstes_am: string | null;
  } | null {
    const wartungZuletzt = this.normalizeDate(form.controls.wartung_zuletzt_am.value);
    const wartungNaechstes = this.normalizeDate(form.controls.wartung_naechstes_am.value);

    if (this.isDateWindowInvalid(wartungZuletzt, wartungNaechstes)) {
      this.uiMessageService.erstelleMessage(
        "error",
        "Wartung: Das nächste Datum darf nicht vor dem zuletzt erledigten Datum liegen."
      );
      return null;
    }

    return {
      name: form.controls.name.value.trim(),
      bereich: form.controls.bereich.value.trim(),
      menge: form.controls.menge.value,
      einheit: form.controls.einheit.value.trim(),
      unterinventar: this.normalizeUnterinventar(form.controls.unterinventar_liste.value),
      reihenfolge: form.controls.reihenfolge.value,
      wartung_zuletzt_am: wartungZuletzt,
      wartung_naechstes_am: wartungNaechstes,
    };
  }

  addItem(raum: IFahrzeugRaum): void {
    const form = this.itemCreateFormFor(raum.id);
    form.markAllAsTouched();

    if (form.invalid) {
      this.uiMessageService.erstelleMessage("error", "Item-Name fehlt oder Menge ist ungültig.");
      return;
    }

    const payload = this.buildItemPayload(form);
    if (!payload) return;

    this.apiHttpService.post(`raeume/${raum.id}/items`, payload, false).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage("success", "Item angelegt.");
        form.reset({
          name: "",
          bereich: "",
          menge: 1,
          einheit: "",
          unterinventar_name: "",
          unterinventar_menge: 1,
          unterinventar_liste: [],
          reihenfolge: 0,
          wartung_zuletzt_am: "",
          wartung_naechstes_am: "",
        });
        if (this.selectedId) this.loadDetail(this.selectedId);
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  selectRaumItem(raum: IFahrzeugRaum, item: IRaumItem): void {
    raum.selectedItemId = item.id;
  }

  selectedRaumItem(raum: IFahrzeugRaum): IRaumItem | null {
    const selectedId = raum.selectedItemId;
    if (!selectedId) return null;
    return raum.items.find((item) => item.id === selectedId) ?? null;
  }

  editingItem(raum: IFahrzeugRaum): IRaumItem | null {
    const editId = raum.editItemId;
    if (!editId) return null;
    return raum.items.find((item) => item.id === editId) ?? null;
  }

  openNewItemForm(raum: IFahrzeugRaum): void {
    raum.showNewItem = true;
    raum.editItemId = null;
  }

  closeNewItemForm(raum: IFahrzeugRaum): void {
    raum.showNewItem = false;
  }

  // openSelectedItemEdit(raum: IFahrzeugRaum): void {
  //   const selectedItem = this.selectedRaumItem(raum);
  //   if (!selectedItem) {
  //     this.uiMessageService.erstelleMessage("info", "Bitte zuerst ein Item in der Tabelle auswählen.");
  //     return;
  //   }
  //   raum.showNewItem = false;
  //   raum.editItemId = selectedItem.id;
  // }

  openItemEdit(raum: IFahrzeugRaum, item: IRaumItem): void {
    raum.showNewItem = false;
    raum.editItemId = item.id;
  }

  closeSelectedItemEdit(raum: IFahrzeugRaum): void {
    raum.editItemId = null;
  }

  deleteSelectedRaumItem(raum: IFahrzeugRaum): void {
    const selectedItem = this.selectedRaumItem(raum);
    if (!selectedItem) {
      this.uiMessageService.erstelleMessage("info", "Bitte zuerst ein Item in der Tabelle auswählen.");
      return;
    }
    this.deleteItem(raum, selectedItem);
  }

  saveItem(raum: IFahrzeugRaum, item: IRaumItem): void {
    const form = this.itemEditFormFor(item);
    form.markAllAsTouched();

    if (form.invalid) {
      this.uiMessageService.erstelleMessage("error", "Item-Name fehlt oder Menge ist ungültig.");
      return;
    }

    const payload = this.buildItemPayload(form);
    if (!payload) return;

    this.apiHttpService.patch(`raeume/${raum.id}/items`, item.id, payload, false).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage("success", `Item "${item.name}" gespeichert.`);
        if (this.selectedId) this.loadDetail(this.selectedId);
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  deleteItem(raum: IFahrzeugRaum, item: IRaumItem): void {
    if (!confirm(`Item "${item.name}" wirklich löschen?`)) return;

    this.apiHttpService.delete(`raeume/${raum.id}/items`, item.id).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage("success", "Item gelöscht.");
        if (this.selectedId) this.loadDetail(this.selectedId);
      },
      error: (err: unknown) => this.authSessionService.errorAnzeigen(err),
    });
  }

  getPhotoPreviewUrl(row: IFahrzeugList): string | null {
    if (this.pendingPhotoRemovals.has(row.id)) {
      return null;
    }

    const pendingPreviewUrl = this.pendingPhotoPreviewUrls.get(row.id);
    if (pendingPreviewUrl) {
      return pendingPreviewUrl;
    }

    return this.normalizePhotoUrl(row.foto_url);
  }


  openPhotoPreview(row: IFahrzeugList): void {
    const previewUrl = this.getPhotoPreviewUrl(row);
    if (!previewUrl) {
      this.uiMessageService.erstelleMessage('info', 'Kein Bild fuer die Vorschau vorhanden.');
      return;
    }

    this.focusBeforePhotoModal =
      typeof document !== 'undefined' && document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;
    this.photoModalUrl = previewUrl;
    this.photoModalOpen = true;
  }

  openRaumPhotoPreview(raum: IFahrzeugRaum): void {
    const url = this.normalizePhotoUrl(raum.foto_url);
    if (!url) {
      this.uiMessageService.erstelleMessage('info', 'Kein Raumfoto für die Vorschau vorhanden.');
      return;
    }
    this.focusBeforePhotoModal =
      typeof document !== 'undefined' && document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;
    this.photoModalUrl = url;
    this.photoModalOpen = true;
  }

  closePhotoPreview(): void {
    this.photoModalOpen = false;
    this.photoModalUrl = null;

    const target = this.focusBeforePhotoModal;
    this.focusBeforePhotoModal = null;
    if (target && typeof target.focus === 'function') {
      target.focus();
    }
  }

  private normalizeFahrzeugDetailPhotoUrls(detail: IFahrzeugDetail): IFahrzeugDetail {
    return {
      ...detail,
      foto_url: this.normalizePhotoUrl(detail.foto_url),
      raeume: (detail.raeume ?? []).map((raum) => ({
        ...raum,
        foto_url: this.normalizePhotoUrl(raum.foto_url),
      })),
    };
  }

  private normalizePhotoUrl(rawValue: string | null | undefined): string | null {
    const value = String(rawValue || '').trim();
    if (!value) {
      return null;
    }

    const browserOrigin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost';
    const apiBase = new URL(String(this.apiHttpService.AppUrl || '/api/v1/'), browserOrigin);

    // Bereits absolute URL -> auf API-Origin umbiegen, damit kein Host-Mix entsteht
    if (value.startsWith('http://') || value.startsWith('https://')) {
      try {
        const absolute = new URL(value);
        return new URL(`${absolute.pathname}${absolute.search}${absolute.hash}`, apiBase.origin).toString();
      } catch {
        return value;
      }
    }

    // Root-relativer Pfad -> ebenfalls auf API-Origin
    if (value.startsWith('/')) {
      return new URL(value, apiBase.origin).toString();
    }

    // Relative Datei/Pfad -> relativ zur API-Base
    return new URL(value.replace(/^\/+/, ''), apiBase).toString();
  }
}
