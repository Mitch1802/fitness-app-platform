﻿import { CommonModule } from "@angular/common";
import { Component, OnInit, inject } from "@angular/core";
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";

import { MatButtonModule } from "@angular/material/button";
import { MatExpansionModule } from "@angular/material/expansion";
import { MatSelectModule } from "@angular/material/select";
import { MatIconModule } from "@angular/material/icon";
import { MatInputModule } from "@angular/material/input";
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTooltipModule } from "@angular/material/tooltip";

import { ApiHttpService } from 'src/app/_service/api-http.service';
import { AuthSessionService } from 'src/app/_service/auth-session.service';
import { CollectionUtilsService } from 'src/app/_service/collection-utils.service';
import { NavigationService } from 'src/app/_service/navigation.service';
import { UiMessageService } from 'src/app/_service/ui-message.service';
import { IFahrzeugDetail } from "../_interface/fahrzeug";
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from "../imr-ui-library";
import { CheckStatus, CHECK_STATUS_OPTIONS } from "./fahrzeug-check.constants";

type ResultFG = FormGroup<{
  item_id: FormControl<string>;
  status: FormControl<CheckStatus | null>;
  menge_soll: FormControl<number | null>;
  menge_aktuel: FormControl<number | null>;
  notiz: FormControl<string>;
}>;

type CheckForm = FormGroup<{
  title: FormControl<string>;
  notiz: FormControl<string>;
  results: FormArray<ResultFG>;
}>;

type CheckRoomView = {
  name: string;
  items: Array<{
    index: number;
    name: string;
    menge: number;
    einheit: string;
    notiz: string;
  }>;
};

@Component({
  standalone: true,
  selector: "app-fahrzeug-check",
  imports: [
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatSelectModule,
    MatIconModule,
    MatInputModule,
    MatTooltipModule,
  ],
  templateUrl: "./fahrzeug-check.component.html",
  styleUrl: "./fahrzeug-check.component.sass",
})
export class FahrzeugCheckComponent implements OnInit {
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private collectionUtilsService = inject(CollectionUtilsService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private fb = inject(FormBuilder);

  breadcrumb: ImrBreadcrumbItem[] = [];

  fahrzeugId = "";
  fahrzeug: IFahrzeugDetail | null = null;
  raeumeView: CheckRoomView[] = [];
  problemStatusOptions = CHECK_STATUS_OPTIONS.filter((option) => option.value !== "ok");

  /** Tracks which form-array indices are in "details expanded" mode (red button pressed) */
  expandedItems = new Set<number>();

  /** Tracks which rooms are collapsed */
  collapsedRooms = new Set<string>();

  form: CheckForm = this.fb.group({
    title: this.fb.control("", { nonNullable: true, validators: [Validators.required] }),
    notiz: this.fb.control("", { nonNullable: true }),
    results: this.fb.array<ResultFG>([]),
  });

  ngOnInit(): void {
    sessionStorage.setItem("PageNumber", "2");
    sessionStorage.setItem("Page2", "FZCHECK");
    this.breadcrumb = this.navigationService.ladeBreadcrumb();
    this.fahrzeugId = String(this.route.snapshot.paramMap.get("id") ?? "");
    if (!this.fahrzeugId) return;

    this.load();
  }

  private load(): void {
    this.apiHttpService.get<IFahrzeugDetail>(`fahrzeuge/${this.fahrzeugId}`).subscribe({
      next: (fz) => {
        this.fahrzeug = fz;
        this.buildForm();
      },
      error: (e) => this.authSessionService.errorAnzeigen(e),
    });
  }

  toggleRoom(raumName: string): void {
    if (this.collapsedRooms.has(raumName)) {
      this.collapsedRooms.delete(raumName);
    } else {
      this.collapsedRooms.add(raumName);
    }
  }

  isRoomOpen(raumName: string): boolean {
    return !this.collapsedRooms.has(raumName);
  }

  markOk(index: number): void {
    this.form.controls.results.controls[index]?.controls.status.setValue("ok");
    this.expandedItems.delete(index);
  }

  markMissing(index: number): void {
    this.form.controls.results.controls[index]?.controls.status.setValue("missing");
    this.expandedItems.add(index);
  }

  setProblemStatus(index: number, status: CheckStatus): void {
    this.form.controls.results.controls[index]?.controls.status.setValue(status);
    if (status === "ok") {
      this.expandedItems.delete(index);
      return;
    }
    this.expandedItems.add(index);
  }

  isExpanded(index: number): boolean {
    return this.expandedItems.has(index);
  }

  isItemOk(index: number): boolean {
    return this.form.controls.results.controls[index]?.controls.status.value === "ok";
  }

  isItemMissing(index: number): boolean {
    const status = this.form.controls.results.controls[index]?.controls.status.value;
    return status === "missing" || status === "damaged";
  }

  getOkCount(raum: CheckRoomView): number {
    return raum.items.reduce((count, item) => {
      return this.isItemOk(item.index) ? count + 1 : count;
    }, 0);
  }

  getMissingCount(raum: CheckRoomView): number {
    return raum.items.reduce((count, item) => {
      const ctrl = this.form.controls.results.controls[item.index];
      const status = ctrl?.controls.status.value;
      return status === "missing" || status === "damaged" ? count + 1 : count;
    }, 0);
  }

  getOpenCount(raum: CheckRoomView): number {
    return raum.items.reduce((count, item) => {
      const ctrl = this.form.controls.results.controls[item.index];
      const status = ctrl?.controls.status.value;
      return status === null || status === undefined ? count + 1 : count;
    }, 0);
  }

  private makeResultFG(itemId: string, mengeSoll: number): ResultFG {
    return this.fb.group({
      item_id: this.fb.control(itemId, { nonNullable: true }),
      status: this.fb.control<CheckStatus | null>(null),
      menge_soll: this.fb.control<number | null>(mengeSoll ?? null),
      menge_aktuel: this.fb.control<number | null>(null),
      notiz: this.fb.control("", { nonNullable: true }),
    });
  }

  get checkedItemCount(): number {
    return this.form.controls.results.controls.filter((fg) => fg.controls.status.value !== null).length;
  }

  get totalItemCount(): number {
    return this.form.controls.results.length;
  }

  private buildForm(): void {
    const arr = this.form.controls.results;
    arr.clear();
    this.raeumeView = [];
    this.expandedItems.clear();
    this.collapsedRooms.clear();

    const fz = this.fahrzeug;
    if (!fz) return;

    for (const raum of fz.raeume ?? []) {
      const roomView: CheckRoomView = {
        name: raum.name,
        items: [],
      };
      this.collapsedRooms.add(raum.name);

      for (const item of raum.items ?? []) {
        const idx = arr.length;
        arr.push(this.makeResultFG(String(item.id), Number(item.menge)));
        roomView.items.push({
          index: idx,
          name: item.name,
          menge: Number(item.menge),
          einheit: item.einheit,
          notiz: item.notiz,
        });
      }

      this.raeumeView.push(roomView);
    }
  }

  expandAllRooms(): void {
    this.collapsedRooms.clear();
  }

  collapseAllRooms(): void {
    for (const raum of this.raeumeView) {
      this.collapsedRooms.add(raum.name);
    }
  }

  get allRoomsOpen(): boolean {
    return this.collapsedRooms.size === 0;
  }

  cancel(): void {
    this.router.navigate(["/fahrzeug-check"]);
  }

  submit(): void {
    this.form.controls.title.markAsTouched();
    if (this.form.controls.title.invalid) {
      this.uiMessageService.erstelleMessage("error", "Titel ist ein Pflichtfeld");
      return;
    }

    const selectedResults = this.form.controls.results.controls.filter((fg) => fg.controls.status.value !== null);

    if (selectedResults.length === 0) {
      this.uiMessageService.erstelleMessage("error", "Bitte mindestens einen Prüfpunkt markieren");
      return;
    }

    // Backend erwartet: { title?, notiz?, results: [{item_id,status,menge_aktuel?,notiz?}] }
    // Bei Teil-Checks werden nur tatsächlich markierte Punkte gesendet.
    const payload = {
      title: this.form.controls.title.value,
      notiz: this.form.controls.notiz.value,
      results: selectedResults.map((fg) => ({
        item_id: fg.controls.item_id.value,
        status: fg.controls.status.value,
        menge_aktuel:
          fg.controls.status.value === "ok"
            ? (fg.controls.menge_soll.value ?? null)
            : (fg.controls.menge_aktuel.value ?? null),
        notiz: fg.controls.notiz.value ?? "",
      })),
    };

    this.apiHttpService.post(`fahrzeuge/${this.fahrzeugId}/checks`, payload).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage("success", "Check gespeichert");
        this.router.navigate(["/fahrzeug-check"]);
      },
      error: (e) => this.authSessionService.errorAnzeigen(e),
    });
  }
}
