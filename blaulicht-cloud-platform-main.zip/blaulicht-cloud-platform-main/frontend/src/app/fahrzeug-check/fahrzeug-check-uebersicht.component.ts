import { CommonModule } from "@angular/common";
import { Component, OnInit, inject } from "@angular/core";
import { Router } from "@angular/router";

import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon";
import { MatProgressBarModule } from "@angular/material/progress-bar";
import { MatTooltipModule } from "@angular/material/tooltip";

import { ApiHttpService } from "src/app/_service/api-http.service";
import { AuthSessionService } from "src/app/_service/auth-session.service";
import { NavigationService } from "src/app/_service/navigation.service";
import { IFahrzeugList } from "../_interface/fahrzeug";
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from "../imr-ui-library";

@Component({
  standalone: true,
  selector: "app-fahrzeug-check-uebersicht",
  imports: [
    CommonModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    MatTooltipModule,
  ],
  templateUrl: "./fahrzeug-check-uebersicht.component.html",
  styleUrl: "./fahrzeug-check-uebersicht.component.sass",
})
export class FahrzeugCheckUebersichtComponent implements OnInit {
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private navigationService = inject(NavigationService);
  private router = inject(Router);

  breadcrumb: ImrBreadcrumbItem[] = [];
  fahrzeuge: IFahrzeugList[] = [];
  loading = true;
  rolesResolved = false;
  canOpenHistory = false;

  ngOnInit(): void {
    sessionStorage.setItem("PageNumber", "2");
    sessionStorage.setItem("Page2", "FZCHECK");
    this.breadcrumb = this.navigationService.ladeBreadcrumb();
    this.loadRoles();
    this.load();
  }

  private loadRoles(): void {
    this.apiHttpService.get<{ user?: { roles?: string[] | string } }>("modul_konfiguration").subscribe({
      next: (res) => {
        const roles = this.normalizeRoles(res?.user?.roles);
        this.canOpenHistory = roles.includes("ADMIN") || roles.includes("FAHRZEUG");
        this.rolesResolved = true;
      },
      error: () => {
        this.rolesResolved = true;
      },
    });
  }

  private normalizeRoles(value: unknown): string[] {
    if (Array.isArray(value)) {
      return value.map((role) => String(role).trim().toUpperCase()).filter(Boolean);
    }

    return String(value ?? "")
      .split(",")
      .map((role) => role.trim().toUpperCase())
      .filter(Boolean);
  }

  private load(): void {
    this.loading = true;
    this.apiHttpService.get<IFahrzeugList[]>("fahrzeuge").subscribe({
      next: (list) => {
        this.fahrzeuge = list;
        this.loading = false;
      },
      error: (e) => {
        this.authSessionService.errorAnzeigen(e);
        this.loading = false;
      },
    });
  }

  openCheck(fahrzeug: IFahrzeugList): void {
    this.router.navigate(["/fahrzeuge", fahrzeug.id, "check"]);
  }

  openHistory(fahrzeug: IFahrzeugList): void {
    this.router.navigate(["/fahrzeuge", fahrzeug.id, "check", "history"]);
  }
}
