import { CommonModule } from "@angular/common";
import { Component, OnInit, inject } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";

import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon";

import {
  IFahrzeugCheckHistoryEntry,
  IFahrzeugCheckProblemItem,
  IFahrzeugDetail,
} from "src/app/_interface/fahrzeug";
import { ApiHttpService } from "src/app/_service/api-http.service";
import { AuthSessionService } from "src/app/_service/auth-session.service";
import { NavigationService } from "src/app/_service/navigation.service";
import { UiMessageService } from "src/app/_service/ui-message.service";
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from "../imr-ui-library";

@Component({
  standalone: true,
  selector: "app-fahrzeug-check-history",
  imports: [
    CommonModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    MatButtonModule,
    MatIconModule,
  ],
  templateUrl: "./fahrzeug-check-history.component.html",
  styleUrl: "./fahrzeug-check-history.component.sass",
})
export class FahrzeugCheckHistoryComponent implements OnInit {
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  breadcrumb: ImrBreadcrumbItem[] = [];
  fahrzeugId = "";
  fahrzeugName = "";

  loading = true;
  rolesResolved = false;
  canAccessHistory = false;
  canDeleteHistory = false;

  checks: IFahrzeugCheckHistoryEntry[] = [];
  expandedChecks = new Set<string>();
  deletingChecks = new Set<string>();

  ngOnInit(): void {
    sessionStorage.setItem("PageNumber", "2");
    sessionStorage.setItem("Page2", "FZCHECK");
    this.breadcrumb = this.navigationService.ladeBreadcrumb();

    this.fahrzeugId = String(this.route.snapshot.paramMap.get("id") ?? "");
    if (!this.fahrzeugId) {
      this.loading = false;
      return;
    }

    this.loadVehicleName();
    this.resolveRolesAndLoadHistory();
  }

  private loadVehicleName(): void {
    this.apiHttpService.get<IFahrzeugDetail>(`fahrzeuge/${this.fahrzeugId}`).subscribe({
      next: (fahrzeug) => {
        this.fahrzeugName = fahrzeug.name ?? "";
      },
      error: () => {
        this.fahrzeugName = "";
      },
    });
  }

  private resolveRolesAndLoadHistory(): void {
    this.apiHttpService.get<{ user?: { roles?: string[] | string } }>("modul_konfiguration").subscribe({
      next: (res) => {
        const roles = this.normalizeRoles(res?.user?.roles);
        this.canAccessHistory = roles.includes("ADMIN") || roles.includes("FAHRZEUG");
        this.canDeleteHistory = this.canAccessHistory;
        this.rolesResolved = true;

        if (!this.canAccessHistory) {
          this.loading = false;
          this.uiMessageService.erstelleMessage("error", "Für die Historie wird die Rolle FAHRZEUG benötigt.");
          this.router.navigate(["/fahrzeug-check"]);
          return;
        }

        this.loadHistory();
      },
      error: () => {
        this.loading = false;
        this.rolesResolved = true;
        this.uiMessageService.erstelleMessage("error", "Rollen konnten nicht geladen werden.");
      },
    });
  }

  private normalizeRoles(value: unknown): string[] {
    if (Array.isArray(value)) {
      return value.map((role) => String(role).trim().toUpperCase()).filter(Boolean);
    }

    return String(value ?? "")
      .split(",")
      .map((role) => role.trim().toUpperCase())
      .filter(Boolean);
  }

  loadHistory(): void {
    this.loading = true;
    this.apiHttpService.get<IFahrzeugCheckHistoryEntry[]>(`fahrzeuge/${this.fahrzeugId}/checks/history`).subscribe({
      next: (checks) => {
        this.checks = checks ?? [];
        if (!this.fahrzeugName && this.checks.length > 0) {
          this.fahrzeugName = this.checks[0]?.fahrzeug_name ?? "";
        }
        this.loading = false;
      },
      error: (e) => {
        this.loading = false;
        this.authSessionService.errorAnzeigen(e);
      },
    });
  }

  backToOverview(): void {
    this.router.navigate(["/fahrzeug-check"]);
  }

  toggleExpanded(checkId: string): void {
    if (this.expandedChecks.has(checkId)) {
      this.expandedChecks.delete(checkId);
      return;
    }
    this.expandedChecks.add(checkId);
  }

  isExpanded(checkId: string): boolean {
    return this.expandedChecks.has(checkId);
  }

  hasProblems(check: IFahrzeugCheckHistoryEntry): boolean {
    return Number(check.problem_count ?? 0) > 0;
  }

  formatCreatedAt(value: string): string {
    const raw = String(value ?? "").trim();
    if (!raw) {
      return "-";
    }

    // Backend kann z. B. "01.06.2026T09:45:12" liefern (kein ISO). Das wird im Browser nicht immer geparst.
    const customMatch = raw.match(/^(\d{2})\.(\d{2})\.(\d{4})T(\d{2}):(\d{2})(?::\d{2})?$/);
    if (customMatch) {
      const [, day, month, year, hour, minute] = customMatch;
      return `${day}.${month}.${year} ${hour}:${minute}`;
    }

    const parsed = new Date(raw);
    if (!Number.isNaN(parsed.getTime())) {
      const day = String(parsed.getDate()).padStart(2, "0");
      const month = String(parsed.getMonth() + 1).padStart(2, "0");
      const year = parsed.getFullYear();
      const hour = String(parsed.getHours()).padStart(2, "0");
      const minute = String(parsed.getMinutes()).padStart(2, "0");
      return `${day}.${month}.${year} ${hour}:${minute}`;
    }

    return raw;
  }

  statusLabel(status: IFahrzeugCheckProblemItem["status"]): string {
    if (status === "missing") {
      return "Fehlt";
    }
    if (status === "damaged") {
      return "Beschädigt";
    }
    return "OK";
  }

  deleteCheck(check: IFahrzeugCheckHistoryEntry): void {
    if (!this.canDeleteHistory) {
      this.uiMessageService.erstelleMessage("error", "Für diese Aktion wird die Rolle FAHRZEUG benötigt.");
      return;
    }

    const confirmed = window.confirm("Diesen Check-Eintrag wirklich löschen?");
    if (!confirmed) {
      return;
    }

    this.deletingChecks.add(check.id);

    this.apiHttpService.delete(`fahrzeuge/${this.fahrzeugId}/checks`, check.id).subscribe({
      next: () => {
        this.checks = this.checks.filter((entry) => entry.id !== check.id);
        this.expandedChecks.delete(check.id);
        this.deletingChecks.delete(check.id);
        this.uiMessageService.erstelleMessage("success", "Check-Historieeintrag gelöscht.");
      },
      error: (e) => {
        this.deletingChecks.delete(check.id);
        this.authSessionService.errorAnzeigen(e);
      },
    });
  }
}
