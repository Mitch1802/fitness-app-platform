import { CommonModule } from '@angular/common';
import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { forkJoin } from 'rxjs';
import { IAufgabenContextResponse, IAufgabenTicket, IAufgabenUserOption, AufgabenStatus } from '../_interface/aufgaben';
import { ApiHttpService } from '../_service/api-http.service';
import { AuthSessionService } from '../_service/auth-session.service';
import { NavigationService } from '../_service/navigation.service';
import { UiMessageService } from '../_service/ui-message.service';
import { TABLE_PAGINATION_DEFAULT_PAGE_SIZE, TABLE_PAGINATION_PAGE_SIZE_OPTIONS } from '../_utils/table-pagination-options';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../imr-ui-library';

@Component({
  selector: 'app-aufgaben',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
  ],
  templateUrl: './aufgaben.component.html',
  styleUrl: './aufgaben.component.sass',
})
export class AufgabenComponent implements OnInit {
  private apiHttpService = inject(ApiHttpService);
  private authSessionService = inject(AuthSessionService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);
  private fb = inject(FormBuilder);

  title = 'Aufgaben und Tickets';
  modul = 'aufgaben';
  breadcrumb: ImrBreadcrumbItem[] = [];

  tickets: IAufgabenTicket[] = [];
  dataSource = new MatTableDataSource<IAufgabenTicket>([]);
  sichtbareSpalten: string[] = [
    'titel',
    'faellig',
    'status',
    'status_aktionen',
    'actions',
  ];
  readonly pageSizeOptions = TABLE_PAGINATION_PAGE_SIZE_OPTIONS.standard;
  readonly pageSize = TABLE_PAGINATION_DEFAULT_PAGE_SIZE.standard;

  users: IAufgabenUserOption[] = [];
  editId: string | null = null;
  erfassenOpen = false;
  aktuellerBenutzername = '-';
  aktuellerMelderName = '-';
  suchtext = '';
  statusFilter: AufgabenStatus | 'ALLE' = 'ALLE';
  canSeeAll = false;
  includeCreatedTickets = false;
  alleAnzeigen = false;
  private hasInitializedDateSort = false;

  readonly statusOptionen: { value: AufgabenStatus; label: string }[] = [
    { value: 'OFFEN', label: 'Offen' },
    { value: 'IN_BEARBEITUNG', label: 'In Bearbeitung' },
    { value: 'GESCHLOSSEN', label: 'Geschlossen' },
  ];

  formModul = this.fb.group({
    titel: this.fb.control('', { nonNullable: true, validators: [Validators.required] }),
    zustaendiger_user: this.fb.control<string | null>(null, { validators: [Validators.required] }),
    beschreibung: this.fb.control('', { nonNullable: true, validators: [Validators.required] }),
    zu_erledigen_bis: this.fb.control<string | null>(null),
    status: this.fb.control<AufgabenStatus>('OFFEN', { nonNullable: true, validators: [Validators.required] }),
    quelle_modul: this.fb.control('', { nonNullable: true }),
  });

  @ViewChild(MatPaginator) set matPaginator(p: MatPaginator | undefined) {
    if (p) {
      this.dataSource.paginator = p;
    }
  }

  @ViewChild(MatSort) set matSort(s: MatSort | undefined) {
    if (s) {
      this.dataSource.sort = s;
      this.applyInitialDateSort();
    }
  }

  ngOnInit(): void {
    sessionStorage.setItem('PageNumber', '2');
    sessionStorage.setItem('Page2', 'Aufgaben');
    this.breadcrumb = this.navigationService.ladeBreadcrumb();
    this.configureTableFilter();
    this.configureTableSort();
    this.loadData();
  }

  private configureTableSort(): void {
    this.dataSource.sortingDataAccessor = (row: IAufgabenTicket, columnId: string): string | number => {
      if (columnId === 'faellig') {
        const dateValue = this.parseSortableDateValue(row.zu_erledigen_bis);
        return dateValue ?? 0;
      }

      const rawValue = (row as unknown as Record<string, unknown>)[columnId];
      if (typeof rawValue === 'number') {
        return rawValue;
      }

      return String(rawValue || '').toLowerCase();
    };

    this.dataSource.sortData = (data: IAufgabenTicket[], sort: MatSort): IAufgabenTicket[] => {
      const active = sort.active;
      const direction = sort.direction;

      if (!active || direction === '') {
        return data;
      }

      const isAsc = direction === 'asc';

      return data.slice().sort((a, b) => {
        if (active === 'faellig') {
          const aDateValue = this.parseSortableDateValue(a.zu_erledigen_bis);
          const bDateValue = this.parseSortableDateValue(b.zu_erledigen_bis);
          const aHasDate = aDateValue !== null;
          const bHasDate = bDateValue !== null;

          // Leere/ungueltige Datumswerte immer ans Tabellenende schieben.
          if (!aHasDate && !bHasDate) {
            return 0;
          }
          if (!aHasDate) {
            return 1;
          }
          if (!bHasDate) {
            return -1;
          }
        }

        const valueA = this.dataSource.sortingDataAccessor(a, active);
        const valueB = this.dataSource.sortingDataAccessor(b, active);
        return this.compareSortValues(valueA, valueB, isAsc);
      });
    };
  }

  private applyInitialDateSort(): void {
    if (this.hasInitializedDateSort) {
      return;
    }

    const sort = this.dataSource.sort;
    if (!sort) {
      return;
    }

    sort.active = 'faellig';
    sort.direction = 'asc';
    sort.sortChange.emit({ active: sort.active, direction: sort.direction });
    this.hasInitializedDateSort = true;
  }

  private compareSortValues(valueA: string | number, valueB: string | number, isAsc: boolean): number {
    if (valueA < valueB) {
      return isAsc ? -1 : 1;
    }
    if (valueA > valueB) {
      return isAsc ? 1 : -1;
    }
    return 0;
  }

  private parseSortableDateValue(rawDate: string | null | undefined): number | null {
    if (!rawDate) {
      return null;
    }

    const trimmed = String(rawDate).trim();
    if (!trimmed) {
      return null;
    }

    // Zuerst deutsches Datumsformat parsen, um Browser-Locale-Missinterpretationen zu vermeiden.
    const match = trimmed.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s+(\d{1,2}):(\d{2}))?$/);
    if (match) {
      const day = Number(match[1]);
      const month = Number(match[2]);
      const year = Number(match[3]);
      const hour = Number(match[4] ?? 0);
      const minute = Number(match[5] ?? 0);

      const parsed = new Date(year, month - 1, day, hour, minute);
      if (
        parsed.getFullYear() === year
        && parsed.getMonth() === month - 1
        && parsed.getDate() === day
        && parsed.getHours() === hour
        && parsed.getMinutes() === minute
      ) {
        return parsed.getTime();
      }
    }

    // ISO-Daten (z.B. 2026-06-11 oder 2026-06-11T08:30:00Z) als Fallback.
    const isoLike = trimmed.match(/^\d{4}-\d{2}-\d{2}(?:[T\s].*)?$/);
    if (isoLike) {
      const isoParsed = Date.parse(trimmed);
      if (!Number.isNaN(isoParsed)) {
        return isoParsed;
      }
    }

    return null;
  }

  private configureTableFilter(): void {
    this.dataSource.filterPredicate = (row: IAufgabenTicket, rawFilter: string) => {
      const parsed = this.parseFilter(rawFilter);
      const haystack = [
        row.titel,
        row.beschreibung,
      ]
        .map((entry) => String(entry || '').toLowerCase())
        .join(' ');

      const textOk = !parsed.suchtext || haystack.includes(parsed.suchtext);
      const statusOk = parsed.status === 'ALLE' || row.status === parsed.status;

      return textOk && statusOk;
    };
  }

  private parseFilter(rawFilter: string): {
    suchtext: string;
    status: AufgabenStatus | 'ALLE';
  } {
    try {
      const parsed = JSON.parse(rawFilter) as {
        suchtext?: string;
        status?: AufgabenStatus | 'ALLE';
      };

      return {
        suchtext: String(parsed?.suchtext || '').trim().toLowerCase(),
        status: parsed?.status || 'ALLE',
      };
    } catch {
      return {
        suchtext: '',
        status: 'ALLE',
      };
    }
  }

  onFilterChange(): void {
    this.dataSource.filter = JSON.stringify({
      suchtext: this.suchtext,
      status: this.statusFilter,
    });
    this.dataSource.paginator?.firstPage();
  }

  private loadData(): void {
    const ticketParams: Record<string, string> = {};
    if (this.includeCreatedTickets) {
      ticketParams.include_created = '1';
    }
    if (this.alleAnzeigen) {
      ticketParams.alle = '1';
    }
    const params = Object.keys(ticketParams).length > 0 ? ticketParams : undefined;

    forkJoin({
      tickets: this.apiHttpService.get<IAufgabenTicket[]>(this.modul, params, true),
      context: this.apiHttpService.get<IAufgabenContextResponse>(`${this.modul}/context`),
    }).subscribe({
      next: ({ tickets, context }) => {
        this.tickets = Array.isArray(tickets) ? tickets : [];
        this.dataSource.data = this.tickets;
        this.applyInitialDateSort();
        this.users = Array.isArray(context?.users) ? context.users : [];
        this.aktuellerBenutzername = String(context?.current_user?.username || '-');
        this.canSeeAll = context?.can_see_all === true;
        this.updateMelderDisplay();
        this.onFilterChange();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  neu(): void {
    this.editId = null;
    this.formModul.reset({
      titel: '',
      zustaendiger_user: null,
      beschreibung: '',
      zu_erledigen_bis: null,
      status: 'OFFEN',
      quelle_modul: '',
    });
    this.updateMelderDisplay();
  }

  neueAufgabeStarten(): void {
    this.neu();
    this.erfassenOpen = true;
  }

  erfassungSchliessen(): void {
    this.erfassenOpen = false;
    this.neu();
  }

  bearbeiten(ticket: IAufgabenTicket): void {
    this.erfassenOpen = true;
    this.editId = ticket.id;
    this.formModul.setValue({
      titel: ticket.titel ?? '',
      zustaendiger_user: ticket.zustaendiger_user,
      beschreibung: ticket.beschreibung ?? '',
      zu_erledigen_bis: ticket.zu_erledigen_bis,
      status: ticket.status,
      quelle_modul: ticket.quelle_modul ?? '',
    });
    this.updateMelderDisplay(ticket.melder_username);
  }

  private updateMelderDisplay(editMelderName?: string): void {
    const cleanedEditName = String(editMelderName || '').trim();
    if (this.editId && cleanedEditName) {
      this.aktuellerMelderName = cleanedEditName;
      return;
    }

    this.aktuellerMelderName = this.aktuellerBenutzername || '-';
  }

  speichern(): void {
    if (this.formModul.invalid) {
      this.uiMessageService.erstelleMessage('error', 'Bitte die Pflichtfelder ausfuellen.');
      return;
    }

    const payload = {
      titel: this.formModul.controls.titel.value,
      zustaendiger_user: this.formModul.controls.zustaendiger_user.value,
      beschreibung: this.formModul.controls.beschreibung.value,
      zu_erledigen_bis: this.formModul.controls.zu_erledigen_bis.value,
      status: this.formModul.controls.status.value,
      quelle_modul: this.formModul.controls.quelle_modul.value,
    };

    if (this.editId) {
      this.apiHttpService.patch<IAufgabenTicket>(this.modul, this.editId, payload).subscribe({
        next: () => {
          this.uiMessageService.erstelleMessage('success', 'Ticket aktualisiert.');
          this.loadData();
          this.erfassungSchliessen();
        },
        error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
      });
      return;
    }

    this.apiHttpService.post<IAufgabenTicket>(this.modul, payload).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Ticket erstellt.');
        this.loadData();
        this.erfassungSchliessen();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  setzeStatus(ticket: IAufgabenTicket, status: AufgabenStatus): void {
    if (ticket.status === status) {
      return;
    }

    if (status === 'GESCHLOSSEN') {
      const confirmed = window.confirm(`Ticket "${ticket.titel}" wirklich auf Geschlossen setzen?`);
      if (!confirmed) {
        return;
      }
    }

    this.apiHttpService.patch<IAufgabenTicket>(this.modul, ticket.id, { status }).subscribe({
      next: () => {
        const statusText = this.getStatusLabel(status);
        this.uiMessageService.erstelleMessage('success', `Status geändert: ${statusText}`);

        if (this.editId === ticket.id) {
          this.formModul.controls.status.setValue(status);
        }

        this.loadData();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  alleAnzeigenToggle(): void {
    this.loadData();
  }

  includeCreatedTicketsToggle(): void {
    this.loadData();
  }

  loeschen(ticket: IAufgabenTicket): void {
    const confirmed = window.confirm(`Ticket „${ticket.titel}" wirklich löschen?`);
    if (!confirmed) {
      return;
    }

    this.apiHttpService.delete<void>(this.modul, ticket.id).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Ticket gelöscht.');
        this.loadData();
      },
      error: (error: unknown) => this.authSessionService.errorAnzeigen(error),
    });
  }

  getStatusLabel(status: AufgabenStatus): string {
    const match = this.statusOptionen.find((entry) => entry.value === status);
    return match?.label || status;
  }

  getStatusClass(status: AufgabenStatus): string {
    if (status === 'OFFEN') {
      return 'status-chip status-chip-offen';
    }
    if (status === 'IN_BEARBEITUNG') {
      return 'status-chip status-chip-inbearbeitung';
    }
    return 'status-chip status-chip-geschlossen';
  }

}
