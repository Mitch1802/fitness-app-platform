import { Component, OnInit, ViewChild, inject, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTabsModule } from '@angular/material/tabs';
import { A11yModule } from '@angular/cdk/a11y';
import QRCode from 'qrcode';
import {
  ImrBreadcrumbItem,
  ImrHeaderComponent,
  ImrPageLayoutComponent,
  ImrSectionComponent,
} from '../imr-ui-library';
import { ApiHttpService } from 'src/app/_service/api-http.service';
import { AuthSessionService } from 'src/app/_service/auth-session.service';
import { NavigationService } from 'src/app/_service/navigation.service';
import { UiMessageService } from 'src/app/_service/ui-message.service';
import { IFotoEvent, IFotoUpload } from 'src/app/_interface/fotoupload';
import {
  TABLE_PAGINATION_DEFAULT_PAGE_SIZE,
  TABLE_PAGINATION_PAGE_SIZE_OPTIONS,
} from '../_utils/table-pagination-options';
import { formatDateOutput, normalizeDateInput } from '../_utils/date-normalization.util';
import { DateInputMaskDirective } from '../_directive/date-input-mask.directive';

type ModulKonfigurationResponse = Record<string, unknown>;

@Component({
  selector: 'app-fotoupload',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ImrHeaderComponent,
    ImrPageLayoutComponent,
    ImrSectionComponent,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatTableModule,
    MatSortModule,
    MatTabsModule,
    MatDialogModule,
    A11yModule,
    DateInputMaskDirective,
  ],
  templateUrl: './fotoupload.component.html',
  styleUrl: './fotoupload.component.sass',
})
export class FotouploadComponent implements OnInit {
  @ViewChild('eventPaginator') set eventPaginator(p: MatPaginator | undefined) {
    if (p) this.eventDataSource.paginator = p;
  }
  @ViewChild('eventSort') set eventSort(s: MatSort | undefined) {
    if (s) {
      this.eventDataSource.sortingDataAccessor = (item: IFotoEvent, prop: string): string | number => {
        if (prop === 'datum') return item.datum ?? '';
        if (prop === 'upload_count') return item.upload_count;
        return String((item as unknown as Record<string, unknown>)[prop] ?? '').toLowerCase();
      };
      s.active = 'datum';
      s.direction = 'desc';
      this.eventDataSource.sort = s;
    }
  }

  @ViewChild('uploadPaginator') set uploadPaginator(p: MatPaginator | undefined) {
    if (p) this.uploadDataSource.paginator = p;
  }
  @ViewChild('uploadSort') set uploadSort(s: MatSort | undefined) {
    if (s) {
      this.uploadDataSource.sortingDataAccessor = (item: IFotoUpload, prop: string): string | number => {
        if (prop === 'created_at') return item.created_at;
        if (prop === 'foto_anzahl') return item.foto_anzahl;
        return String((item as unknown as Record<string, unknown>)[prop] ?? '').toLowerCase();
      };
      s.active = 'created_at';
      s.direction = 'desc';
      this.uploadDataSource.sort = s;
    }
  }

  @ViewChild('qrCanvas') qrCanvasRef?: ElementRef<HTMLCanvasElement>;

  private apiHttpService = inject(ApiHttpService);
  private http = inject(HttpClient);
  private authSessionService = inject(AuthSessionService);
  private navigationService = inject(NavigationService);
  private uiMessageService = inject(UiMessageService);

  readonly defaultPageSize = TABLE_PAGINATION_DEFAULT_PAGE_SIZE.standard;
  readonly pageSizeOptions = TABLE_PAGINATION_PAGE_SIZE_OPTIONS.standard;

  breadcrumb: ImrBreadcrumbItem[] = [];
  title = 'Fotoupload';

  isEventEditMode = false;
  showQrDialog = false;
  qrDataUrl = '';
  qrPublicUrl = '';

  // Data
  eventDataSource = new MatTableDataSource<IFotoEvent>([]);
  uploadDataSource = new MatTableDataSource<IFotoUpload>([]);
  allEvents: IFotoEvent[] = [];
  selectedEventId: string | null = null;
  meine_rollen: string[] = [];

  readonly eventSpalten: string[] = ['name', 'datum', 'sichtbar', 'upload_count', 'actions'];
  readonly uploadSpalten: string[] = ['uploader_name', 'event_name', 'foto_anzahl', 'created_at', 'actions'];

  // Forms
  formEvent = new FormGroup({
    id: new FormControl<string>(''),
    name: new FormControl<string>('', [Validators.required, Validators.maxLength(255)]),
    beschreibung: new FormControl<string>(''),
    datum: new FormControl<string>(''),
    sichtbar: new FormControl<boolean>(true),
  });

  get isAdmin(): boolean {
    return this.meine_rollen.includes('ADMIN');
  }

  ngOnInit(): void {
    sessionStorage.setItem('PageNumber', '2');
    sessionStorage.setItem('Page2', 'FOTUPL');
    this.breadcrumb = this.navigationService.ladeBreadcrumb();
    this.ladeRollen();
    this.ladeEvents();
    this.qrPublicUrl = `${window.location.origin}/public/fotoupload`;
  }

  // ── Data Loading ──────────────────────────────────────────────────────────

  private ladeRollen(): void {
    this.apiHttpService.get<ModulKonfigurationResponse>('modul_konfiguration').subscribe({
      next: (erg) => {
        const roles = (erg as { user?: { roles?: unknown } })?.user?.roles;
        this.meine_rollen = Array.isArray(roles)
          ? roles.map((r) => String(r).trim().toUpperCase()).filter(Boolean)
          : String(roles ?? '').split(',').map((r) => r.trim().toUpperCase()).filter(Boolean);
      },
      error: () => { this.meine_rollen = []; },
    });
  }

  ladeEvents(): void {
    this.apiHttpService.get<IFotoEvent[]>('fotoupload/events').subscribe({
      next: (data) => {
        this.allEvents = Array.isArray(data) ? data : [];
        this.eventDataSource.data = this.allEvents;
      },
      error: (err) => this.authSessionService.errorAnzeigen(err),
    });
  }

  ladeUploads(eventId?: string | null): void {
    const params = eventId ? { event_id: eventId } : undefined;
    this.apiHttpService.get<IFotoUpload[]>('fotoupload/uploads', params).subscribe({
      next: (data) => {
        this.uploadDataSource.data = Array.isArray(data) ? data : [];
      },
      error: (err) => this.authSessionService.errorAnzeigen(err),
    });
  }

  onTabChange(index: number): void {
    if (index === 1) {
      this.ladeUploads(this.selectedEventId);
    }
  }

  onEventFilterChange(): void {
    this.ladeUploads(this.selectedEventId);
  }

  // ── Event CRUD ────────────────────────────────────────────────────────────

  neuesEvent(): void {
    this.formEvent.reset({ sichtbar: true });
    this.formEvent.enable();
    this.isEventEditMode = true;
  }

  eventBearbeiten(event: IFotoEvent): void {
    this.formEvent.enable();
    this.formEvent.setValue({
      id: event.id,
      name: event.name,
      beschreibung: event.beschreibung ?? '',
      datum: event.datum ? this.formatDateForInput(event.datum) : '',
      sichtbar: event.sichtbar,
    });
    this.isEventEditMode = true;
  }

  eventAbbrechen(): void {
    this.formEvent.reset();
    this.formEvent.disable();
    this.isEventEditMode = false;
  }

  eventSpeichern(): void {
    if (this.formEvent.invalid) return;
    const val = this.formEvent.value;
    const id = val.id;
    const payload: Partial<IFotoEvent> = {
      name: val.name ?? '',
      beschreibung: val.beschreibung ?? '',
      datum: val.datum ? normalizeDateInput(val.datum) : null,
      sichtbar: val.sichtbar ?? true,
    };

    const req = id
      ? this.apiHttpService.patch<IFotoEvent>('fotoupload/events', id, payload)
      : this.apiHttpService.post<IFotoEvent>('fotoupload/events', payload);

    req.subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', id ? 'Event gespeichert.' : 'Event angelegt.');
        this.eventAbbrechen();
        this.ladeEvents();
      },
      error: (err) => this.authSessionService.errorAnzeigen(err),
    });
  }

  eventLoeschen(event: IFotoEvent): void {
    if (!confirm(`Event "${event.name}" wirklich löschen? Alle zugehörigen Uploads werden ebenfalls gelöscht.`)) return;
    this.apiHttpService.delete('fotoupload/events', event.id).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Event gelöscht.');
        this.ladeEvents();
      },
      error: (err) => this.authSessionService.errorAnzeigen(err),
    });
  }

  // ── Upload management ─────────────────────────────────────────────────────

  uploadLoeschen(upload: IFotoUpload): void {
    const event = this.allEvents.find((e) => e.id === upload.event);
    const eventName = event?.name ?? upload.event_name;
    if (!confirm(`Upload von "${upload.uploader_name}" (${upload.foto_anzahl} Fotos, Event: ${eventName}) wirklich löschen?`)) return;
    this.apiHttpService.delete('fotoupload/uploads', upload.id).subscribe({
      next: () => {
        this.uiMessageService.erstelleMessage('success', 'Upload gelöscht.');
        this.ladeUploads(this.selectedEventId);
        this.ladeEvents();
      },
      error: (err) => this.authSessionService.errorAnzeigen(err),
    });
  }

  zipHerunterladen(upload: IFotoUpload): void {
    this.http.get(`${this.apiHttpService.AppUrl}fotoupload/uploads/${upload.id}/download/`, { responseType: 'blob' }).subscribe({
      next: (blob) => {
        if (!blob || blob.size === 0) {
          this.uiMessageService.erstelleMessage('error', 'ZIP-Datei ist leer oder nicht verfügbar.');
          return;
        }
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${upload.uploader_name}_${upload.event_name}.zip`;
        a.click();
        URL.revokeObjectURL(url);
      },
      error: () => {
        this.uiMessageService.erstelleMessage('error', 'ZIP-Datei konnte nicht heruntergeladen werden.');
      },
    });
  }

  // ── QR Code ───────────────────────────────────────────────────────────────

  async qrCodeAnzeigen(): Promise<void> {
    this.showQrDialog = true;
    try {
      this.qrDataUrl = await QRCode.toDataURL(this.qrPublicUrl, {
        width: 400,
        margin: 2,
        color: { dark: '#000000', light: '#ffffff' },
      });
    } catch {
      this.uiMessageService.erstelleMessage('error', 'QR-Code konnte nicht generiert werden.');
    }
  }

  qrCodeSchliessen(): void {
    this.showQrDialog = false;
    this.qrDataUrl = '';
  }

  qrCodeDrucken(): void {
    const printWin = window.open('', '_blank');
    if (!printWin) return;
    printWin.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Fotoupload QR-Code</title>
          <style>
            body { display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; font-family: sans-serif; padding: 2rem; }
            img { width: 350px; height: 350px; }
            h2 { margin-bottom: 0.5rem; }
            p { color: #555; margin-top: 0.5rem; word-break: break-all; text-align: center; max-width: 400px; }
          </style>
        </head>
        <body>
          <h2>Fotos hochladen</h2>
          <img src="${this.qrDataUrl}" alt="QR-Code Fotoupload" />
          <p>${this.qrPublicUrl}</p>
          <script>window.onload = function(){ window.print(); window.close(); }</script>
        </body>
      </html>
    `);
    printWin.document.close();
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  private formatDateForInput(isoDate: string): string {
    if (!isoDate) return '';
    const [y, m, d] = isoDate.split('-');
    return `${d}.${m}.${y}`;
  }

  formatDateDisplay(isoDate: string | null): string {
    return formatDateOutput(isoDate);
  }

  formatDateTimeDisplay(isoDate: string): string {
    if (!isoDate) return '';
    const parsed = new Date(isoDate);
    if (!Number.isNaN(parsed.getTime())) {
      return parsed.toLocaleString('de-AT', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    }

    const isoMatch = String(isoDate).trim().match(/^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2}))?/);
    if (isoMatch) {
      const [, year, month, day, hour = '00', minute = '00'] = isoMatch;
      return `${day}.${month}.${year} ${hour}:${minute}`;
    }

    const dayFirstMatch = String(isoDate).trim().match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})(?:[ ,T](\d{1,2}):(\d{2}))?/);
    if (dayFirstMatch) {
      const [, day, month, year, hour = '00', minute = '00'] = dayFirstMatch;
      return `${day.padStart(2, '0')}.${month.padStart(2, '0')}.${year} ${hour.padStart(2, '0')}:${minute}`;
    }

    return '';
  }
}
