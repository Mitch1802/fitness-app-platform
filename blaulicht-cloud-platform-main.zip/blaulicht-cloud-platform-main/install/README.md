# Manuelle Installation und Updates

Dieses Dokument beschreibt die Schritte, die bei einer manuellen Installation oder einem manuellen Update auf dem Zielserver ausgeführt werden müssen.

Die Anleitung deckt vier Fälle ab:

1. Dev/Test Neuinstallation
2. Dev/Test Update
3. Produktion Neuinstallation
4. Produktion Update

## Grundlagen

Die Datei [app_manager.sh](app_manager.sh) arbeitet immer im Verzeichnis, in dem sie liegt. In demselben Verzeichnis muss auch die Datei [docker-compose.yml](docker-compose.yml) liegen.

Das Zielverzeichnis auf dem Server sollte daher wie folgt aussehen:

```text
/srv/blaulichtcloud/
  app_manager.sh
  docker-compose.yml
  .env
  .envs/
```

Das Skript erwartet:

1. Docker und Docker Compose auf dem Server.
2. Bash und OpenSSL auf dem Server.
3. Zugriff auf die GHCR-Images `ghcr.io/mitch1802/blaulichtcloud:*`.
4. Schreibrechte im Zielverzeichnis.
5. Eine freie Host-Port-Zuordnung, standardmäßig `2432`.
6. Eine vorhandene externe Docker-Network `blaulichtcloud_nw` oder die Berechtigung, sie anlegen zu lassen.
7. Optional eine Datei `.envs/.secrets` mit sensiblen Zugangsdaten.

Hinweis zu Windows:

Dieses Skript ist für Bash ausgelegt. Unter Windows bitte über WSL oder Git Bash ausführen.

Beispiel für optionale Secrets-Datei:

```bash
mkdir -p /srv/blaulichtcloud/.envs
cat > /srv/blaulichtcloud/.envs/.secrets <<'EOF'
BLAULICHTSMS_DASHBOARD_SESSION_ID=dein-session-token
DJANGO_EMAIL_HOST_PASSWORD=dein-smtp-passwort
EOF
chmod 600 /srv/blaulichtcloud/.envs/.secrets
```

Wenn `.envs/.secrets` nicht vorhanden ist, setzt das Skript diese Werte leer und gibt eine Warnung aus.

## Dateien bereitstellen

Vor jeder manuellen Installation oder jedem manuellen Update müssen die beiden Install-Dateien im Zielverzeichnis liegen.

Variante A: Direkt aus dem Repository laden

```bash
mkdir -p /srv/blaulichtcloud
cd /srv/blaulichtcloud

curl -fsSL -o app_manager.sh "https://raw.githubusercontent.com/Mitch1802/blaulicht-cloud-platform/main/install/app_manager.sh"
curl -fsSL -o docker-compose.yml "https://raw.githubusercontent.com/Mitch1802/blaulicht-cloud-platform/main/install/docker-compose.yml"
chmod +x app_manager.sh
```

Variante B: Dateien aus der CI oder lokal kopieren

```bash
mkdir -p /srv/blaulichtcloud
cp app_manager.sh /srv/blaulichtcloud/
cp docker-compose.yml /srv/blaulichtcloud/
chmod +x /srv/blaulichtcloud/app_manager.sh
```

Kurzer Check vor dem Start:

```bash
cd /srv/blaulichtcloud
test -f app_manager.sh
test -f docker-compose.yml
grep -q '^services:' docker-compose.yml
```

## Parameter des Skripts

Aufruf:

```bash
./app_manager.sh [install|update|rollback] [VERSION] [DOMAIN] [PORT] [DEV_CORS]
```

Bedeutung:

1. `install|update`: Aktion.
2. `VERSION`: Docker-Image-Version, zum Beispiel `test` oder `1.2.3`.
3. `DOMAIN`: Öffentliche Domain der Instanz.
4. `PORT`: Host-Port für Nginx, Standard `2432`.
5. `DEV_CORS`: `true` oder `false`. Bei `true` werden `localhost:4200` und `127.0.0.1:4200` für Frontend-Entwicklung in CORS und CSRF eingetragen.

Für `rollback` gilt:

1. Ohne VERSION wird auf `PREVIOUS_VERSION` aus `.env` zurückgesetzt.
2. Mit VERSION wird gezielt auf die angegebene Version zurückgesetzt.

Optionale Umgebungsvariablen:

1. `PUBLIC_FAHRZEUG_PIN`: Überschreibt den Default-Wert `2432` beim Erstellen der `.envs/.django`.
2. `BACKUP_ON_UPDATE`: `true` oder `false` (Default `true`). Steuert, ob vor einem Update ein Backup erstellt wird.
3. `BACKUP_DIR_NAME`: Name des Backup-Ordners unterhalb des Installationspfads (Default `backups`).

## Dev/Test Neuinstallation

Diese Variante ist für Testserver oder Entwicklungsumgebungen gedacht, die mit dem Test-Image laufen sollen.

```bash
mkdir -p /srv/blaulichtcloud
cd /srv/blaulichtcloud

curl -fsSL -o app_manager.sh "https://raw.githubusercontent.com/Mitch1802/blaulicht-cloud-platform/main/install/app_manager.sh"
curl -fsSL -o docker-compose.yml "https://raw.githubusercontent.com/Mitch1802/blaulicht-cloud-platform/main/install/docker-compose.yml"
chmod +x app_manager.sh

./app_manager.sh install test test.example.org 2432 true
```

Wirkung:

1. `.env`, `.envs/.django` und `.envs/.postgres` werden neu erzeugt.
2. Docker Network `blaulichtcloud_nw` wird bei Bedarf angelegt.
3. Die Images `api-test`, `db-test` und `nginx-test` werden gepullt und gestartet.
4. Ein Django-Admin-Benutzer wird erzeugt oder aktualisiert.
5. `DEV_CORS=true` erlaubt lokales Frontend gegen die Server-API.
6. Das initiale Admin-Passwort wird in `.envs/.admin-secrets` gespeichert.

Nachkontrolle:

```bash
cd /srv/blaulichtcloud
docker compose ps
docker compose logs --tail=100
```

## Dev/Test Update

Diese Variante aktualisiert eine bestehende Test- oder Entwicklungsinstanz.

```bash
cd /srv/blaulichtcloud

curl -fsSL -o app_manager.sh "https://raw.githubusercontent.com/Mitch1802/blaulicht-cloud-platform/main/install/app_manager.sh"
curl -fsSL -o docker-compose.yml "https://raw.githubusercontent.com/Mitch1802/blaulicht-cloud-platform/main/install/docker-compose.yml"
chmod +x app_manager.sh

./app_manager.sh update test test.example.org 2432 true
```

Wenn nur die Version aktualisiert werden soll und Domain sowie Port unverändert bleiben sollen:

```bash
cd /srv/blaulichtcloud
./app_manager.sh update test
```

Wenn nur Dev-CORS nachträglich aktiviert werden soll:

```bash
cd /srv/blaulichtcloud
./app_manager.sh update test "" "" true
```

Wirkung:

1. Vor dem Stoppen der Container wird ein Backup unter `backups/pre_update_<timestamp>/` erstellt (wenn `BACKUP_ON_UPDATE=true`).
2. Falls Postgres läuft, wird zusätzlich ein SQL-Dump in den Backup-Ordner geschrieben.
3. Container werden gestoppt.
4. `PREVIOUS_VERSION` und `VERSION` in `.env` werden aktualisiert.
5. Fehlende Basis-Variablen werden ergänzt.
6. Neue Images werden gepullt und die Container neu gestartet.
7. Nicht mehr benötigte Volumes und Images werden aufgeräumt.

## Produktion Neuinstallation

Diese Variante ist für einen neuen Produktivserver mit einer festen Release-Version gedacht.

```bash
mkdir -p /srv/blaulichtcloud
cd /srv/blaulichtcloud

curl -fsSL -o app_manager.sh "https://raw.githubusercontent.com/Mitch1802/blaulicht-cloud-platform/main/install/app_manager.sh"
curl -fsSL -o docker-compose.yml "https://raw.githubusercontent.com/Mitch1802/blaulicht-cloud-platform/main/install/docker-compose.yml"
chmod +x app_manager.sh

./app_manager.sh install 1.2.3 blaulichtcloud.example.org 2432 false
```

Empfehlung für Produktion nach dem ersten Start:

1. `.envs/.django` prüfen.
2. `DJANGO_SECURE_SSL_REDIRECT` bei sauberem HTTPS-Setup auf `True` setzen.
3. Mail-Zugangsdaten und sonstige Standardwerte prüfen.
4. Admin-Passwort nach der Installation sofort ändern.
5. Falls nicht bereits gesetzt: `BLAULICHTSMS_DASHBOARD_SESSION_ID` und `DJANGO_EMAIL_HOST_PASSWORD` in `.envs/.django` oder `.envs/.secrets` setzen.

Kurzer Health-Check:

```bash
cd /srv/blaulichtcloud
docker compose ps
docker compose logs api --tail=100
docker compose logs nginx --tail=100
```

## Produktion Update

Diese Variante aktualisiert eine bestehende Produktivinstanz auf eine neue Release-Version.

Verbindlicher Ablauf (Token aus libuadmin-Frontend):

1. Release auf GitHub erstellen.
2. Production-Token im libuadmin-Frontend erzeugen.
3. Auf dem Produktivserver nach /srv/blaulichtcloud wechseln.
4. app_manager.sh und docker-compose.yml mit curl und Token laden.
5. app_manager.sh update VERSION ausführen.

Manueller Ablauf direkt auf dem Produktivserver:

```bash
cd /srv/blaulichtcloud

VERSION=1.2.3
TOKEN='frontend-token-aus-libuadmin'
PLATFORM_URL='https://libu-test.michael-web.at'

curl -fsSL -o app_manager.sh "${PLATFORM_URL}/api/v1/downloads/blaulichtcloud/app_manager.sh?token=${TOKEN}"
curl -fsSL -o docker-compose.yml "${PLATFORM_URL}/api/v1/downloads/blaulichtcloud/docker-compose.yml?token=${TOKEN}"
chmod +x app_manager.sh

./app_manager.sh update "$VERSION"
```

Nach erfolgreichem Update den verwendeten Token im libuadmin-Frontend widerrufen.

Falls Domain oder Port mit geändert werden sollen:

```bash
cd /srv/blaulichtcloud
./app_manager.sh update 1.2.3 blaulichtcloud.example.org 2432 false
```

Wichtig für Produktion:

1. Nur Release-Versionen wie `1.2.3` verwenden, nicht `test`.
2. `DEV_CORS` auf `false` belassen.
3. Vor dem Update sicherstellen, dass die gewünschten Images bereits in GHCR verfügbar sind.
4. Für private GHCR-Images müssen auf dem Zielserver `GHCR_USER` und `GHCR_TOKEN` gesetzt sein.

Rollback-Hinweis:

1. Nach dem Update steht die vorherige Version in `.env` als `PREVIOUS_VERSION`.
2. Für einen schnellen Rollback kann diese Version wieder als `VERSION` gesetzt und das Update erneut gestartet werden.
3. Falls vorhanden, kann der SQL-Dump aus dem zuletzt erzeugten Backup-Ordner eingespielt werden.

Rollback direkt über das Skript:

```bash
cd /srv/blaulichtcloud
./app_manager.sh rollback
```

Oder auf eine feste Version:

```bash
cd /srv/blaulichtcloud
./app_manager.sh rollback 1.2.3
```

## Manuelle Prüfungen nach Installation oder Update

Diese Checks sollten nach jedem manuellen Eingriff ausgeführt werden:

```bash
cd /srv/blaulichtcloud
docker compose ps
docker compose logs --tail=100
cat .env
cat .envs/.django
```

Zusätzliche Prüfungen für den Webzugriff:

```bash
curl -I http://127.0.0.1:2432
```

Wenn HTTPS über einen Reverse Proxy davor liegt, zusätzlich die öffentliche Domain prüfen.

## Manuelle Wartungsprüfung und E-Mail-Versand

Es gibt zwei unterschiedliche Wege, die Wartungsprüfung manuell anzustoßen:

1. **Manuelle Erinnerungsprüfung** über das Management-Command. Das ist flexibel und prüft einen frei wählbaren Zeitraum.
2. **Exakte Celery-Prüfung** über den Hintergrund-Task. Das ist derselbe Job, der auch täglich um 5 Uhr läuft.

### 1. Manuelle Erinnerungsprüfung

Diese Variante sucht alle Einträge, die in den nächsten Tagen fällig werden, und sendet die Erinnerungs-Mail an die konfigurierte Feuerwehr-E-Mail-Adresse.

Dry-Run, nur Ausgabe ohne Mailversand:

```bash
cd /srv/blaulichtcloud
docker compose exec api python manage.py send_service_reminders --days 30 --dry-run
```

Mit Mailversand:

```bash
cd /srv/blaulichtcloud
docker compose exec api python manage.py send_service_reminders --days 30
```

Mit abweichendem Empfänger:

```bash
cd /srv/blaulichtcloud
docker compose exec api python manage.py send_service_reminders --days 30 --recipient test@example.com
```

### 2. Exakte Celery-Prüfung

Diese Variante stößt den täglichen 5-Uhr-Job direkt an. Sie prüft also genau die Logik, die auch über Celery Beat läuft.

```bash
cd /srv/blaulichtcloud
docker compose exec api python manage.py shell -c "from core_apps.wartung_service.tasks import check_service_expiry; check_service_expiry.delay()"
```

Wichtig für diese Variante:

1. Redis muss laufen.
2. Der Celery-Worker muss laufen.
3. Der Task landet sonst nur in der Queue und wird nicht abgearbeitet.

### Prüfen, ob es gelaufen ist

Nach dem Start kannst du die Logs ansehen:

```bash
cd /srv/blaulichtcloud
docker compose logs -f celery_worker
docker compose logs -f celery_beat
docker compose logs -f api
```

## Typische Fehlerbilder

`docker compose` meldet YAML-Fehler:

1. Prüfen, ob die aktuelle `docker-compose.yml` wirklich aus [docker-compose.yml](docker-compose.yml) stammt.
2. Prüfen, ob statt YAML eine Fehlerseite oder ein `404` gespeichert wurde.
3. Vor dem nächsten Update die Datei erneut sauber kopieren oder herunterladen.

`docker compose pull` findet keine Images:

1. Existiert die gewünschte Version in GHCR?
2. Stimmen `VERSION` und Image-Tag zusammen?
3. Falls Registry-Zugriff geschützt ist, ist ein Login auf dem Server erforderlich.

Frontend kann lokal nicht gegen die API entwickeln:

1. `DEV_CORS=true` verwenden.
2. Danach `.envs/.django` auf `DJANGO_CORS_ALLOWED_ORIGINS` und `DJANGO_CSRF_TRUSTED_ORIGINS` prüfen.

## Bezug zur CI/CD

Die GitHub-Actions-Deployments verwenden dieselben beiden Dateien aus dem Verzeichnis [install](.) und rufen auf dem Zielserver ebenfalls `./app_manager.sh update ...` auf. Für Produktion ist ein im libuadmin-Frontend erzeugter Token als Workflow-Input verpflichtend. Die manuelle Anleitung hier ist die Referenz für den Notfallbetrieb ohne GitHub Actions.
