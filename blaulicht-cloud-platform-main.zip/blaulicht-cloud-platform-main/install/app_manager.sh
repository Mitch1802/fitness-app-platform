#!/usr/bin/env bash
set -euo pipefail

#############################################
# FESTE VARIABLEN
#############################################
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_PATH="${INSTALL_PATH:-$SCRIPT_DIR}"
API_VERSION="api/v1/"
SOFTWARE_NAME="blaulichtcloud"
NETWORK_NAME="blaulichtcloud_nw"
DEBUG=False
SECURE_SSL_REDIRECT_DEFAULT=False
GHCR_USER="${GHCR_USER:-}"
GHCR_TOKEN="${GHCR_TOKEN:-}"
DEFAULT_PUBLIC_FAHRZEUG_PIN="${PUBLIC_FAHRZEUG_PIN:-2432}"
BACKUP_ON_UPDATE="${BACKUP_ON_UPDATE:-true}"
BACKUP_DIR_NAME="${BACKUP_DIR_NAME:-backups}"

ACTION=${1:-""}
INPUT_VERSION=${2:-""}
VERSION=${INPUT_VERSION:-"1.0.0"}
DOMAIN=${3:-"blaulichtcloud.michael-web.at"}
PORT=${4:-"2432"}
DEV_CORS=$(echo "${5:-false}" | tr '[:upper:]' '[:lower:]')

DOMAIN_PROVIDED=false
PORT_PROVIDED=false
DEV_CORS_PROVIDED=false
if [ $# -ge 3 ] && [ -n "${3:-}" ]; then
    DOMAIN_PROVIDED=true
fi
if [ $# -ge 4 ] && [ -n "${4:-}" ]; then
    PORT_PROVIDED=true
fi
if [ $# -ge 5 ] && [ -n "${5:-}" ]; then
    DEV_CORS_PROVIDED=true
fi

if [ "$ACTION" != "install" ] && [ "$ACTION" != "update" ] && [ "$ACTION" != "rollback" ]; then
    echo "Usage: app_manager.sh [install|update|rollback] [VERSION] [DOMAIN] [PORT] [DEV_CORS]"
    echo "Beispiel für Update einer neuen Version: ./app_manager.sh update 1.0.0"
    echo "Beispiel für Rollback auf PREVIOUS_VERSION: ./app_manager.sh rollback"
    echo "Beispiel für Rollback auf eine konkrete Version: ./app_manager.sh rollback 1.2.3"
    exit 1
fi

if [ "$DEV_CORS" != "true" ] && [ "$DEV_CORS" != "false" ]; then
    echo "Fehler: DEV_CORS muss 'true' oder 'false' sein."
    echo "Beispiel: ./app_manager.sh install 1.0.0 example.com 2432 true"
    exit 1
fi

function upsert_env_var() {
    local file="$1"
    local key="$2"
    local value="$3"
    local tmp_file

    if grep -q "^${key}=" "$file"; then
        tmp_file="${file}.tmp.$$"
        awk -v key="$key" -v value="$value" '
            BEGIN { updated = 0 }
            {
                if ($0 ~ ("^" key "=")) {
                    print key "=" value
                    updated = 1
                } else {
                    print
                }
            }
            END {
                if (updated == 0) {
                    print key "=" value
                }
            }
        ' "$file" > "$tmp_file"
        mv "$tmp_file" "$file"
    else
        echo "${key}=${value}" >> "$file"
    fi
}

function ensure_file_exists() {
    local file="$1"
    local dir
    dir="$(dirname "$file")"
    mkdir -p "$dir"
    touch "$file"
}

function set_env_var_if_missing() {
    local file="$1"
    local key="$2"
    local value="$3"

    if ! grep -q "^${key}=" "$file"; then
        echo "${key}=${value}" >> "$file"
    fi
}

function ensure_ghcr_login() {
    if [ -n "$GHCR_USER" ] && [ -n "$GHCR_TOKEN" ]; then
        echo "Authentifiziere gegen ghcr.io als $GHCR_USER ..."
        printf '%s' "$GHCR_TOKEN" | docker login ghcr.io -u "$GHCR_USER" --password-stdin
    else
        echo "Hinweis: GHCR_USER/GHCR_TOKEN nicht gesetzt. Falls Pull fehlschlaegt:"
        echo "  export GHCR_USER='<github-user>'"
        echo "  export GHCR_TOKEN='<github-token-mit-read:packages>'"
    fi
}

function require_command() {
    local cmd="$1"
    if ! command -v "$cmd" >/dev/null 2>&1; then
        echo "Fehler: Benoetigter Befehl '$cmd' wurde nicht gefunden."
        exit 1
    fi
}

function ensure_prerequisites() {
    require_command docker
    require_command openssl
    if ! docker compose version >/dev/null 2>&1; then
        echo "Fehler: Docker Compose (docker compose) ist nicht verfuegbar."
        exit 1
    fi
}

function ensure_compose_file_exists() {
    if [ ! -f "$INSTALL_PATH/docker-compose.yml" ]; then
        echo "Fehler: $INSTALL_PATH/docker-compose.yml wurde nicht gefunden."
        echo "Lege app_manager.sh und docker-compose.yml ins gleiche Verzeichnis."
        exit 1
    fi
}

function print_platform_hint() {
    local uname_out
    uname_out="$(uname -s 2>/dev/null || echo unknown)"
    case "$uname_out" in
        Linux*|Darwin*)
            ;;
        *)
            echo "Hinweis: Dieses Skript ist fuer Bash auf Linux/macOS ausgelegt (unter Windows via WSL/Git Bash)."
            ;;
    esac
}

function read_env_value() {
    local file="$1"
    local key="$2"
    grep -E "^${key}=" "$file" | tail -n 1 | cut -d'=' -f2- || true
}

function load_optional_secrets() {
    local secrets_file="$INSTALL_PATH/.envs/.secrets"
    if [ -f "$secrets_file" ]; then
        set -a
        # shellcheck disable=SC1090
        . "$secrets_file"
        set +a
        echo "Optionale Secrets aus $secrets_file geladen."
    fi
}

function ensure_network_exists() {
    if [ -z "$(docker network ls --filter name=^$NETWORK_NAME$ --format='{{ .Name }}')" ]; then
        docker network create "$NETWORK_NAME"
        echo "Netzwerk $NETWORK_NAME erstellt."
    else
        echo "Netzwerk $NETWORK_NAME existiert bereits."
    fi
}

function maybe_backup_before_update() {
    local backup_root
    local timestamp
    local backup_dir
    local pg_user
    local pg_db
    local backup_file

    if [ "$BACKUP_ON_UPDATE" != "true" ]; then
        echo "Backup vor Update uebersprungen (BACKUP_ON_UPDATE=$BACKUP_ON_UPDATE)."
        return
    fi

    backup_root="$INSTALL_PATH/$BACKUP_DIR_NAME"
    timestamp="$(date +%Y%m%d_%H%M%S)"
    backup_dir="$backup_root/pre_update_$timestamp"
    mkdir -p "$backup_dir"

    if [ -f ".env" ]; then
        cp ".env" "$backup_dir/.env"
    fi
    if [ -d ".envs" ]; then
        cp -R ".envs" "$backup_dir/.envs"
    fi

    if docker compose ps --services --filter status=running | grep -q '^postgres$'; then
        if [ -f ".envs/.postgres" ]; then
            pg_user="$(read_env_value ".envs/.postgres" "POSTGRES_USER")"
            pg_db="$(read_env_value ".envs/.postgres" "POSTGRES_DB")"
            if [ -n "$pg_user" ] && [ -n "$pg_db" ]; then
                backup_file="$backup_dir/postgres_${pg_db}.sql"
                if docker compose exec -T postgres pg_dump -U "$pg_user" "$pg_db" > "$backup_file"; then
                    echo "Postgres-Dump erstellt: $backup_file"
                else
                    echo "Warnung: Postgres-Dump fehlgeschlagen. Update laeuft weiter."
                    rm -f "$backup_file"
                fi
            fi
        fi
    else
        echo "Hinweis: Postgres-Container laeuft nicht. DB-Dump wird uebersprungen."
    fi

    echo "Backup erstellt unter: $backup_dir"
}

#############################################
# FUNKTION: Installation
#############################################
function do_install() {
    echo "----------------------------------------"
    echo "INSTALLATION WIRD GESTARTET (Version: $VERSION)"
    echo "----------------------------------------"

    # Ordner anlegen
    if [ ! -d "$INSTALL_PATH" ]; then
        mkdir -p "$INSTALL_PATH"
        echo "Ordner $INSTALL_PATH wurde angelegt."
    fi

    # Env-Dateien generieren
    DJANGO_SECRET_KEY=$(openssl rand -hex 32)
    POSTGRES_PASSWORD=$(openssl rand -hex 16)

    mkdir -p "$INSTALL_PATH/.envs"
    load_optional_secrets

    SMS_DASHBOARD_SESSION_ID="${BLAULICHTSMS_DASHBOARD_SESSION_ID:-}"
    EMAIL_HOST_PASSWORD="${DJANGO_EMAIL_HOST_PASSWORD:-}"

    cat <<EOF > "$INSTALL_PATH/.env"
DOMAIN=$DOMAIN
NAME=$SOFTWARE_NAME
VERSION=$VERSION
HOST_PORT=$PORT
EOF

    # Zusätzliche Hilfsvariable, die ggf. '-demo' entfernt:
    VERSION_CLEAN=${VERSION/-demo/}
    APP_ORIGIN="https://$DOMAIN"
    CORS_ORIGINS="$APP_ORIGIN"
    CSRF_TRUSTED_ORIGINS="$APP_ORIGIN"

    if [ "$DEV_CORS" = "true" ]; then
        CORS_ORIGINS="http://localhost:4200,http://127.0.0.1:4200,$APP_ORIGIN"
        CSRF_TRUSTED_ORIGINS="http://localhost:4200,http://127.0.0.1:4200,$APP_ORIGIN"
    fi

    cat <<EOF > "$INSTALL_PATH/.envs/.django"
DJANGO_SECRET_KEY=$DJANGO_SECRET_KEY
DJANGO_DEBUG=$DEBUG
DJANGO_API_URL=$API_VERSION
VERSION=$VERSION_CLEAN
PUBLIC_FAHRZEUG_PIN=$DEFAULT_PUBLIC_FAHRZEUG_PIN
DJANGO_ALLOWED_HOSTS=localhost,127.0.0.1,$DOMAIN
DJANGO_CORS_ALLOWED_ORIGINS=$CORS_ORIGINS
DJANGO_CSRF_TRUSTED_ORIGINS=$CSRF_TRUSTED_ORIGINS
DJANGO_SECURE_SSL_REDIRECT=$SECURE_SSL_REDIRECT_DEFAULT
BLAULICHTSMS_API_URL=https://api.blaulichtsms.net/blaulicht
BLAULICHTSMS_DASHBOARD_SESSION_ID=$SMS_DASHBOARD_SESSION_ID
DJANGO_EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
DJANGO_EMAIL_HOST=smtp.world4you.com
DJANGO_EMAIL_PORT=587
DJANGO_EMAIL_USE_TLS=True
DJANGO_EMAIL_HOST_USER=app@blaulichtcloud.at
DJANGO_EMAIL_HOST_PASSWORD=$EMAIL_HOST_PASSWORD
DJANGO_DEFAULT_FROM_EMAIL=app@blaulichtcloud.at
DJANGO_EMAIL_TIMEOUT=10
CELERY_BROKER_URL=redis://redis:6379/0
CELERY_RESULT_BACKEND=redis://redis:6379/0
USER_INVITE_TOKEN_TTL_HOURS=48
EOF

    POSTGRES_USER_VALUE="${POSTGRES_USER:-app_user_$(openssl rand -hex 4)}"
    DB_URL="postgres://$POSTGRES_USER_VALUE:$POSTGRES_PASSWORD@postgres:5432/app-live"

    cat <<EOF > "$INSTALL_PATH/.envs/.postgres"
POSTGRES_HOST=postgres
POSTGRES_PORT=5432
POSTGRES_DB=app-live
POSTGRES_USER=$POSTGRES_USER_VALUE
POSTGRES_PASSWORD=$POSTGRES_PASSWORD
DATABASE_URL=$DB_URL
EOF

    if [ -z "$SMS_DASHBOARD_SESSION_ID" ]; then
        echo "Warnung: BLAULICHTSMS_DASHBOARD_SESSION_ID ist leer. Bitte in .envs/.django setzen."
    fi
    if [ -z "$EMAIL_HOST_PASSWORD" ]; then
        echo "Warnung: DJANGO_EMAIL_HOST_PASSWORD ist leer. Bitte in .envs/.django setzen."
    fi

    echo "ENV-Dateien erstellt unter $INSTALL_PATH."

    # Netzwerk erstellen (falls nicht vorhanden)
    ensure_network_exists

    cd "$INSTALL_PATH"
    ensure_ghcr_login
    echo "Ziehe Docker Images (pull) ..."
    docker compose pull

    # Container neu starten
    docker compose up -d

    echo "Warte 30 Sekunden, damit alles initialisiert ..."
    sleep 30

    # Django Superuser: Passwort generieren und setzen
    SUPERUSER_PASSWORD=$(openssl rand -hex 4)
    ADMIN_SECRET_FILE="$INSTALL_PATH/.envs/.admin-secrets"
    echo "Erstelle Django-Superuser (zufälliges Passwort wird gesetzt)"

    docker compose exec api python manage.py shell -c "\
from django.contrib.auth import get_user_model; \
from core_apps.users.models import Role; \
User = get_user_model(); \
# Superuser anlegen/aktualisieren
u, _ = User.objects.get_or_create(username='admin'); \
u.is_superuser = True; \
u.is_staff = True; \
u.set_password('$SUPERUSER_PASSWORD'); \
u.save(); \
# Rollen anlegen, falls nicht vorhanden
r_admin, _ = Role.objects.get_or_create(key='ADMIN', defaults={'verbose_name': 'ADMIN'}); \
r_member, _ = Role.objects.get_or_create(key='MITGLIED', defaults={'verbose_name': 'MITGLIED'}); \
# Nur ADMIN-Rolle zuweisen
u.roles.set([r_admin]); \
u.save(); \
print('Admin-Passwort gesetzt: $SUPERUSER_PASSWORD'); \
print('Rollen zugewiesen:', [r.key for r in u.roles.all()])"

    cat <<EOF > "$ADMIN_SECRET_FILE"
ADMIN_USERNAME=admin
ADMIN_PASSWORD=$SUPERUSER_PASSWORD
EOF
    chmod 600 "$ADMIN_SECRET_FILE" || true
    echo "Admin-Zugang in $ADMIN_SECRET_FILE gespeichert. Bitte nach Erstlogin entfernen."

    echo "----------------------------------------"
    echo "INSTALLATION ABGESCHLOSSEN."
    echo "----------------------------------------"
}

#############################################
# FUNKTION: Update
#############################################
function do_update() {
    echo "----------------------------------------"
    echo "UPDATE WIRD GESTARTET (Version: $VERSION)"
    echo "----------------------------------------"

    if [ ! -d "$INSTALL_PATH" ]; then
        echo "Fehler: Installationspfad $INSTALL_PATH existiert nicht."
        echo "Bitte zuerst install ausführen, oder Pfad anpassen."
        exit 1
    fi
    cd "$INSTALL_PATH"
    load_optional_secrets

    ensure_file_exists ".env"
    ensure_file_exists ".envs/.django"
    ensure_file_exists ".envs/.postgres"

    SMS_DASHBOARD_SESSION_ID="${BLAULICHTSMS_DASHBOARD_SESSION_ID:-}"
    EMAIL_HOST_PASSWORD="${DJANGO_EMAIL_HOST_PASSWORD:-}"

    CURRENT_VERSION="$(read_env_value ".env" "VERSION")"
    if [ -n "$CURRENT_VERSION" ]; then
        upsert_env_var ".env" "PREVIOUS_VERSION" "$CURRENT_VERSION"
    fi

    maybe_backup_before_update

    # Container stoppen
    docker compose down

    # # Docker-Compose neu herunterladen
    # echo "Aktualisiere docker-compose.yml aus GitHub ..."
    # curl -sSL -o "docker-compose.yml" \
    #     "https://raw.githubusercontent.com/Mitch1802/blaulicht-cloud-platform/main/install/docker-compose.yml" || {
    #     echo "Fehler beim Herunterladen der docker-compose.yml"
    #     exit 1
    # }

    # Versions-Eintrag in Env-Files aktualisieren
    echo "Aktualisiere Versionseintrag auf $VERSION in Env-Files ..."
    upsert_env_var ".env" "VERSION" "$VERSION"
    set_env_var_if_missing ".env" "NAME" "$SOFTWARE_NAME"

    if [ "$PORT_PROVIDED" = true ]; then
        upsert_env_var ".env" "HOST_PORT" "$PORT"
    else
        set_env_var_if_missing ".env" "HOST_PORT" "$PORT"
    fi

    # Security-/Host-Variablen in .envs/.django ergänzen/aktualisieren
    DOMAIN_CURRENT=$(grep -E '^DOMAIN=' .env | cut -d'=' -f2- || true)
    if [ -z "$DOMAIN_CURRENT" ]; then
        DOMAIN_CURRENT="$DOMAIN"
    fi

    if [ "$DOMAIN_PROVIDED" = true ]; then
        upsert_env_var ".env" "DOMAIN" "$DOMAIN"
        DOMAIN_CURRENT="$DOMAIN"
    else
        set_env_var_if_missing ".env" "DOMAIN" "$DOMAIN_CURRENT"
    fi

    # Core-Variablen in .envs/.django ergänzen/aktualisieren
    set_env_var_if_missing ".envs/.django" "DJANGO_DEBUG" "$DEBUG"
    set_env_var_if_missing ".envs/.django" "DJANGO_API_URL" "$API_VERSION"
    upsert_env_var ".envs/.django" "VERSION" "${VERSION/-demo/}"
    set_env_var_if_missing ".envs/.django" "PUBLIC_FAHRZEUG_PIN" "$DEFAULT_PUBLIC_FAHRZEUG_PIN"
    set_env_var_if_missing ".envs/.django" "BLAULICHTSMS_API_URL" "https://api.blaulichtsms.net/blaulicht"
    set_env_var_if_missing ".envs/.django" "BLAULICHTSMS_DASHBOARD_SESSION_ID" "$SMS_DASHBOARD_SESSION_ID"
    set_env_var_if_missing ".envs/.django" "DJANGO_EMAIL_BACKEND" "django.core.mail.backends.smtp.EmailBackend"
    set_env_var_if_missing ".envs/.django" "DJANGO_EMAIL_HOST" "smtp.world4you.com"
    set_env_var_if_missing ".envs/.django" "DJANGO_EMAIL_PORT" "587"
    set_env_var_if_missing ".envs/.django" "DJANGO_EMAIL_USE_TLS" "True"
    set_env_var_if_missing ".envs/.django" "DJANGO_EMAIL_HOST_USER" "app@blaulichtcloud.at"
    set_env_var_if_missing ".envs/.django" "DJANGO_EMAIL_HOST_PASSWORD" "$EMAIL_HOST_PASSWORD"
    set_env_var_if_missing ".envs/.django" "DJANGO_DEFAULT_FROM_EMAIL" "app@blaulichtcloud.at"
    set_env_var_if_missing ".envs/.django" "DJANGO_EMAIL_TIMEOUT" "10"
    set_env_var_if_missing ".envs/.django" "CELERY_BROKER_URL" "redis://redis:6379/0"
    set_env_var_if_missing ".envs/.django" "CELERY_RESULT_BACKEND" "redis://redis:6379/0"

    if [ -z "$SMS_DASHBOARD_SESSION_ID" ]; then
        echo "Warnung: BLAULICHTSMS_DASHBOARD_SESSION_ID ist leer."
    fi
    if [ -z "$EMAIL_HOST_PASSWORD" ]; then
        echo "Warnung: DJANGO_EMAIL_HOST_PASSWORD ist leer."
    fi


    APP_ORIGIN="https://$DOMAIN_CURRENT"
    CORS_ORIGINS="$APP_ORIGIN"
    CSRF_TRUSTED_ORIGINS="$APP_ORIGIN"

    if [ "$DEV_CORS" = "true" ]; then
        CORS_ORIGINS="http://localhost:4200,http://127.0.0.1:4200,$APP_ORIGIN"
        CSRF_TRUSTED_ORIGINS="http://localhost:4200,http://127.0.0.1:4200,$APP_ORIGIN"
    fi

    if [ "$DOMAIN_PROVIDED" = true ]; then
        upsert_env_var ".envs/.django" "DJANGO_ALLOWED_HOSTS" "$DOMAIN_CURRENT,localhost,127.0.0.1"
        upsert_env_var ".envs/.django" "DJANGO_CORS_ALLOWED_ORIGINS" "$CORS_ORIGINS"
        upsert_env_var ".envs/.django" "DJANGO_CSRF_TRUSTED_ORIGINS" "$CSRF_TRUSTED_ORIGINS"
    elif [ "$DEV_CORS_PROVIDED" = true ]; then
        upsert_env_var ".envs/.django" "DJANGO_CORS_ALLOWED_ORIGINS" "$CORS_ORIGINS"
        upsert_env_var ".envs/.django" "DJANGO_CSRF_TRUSTED_ORIGINS" "$CSRF_TRUSTED_ORIGINS"
    else
        set_env_var_if_missing ".envs/.django" "DJANGO_ALLOWED_HOSTS" "$DOMAIN_CURRENT,localhost,127.0.0.1"
        set_env_var_if_missing ".envs/.django" "DJANGO_CORS_ALLOWED_ORIGINS" "$CORS_ORIGINS"
        set_env_var_if_missing ".envs/.django" "DJANGO_CSRF_TRUSTED_ORIGINS" "$CSRF_TRUSTED_ORIGINS"
    fi

    set_env_var_if_missing ".envs/.django" "DJANGO_SECURE_SSL_REDIRECT" "$SECURE_SSL_REDIRECT_DEFAULT"

    # Neue Images holen
    ensure_ghcr_login
    echo "Ziehe neue Images (docker compose pull) ..."
    docker compose pull

    # Container neu starten
    ensure_network_exists
    docker compose up -d

    echo "----------------------------------------"
    echo "DOCKER VOLUME UND IMAGES AUFRÄUMEN"
    echo "----------------------------------------"
    docker volume prune -f || true
    docker image prune -f || true

    echo "----------------------------------------"
    echo "UPDATE ERFOLGREICH"
    echo "----------------------------------------"
}

#############################################
# FUNKTION: Rollback
#############################################
function do_rollback() {
    echo "----------------------------------------"
    echo "ROLLBACK WIRD GESTARTET"
    echo "----------------------------------------"

    local rollback_version
    local current_version

    if [ ! -d "$INSTALL_PATH" ]; then
        echo "Fehler: Installationspfad $INSTALL_PATH existiert nicht."
        exit 1
    fi

    cd "$INSTALL_PATH"
    ensure_file_exists ".env"

    rollback_version="$INPUT_VERSION"
    if [ -z "$rollback_version" ]; then
        rollback_version="$(read_env_value ".env" "PREVIOUS_VERSION")"
    fi

    if [ -z "$rollback_version" ]; then
        echo "Fehler: Keine Rollback-Version gefunden."
        echo "Setze PREVIOUS_VERSION in .env oder rufe ./app_manager.sh rollback <VERSION> auf."
        exit 1
    fi

    current_version="$(read_env_value ".env" "VERSION")"
    if [ -n "$current_version" ]; then
        upsert_env_var ".env" "PREVIOUS_VERSION" "$current_version"
    fi
    upsert_env_var ".env" "VERSION" "$rollback_version"

    echo "Rollback auf Version $rollback_version wird ausgefuehrt."
    echo "Hinweis: DB-Downgrades erfolgen nicht automatisch."

    load_optional_secrets
    ensure_network_exists
    ensure_ghcr_login
    docker compose pull
    docker compose up -d

    echo "----------------------------------------"
    echo "ROLLBACK ERFOLGREICH"
    echo "----------------------------------------"
}

# Hauptablauf
print_platform_hint
ensure_prerequisites
ensure_compose_file_exists

case "$ACTION" in
    install)
        do_install
        ;;
    update)
        do_update
        ;;
    rollback)
        do_rollback
        ;;
    *)
        echo "Falscher Parameter. Usage: $0 [install|update|rollback] [VERSION]"
        exit 1
        ;;
esac
